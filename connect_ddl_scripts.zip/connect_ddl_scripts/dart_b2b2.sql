
  CREATE OR REPLACE EDITIONABLE FUNCTION "DART_B2B2"."GET_CONTRACTSTATUS_CSV_03AUG" (progId in varchar2,seasId in varchar2,stationId in varchar2)
return varchar2 is contractStatus varchar2(4000);
begin
if (seasId is not null ) then
	declare cursor contracts is 
        select distinct DECODE(value,'On Offer','U','Pre-Deal','U','Binding Deal','U','Contract Signed','C','Pending Ref# Approval','C','Contracted','C') as status from lookUp_value where lkp_id in (select distinct CONTRACT_STATUS_LKP_ID from RPM_Deal_product where gpms_prog_id = progId and gpms_seas_id = seasId 
        and rpm_station_id = stationId);
  begin
	for i in contracts 
	loop  
		contractStatus := contractStatus || ',' || i.status;  
	end loop ; 
  end;
end if;
if (seasId is null ) then
	declare cursor contracts is 
        select distinct DECODE(value,'On Offer','U','Pre-Deal','U','Binding Deal','U','Contract Signed','C','Pending Ref# Approval','C','Contracted','C') as status from lookUp_value where lkp_id in (select distinct CONTRACT_STATUS_LKP_ID from RPM_Deal_product where gpms_prog_id = progId and gpms_seas_id is null
        and rpm_station_id = stationId);
  begin	 
  for i in contracts
  loop 
     contractStatus := contractStatus || ',' || i.status;
  end loop ;
  end;
end if;
  IF contractStatus IS NOT NULL THEN
      contractStatus := SUBSTR(contractStatus,2);
  END IF;
return contractStatus;
end Get_ContractStatus_CSV_03AUG ;
/


  CREATE OR REPLACE EDITIONABLE FUNCTION "DART_B2B2"."GET_CONTRACTTYPE_CSV_03AUG" (progId in varchar2,seasId in varchar2,b2bstationId in varchar2)
return varchar2 is contractStatus varchar2(4000);
begin
if (seasId is not null ) then
	declare cursor contracts is 
        select value as status from lookUp_value where lkp_id in (select distinct rdp.CONTRACT_STATUS_LKP_ID from RPM_Deal_product rdp, rpm_deal_product_station rpds 
		where rdp.gpms_prog_id = progId and rdp.gpms_seas_id = seasId and rpds.rpm_request_id = rdp.rpm_request_id and rpds.b2b_station_id = b2bstationId );  
  begin
	for i in contracts 
	loop  
		contractStatus := contractStatus || ',' || i.status;  
	end loop ; 
  end;
end if;
if (seasId is null ) then
	declare cursor contracts is 
        select value as status from lookUp_value where lkp_id in (select distinct rdp.CONTRACT_STATUS_LKP_ID from RPM_Deal_product rdp, rpm_deal_product_station rpds 
		where rdp.gpms_prog_id = progId and rdp.gpms_seas_id is null and rpds.rpm_request_id = rdp.rpm_request_id and rpds.b2b_station_id = b2bstationId );  
  begin	 
  for i in contracts
  loop 
     contractStatus := contractStatus || ',' || i.status;
  end loop ;
  end;
end if;
  IF contractStatus IS NOT NULL THEN
      contractStatus := SUBSTR(contractStatus,2);
  END IF;
return contractStatus;
end Get_ContractType_CSV_03AUG;
/


  CREATE OR REPLACE EDITIONABLE FUNCTION "DART_B2B2"."GET_DEAL_CONTRACTSTATUS_CSV" (progId in varchar2,seasId in varchar2,b2bstationId in varchar2)
return varchar2 is contractStatus varchar2(4000);
begin
if (seasId is not null ) then
	declare cursor contracts is 
        select distinct DECODE(value,'On Offer','U','Pre-Deal','U','Binding Deal','U','Contract Signed','C','Pending Ref# Approval','C','Contracted','C') 
		as status from lookUp_value where lkp_id in (select distinct CONTRACT_STATUS_LKP_ID from RPM_Deal_product rdp, rpm_deal_product_station rpds   
		where rdp.gpms_prog_id = progId and rdp.gpms_seas_id = seasId and rpds.rpm_request_id = rdp.rpm_request_id and rpds.b2b_station_id = b2bstationId);  
  begin
	for i in contracts 
	loop  
		contractStatus := contractStatus || ',' || i.status;  
	end loop ; 
  end;
end if;
if (seasId is null ) then
	declare cursor contracts is 
        select distinct DECODE(value,'On Offer','U','Pre-Deal','U','Binding Deal','U','Contract Signed','C','Pending Ref# Approval','C','Contracted','C') 
		as status from lookUp_value where lkp_id in (select distinct rdp.CONTRACT_STATUS_LKP_ID from RPM_Deal_product rdp, rpm_deal_product_station rpds   
		where rdp.gpms_prog_id = progId and rdp.gpms_seas_id is null and rpds.rpm_request_id = rdp.rpm_request_id and rpds.b2b_station_id = b2bstationId);  
  begin	 
  for i in contracts
  loop 
     contractStatus := contractStatus || ',' || i.status;
  end loop ;
  end;
end if;
  IF contractStatus IS NOT NULL THEN
      contractStatus := SUBSTR(contractStatus,2);
  END IF;
return contractStatus;
end Get_deal_ContractStatus_CSV;
/


  CREATE OR REPLACE EDITIONABLE FUNCTION "DART_B2B2"."GET_DEAL_CONTRACTSTATUS_CSV_HI" (progId in varchar2,seasId in varchar2,b2bstationId in varchar2)
return varchar2 is contractStatus varchar2(4000);
begin
if (seasId is not null ) then
	declare cursor contracts is 
        select distinct DECODE(value,'On Offer','U','Pre-Deal','U','Binding Deal','U','Contract Signed','C','Pending Ref# Approval','C','Contracted','C') 
		as status from lookUp_value where lkp_id in (select distinct CONTRACT_STATUS_LKP_ID from RPM_Deal_product_historical rdp, rpm_deal_product_station_hist rpds   
		where rdp.gpms_prog_id = progId and rdp.gpms_seas_id = seasId and rpds.rpm_request_id = rdp.rpm_request_id and rpds.b2b_station_id = b2bstationId);  
  begin
	for i in contracts 
	loop  
		contractStatus := contractStatus || ',' || i.status;  
	end loop ; 
  end;
end if;
if (seasId is null ) then
	declare cursor contracts is 
        select distinct DECODE(value,'On Offer','U','Pre-Deal','U','Binding Deal','U','Contract Signed','C','Pending Ref# Approval','C','Contracted','C') 
		as status from lookUp_value where lkp_id in (select distinct rdp.CONTRACT_STATUS_LKP_ID from RPM_Deal_product_historical rdp, rpm_deal_product_station_hist rpds   
		where rdp.gpms_prog_id = progId and rdp.gpms_seas_id is null and rpds.rpm_request_id = rdp.rpm_request_id and rpds.b2b_station_id = b2bstationId);  
  begin	 
  for i in contracts
  loop 
     contractStatus := contractStatus || ',' || i.status;
  end loop ;
  end;
end if;
  IF contractStatus IS NOT NULL THEN
      contractStatus := SUBSTR(contractStatus,2);
  END IF;
return contractStatus;
end Get_deal_ContractStatus_CSV_hi;
/


  CREATE OR REPLACE EDITIONABLE FUNCTION "DART_B2B2"."GET_DEAL_CONTRACTSTATUS_CSV_SYND" (titleStatus in varchar2)
return varchar2 is contractStatus varchar2(4000);
begin
select connect_value into contractStatus from syndication_deal_map where lkp_type_id=16000 and Rpm_Value=titleStatus;
return contractStatus;
end Get_deal_ContractStatus_CSV_SYND;
/


  CREATE OR REPLACE EDITIONABLE FUNCTION "DART_B2B2"."GET_DEAL_CONTRACTTYPE_CSV" (progId in varchar2,seasId in varchar2,b2bstationId in varchar2)
return varchar2 is contractStatus varchar2(4000);
begin
if (seasId is not null ) then
	declare cursor contracts is 
        select value as status from lookUp_value where lkp_id in (select distinct rdp.CONTRACT_STATUS_LKP_ID from RPM_Deal_product rdp, rpm_deal_product_station rpds 
		where rdp.gpms_prog_id = progId and rdp.gpms_seas_id = seasId and rpds.rpm_request_id = rdp.rpm_request_id and rpds.b2b_station_id = b2bstationId );  
  begin
	for i in contracts 
	loop  
		contractStatus := contractStatus || ',' || i.status;  
	end loop ; 
  end;
end if;
if (seasId is null ) then
	declare cursor contracts is 
        select value as status from lookUp_value where lkp_id in (select distinct rdp.CONTRACT_STATUS_LKP_ID from RPM_Deal_product rdp, rpm_deal_product_station rpds 
		where rdp.gpms_prog_id = progId and rdp.gpms_seas_id is null and rpds.rpm_request_id = rdp.rpm_request_id and rpds.b2b_station_id = b2bstationId );  
  begin	 
  for i in contracts
  loop 
     contractStatus := contractStatus || ',' || i.status;
  end loop ;
  end;
end if;
  IF contractStatus IS NOT NULL THEN
      contractStatus := SUBSTR(contractStatus,2);
  END IF;
return contractStatus;
end Get_deal_ContractType_CSV;
/


  CREATE OR REPLACE EDITIONABLE FUNCTION "DART_B2B2"."GET_DEAL_CONTRACTTYPE_CSV_HIST" (progId in varchar2,seasId in varchar2,b2bstationId in varchar2)
return varchar2 is contractStatus varchar2(4000);
begin
if (seasId is not null ) then
	declare cursor contracts is 
        select value as status from lookUp_value where lkp_id in (select distinct rdp.CONTRACT_STATUS_LKP_ID from RPM_Deal_product_historical rdp, rpm_deal_product_station_hist rpds 
		where rdp.gpms_prog_id = progId and rdp.gpms_seas_id = seasId and rpds.rpm_request_id = rdp.rpm_request_id and rpds.b2b_station_id = b2bstationId );  
  begin
	for i in contracts 
	loop  
		contractStatus := contractStatus || ',' || i.status;  
	end loop ; 
  end;
end if;
if (seasId is null ) then
	declare cursor contracts is 
        select value as status from lookUp_value where lkp_id in (select distinct rdp.CONTRACT_STATUS_LKP_ID from RPM_Deal_product_historical rdp, rpm_deal_product_station_hist rpds 
		where rdp.gpms_prog_id = progId and rdp.gpms_seas_id is null and rpds.rpm_request_id = rdp.rpm_request_id and rpds.b2b_station_id = b2bstationId );  
  begin	 
  for i in contracts
  loop 
     contractStatus := contractStatus || ',' || i.status;
  end loop ;
  end;
end if;
  IF contractStatus IS NOT NULL THEN
      contractStatus := SUBSTR(contractStatus,2);
  END IF;
return contractStatus;
end Get_deal_ContractType_CSV_hist;
/


  CREATE OR REPLACE EDITIONABLE FUNCTION "DART_B2B2"."GET_DEAL_PRODUCT_ID_CSV" (progId in varchar2,seasId in varchar2,b2bstationId in varchar2)
return varchar2 is dealProductIds varchar2(4000);
begin
if (seasId is not null ) then
	declare cursor dealIds is 
        select distinct rdp.DEAL_PRODUCT_ID as dealId from RPM_Deal_product rdp, rpm_deal_product_station rpds where rdp.gpms_prog_id = progId 
		and rdp.gpms_seas_id = seasId and rpds.rpm_request_id = rdp.rpm_request_id and rpds.b2b_station_id = b2bstationId;  
  begin
	for i in dealIds 
	loop  
		dealProductIds := dealProductIds || ',' || i.dealId;  
	end loop ; 
  end;
end if;
if (seasId is null ) then
	declare cursor dealIds is 
        select distinct rdp.DEAL_PRODUCT_ID as dealId from RPM_Deal_product rdp, rpm_deal_product_station rpds where rdp.gpms_prog_id = progId 
		and rdp.gpms_seas_id is null and rpds.rpm_request_id = rdp.rpm_request_id and rpds.b2b_station_id = b2bstationId;  
  begin	 
  for i in dealIds
  loop 
     dealProductIds := dealProductIds || ',' || i.dealId;
  end loop ;
  end;
end if;
  IF dealProductIds IS NOT NULL THEN
      dealProductIds := SUBSTR(dealProductIds,2);
  END IF;
return dealProductIds;
end get_deal_product_Id_CSV;
/


  CREATE OR REPLACE EDITIONABLE FUNCTION "DART_B2B2"."GET_DEAL_PRODUCT_ID_CSV_03AUG" (progId in varchar2,seasId in varchar2,stationId in varchar2)
return varchar2 is dealProductIds varchar2(4000);
begin
if (seasId is not null ) then
	declare cursor dealIds is 
        select distinct DEAL_PRODUCT_ID as dealId from RPM_DEAL_Product where gpms_prog_id = progId and gpms_seas_id = seasId 
        and rpm_station_id = stationId;
  begin
	for i in dealIds 
	loop  
		dealProductIds := dealProductIds || ',' || i.dealId;  
	end loop ; 
  end;
end if;
if (seasId is null ) then
	declare cursor dealIds is 
        select distinct DEAL_PRODUCT_ID as dealId from RPM_DEAL_Product where gpms_prog_id = progId and gpms_seas_id is null
        and rpm_station_id = stationId;
  begin	 
  for i in dealIds
  loop 
     dealProductIds := dealProductIds || ',' || i.dealId;
  end loop ;
  end;
end if;
  IF dealProductIds IS NOT NULL THEN
      dealProductIds := SUBSTR(dealProductIds,2);
  END IF;
return dealProductIds;
end Get_deal_product_Id_CSV_03AUG;
/


  CREATE OR REPLACE EDITIONABLE FUNCTION "DART_B2B2"."GET_DEAL_TERRITORY_CSV" (progId in varchar2,seasId in varchar2,b2bstationId in varchar2)
return varchar2 is territoryValues varchar2(4000);
begin
if (seasId is not null ) then
	declare cursor territorys is 
        select  TERRITORY_NAME as territory, territory_id  from RPM_Territory where territory_id in (select distinct territory_id from RPM_DEAL_TERRITORY_MEDIA 
		where rpm_request_id in(select distinct rdp.rpm_request_id from RPM_DEAL_Product rdp, rpm_deal_product_station rpds where rdp.gpms_prog_id = progId   
		and rdp.gpms_seas_id = seasId and rpds.rpm_request_id = rdp.rpm_request_id and rpds.b2b_station_id = b2bstationId)) order by territory_id asc;  
  begin
	for i in territorys 
	loop  
		territoryValues := territoryValues || ',' || i.territory;  
	end loop ; 
  end;
end if;
if (seasId is null ) then
	declare cursor territorys is 
        select  TERRITORY_NAME as territory,territory_id from RPM_Territory where territory_id in (select distinct territory_id from RPM_DEAL_TERRITORY_MEDIA 
		where rpm_request_id in(select distinct rdp.rpm_request_id from RPM_DEAL_Product rdp, rpm_deal_product_station rpds where rdp.gpms_prog_id = progId  
        and rdp.gpms_seas_id is null and rpds.rpm_request_id = rdp.rpm_request_id and rpds.b2b_station_id = b2bstationId)) order by territory_id asc;
  begin	 
  for i in territorys
  loop 
     territoryValues := territoryValues || ',' || i.territory;
  end loop ;
  end;
end if;
  IF territoryValues IS NOT NULL THEN
      territoryValues := SUBSTR(territoryValues,2);
  END IF;
return territoryValues;
end Get_deal_territory_CSV;
/


  CREATE OR REPLACE EDITIONABLE FUNCTION "DART_B2B2"."GET_DEAL_TERRITORY_CSV_HIST" (progId in varchar2,seasId in varchar2,b2bstationId in varchar2)
return varchar2 is territoryValues varchar2(4000);
begin
if (seasId is not null ) then
	declare cursor territorys is 
        select  TERRITORY_NAME as territory, territory_id  from RPM_Territory_HIST where territory_id in (select distinct territory_id from RPM_DEAL_TERRITORY_MEDIA_HIST
		where rpm_request_id in(select distinct rdp.rpm_request_id from RPM_DEAL_Product_HISTORICAL rdp, rpm_deal_product_station_hist rpds where rdp.gpms_prog_id = progId   
		and rdp.gpms_seas_id = seasId and rpds.rpm_request_id = rdp.rpm_request_id and rpds.b2b_station_id = b2bstationId)) order by territory_id asc;  
  begin
	for i in territorys 
	loop  
		territoryValues := territoryValues || ',' || i.territory;  
	end loop ; 
  end;
end if;
if (seasId is null ) then
	declare cursor territorys is 
        select  TERRITORY_NAME as territory,territory_id from RPM_Territory_HIST where territory_id in (select distinct territory_id from RPM_DEAL_TERRITORY_MEDIA_HIST 
		where rpm_request_id in(select distinct rdp.rpm_request_id from RPM_DEAL_Product_HISTORICAL rdp, rpm_deal_product_station_hist rpds where rdp.gpms_prog_id = progId  
        and rdp.gpms_seas_id is null and rpds.rpm_request_id = rdp.rpm_request_id and rpds.b2b_station_id = b2bstationId)) order by territory_id asc;
  begin	 
  for i in territorys
  loop 
     territoryValues := territoryValues || ',' || i.territory;
  end loop ;
  end;
end if;
  IF territoryValues IS NOT NULL THEN
      territoryValues := SUBSTR(territoryValues,2);
  END IF;
return territoryValues;
end Get_deal_territory_CSV_HIST;
/


  CREATE OR REPLACE EDITIONABLE FUNCTION "DART_B2B2"."GET_DEAL_TERRITORY_IDS" (progId in varchar2,seasId in varchar2,b2bstationId in varchar2)
return varchar2 is territoryIds varchar2(4000);
begin
if (seasId is not null ) then
	declare cursor territorys is 
        select distinct territory_id as territory  from RPM_DEAL_TERRITORY_MEDIA where rpm_request_id in(select distinct rdp.rpm_request_id 
		from RPM_Deal_product rdp, rpm_deal_product_station rpds where rdp.gpms_prog_id = progId and rdp.gpms_seas_id = seasId   
        and rpds.rpm_request_id = rdp.rpm_request_id and rpds.b2b_station_id = b2bstationId) order by territory_id asc;
  begin
	for i in territorys 
	loop  
		territoryIds := territoryIds || ',' || i.territory;  
	end loop ; 
  end;
end if;
if (seasId is null ) then
	declare cursor territorys is 
        select distinct territory_id as territory from RPM_DEAL_TERRITORY_MEDIA where rpm_request_id in(select distinct rdp.rpm_request_id 
		from RPM_Deal_product rdp, rpm_deal_product_station rpds where rdp.gpms_prog_id = progId and rdp.gpms_seas_id is null   
        and rpds.rpm_request_id = rdp.rpm_request_id and rpds.b2b_station_id = b2bstationId) order by territory_id asc;
  begin	 
  for i in territorys
  loop 
     territoryIds := territoryIds || ',' || i.territory;
  end loop ;
  end;
end if;
  IF territoryIds IS NOT NULL THEN
      territoryIds := SUBSTR(territoryIds,2);
  END IF;
return territoryIds;
end Get_deal_territory_Ids;
/


  CREATE OR REPLACE EDITIONABLE FUNCTION "DART_B2B2"."GET_DEAL_TERRITORY_IDS_03AUG" (progId in varchar2,seasId in varchar2,stationId in varchar2)
return varchar2 is territoryIds varchar2(4000);
begin
if (seasId is not null ) then
	declare cursor territorys is 
        select distinct territory_id as territory  from RPM_DEAL_TERRITORY_MEDIA where rpm_request_id in(select distinct rpm_request_id from RPM_DEAL_Product where gpms_prog_id = progId and gpms_seas_id = seasId 
        and rpm_station_id = stationId) order by territory_id asc;
  begin
	for i in territorys 
	loop  
		territoryIds := territoryIds || ',' || i.territory;  
	end loop ; 
  end;
end if;
if (seasId is null ) then
	declare cursor territorys is 
        select distinct territory_id as territory from RPM_DEAL_TERRITORY_MEDIA where rpm_request_id in(select distinct rpm_request_id from RPM_DEAL_Product where gpms_prog_id = progId
        and gpms_seas_id is null 
        and rpm_station_id = stationId) order by territory_id asc;
  begin	 
  for i in territorys
  loop 
     territoryIds := territoryIds || ',' || i.territory;
  end loop ;
  end;
end if;
  IF territoryIds IS NOT NULL THEN
      territoryIds := SUBSTR(territoryIds,2);
  END IF;
return territoryIds;
end Get_deal_territory_Ids_03AUG;
/


  CREATE OR REPLACE EDITIONABLE FUNCTION "DART_B2B2"."GET_DEAL_TERRITORY_IDS_HIST" (progId in varchar2,seasId in varchar2,b2bstationId in varchar2)
return varchar2 is territoryIds varchar2(4000);
begin
if (seasId is not null ) then
	declare cursor territorys is 
        select distinct territory_id as territory  from RPM_DEAL_TERRITORY_MEDIA_HIST where rpm_request_id in(select distinct rdp.rpm_request_id 
		from RPM_Deal_product_HISTORICAL rdp, rpm_deal_product_station_hist rpds where rdp.gpms_prog_id = progId and rdp.gpms_seas_id = seasId   
        and rpds.rpm_request_id = rdp.rpm_request_id and rpds.b2b_station_id = b2bstationId) order by territory_id asc;
  begin
	for i in territorys 
	loop  
		territoryIds := territoryIds || ',' || i.territory;  
	end loop ; 
  end;
end if;
if (seasId is null ) then
	declare cursor territorys is 
        select distinct territory_id as territory from RPM_DEAL_TERRITORY_MEDIA_HIST where rpm_request_id in(select distinct rdp.rpm_request_id 
		from RPM_Deal_product_HISTORICAL rdp, rpm_deal_product_station_hist rpds where rdp.gpms_prog_id = progId and rdp.gpms_seas_id is null   
        and rpds.rpm_request_id = rdp.rpm_request_id and rpds.b2b_station_id = b2bstationId) order by territory_id asc;
  begin	 
  for i in territorys
  loop 
     territoryIds := territoryIds || ',' || i.territory;
  end loop ;
  end;
end if;
  IF territoryIds IS NOT NULL THEN
      territoryIds := SUBSTR(territoryIds,2);
  END IF;
return territoryIds;
end Get_deal_territory_Ids_hist;
/


  CREATE OR REPLACE EDITIONABLE FUNCTION "DART_B2B2"."GET_LICENSETYPE_IDS" (progId in varchar2,seasId in varchar2,b2bstationId in varchar2)
return varchar2 is licenseTypeIds varchar2(4000);
begin
if (seasId is not null ) then
	declare cursor licenseTypes is 
        select distinct LICENSE_LKP_ID as licenseType  from RPM_DEAL_TERRITORY_MEDIA where rpm_request_id in(select distinct rdp.rpm_request_id 
		from RPM_Deal_product rdp, rpm_deal_product_station rpds where rdp.gpms_prog_id = progId and rdp.gpms_seas_id = seasId   
        and rpds.rpm_request_id = rdp.rpm_request_id and rpds.b2b_station_id = b2bstationId) and LICENSE_LKP_ID is not null order by LICENSE_LKP_ID asc;
  begin
	for i in licenseTypes 
	loop  
		licenseTypeIds := licenseTypeIds || ',' || i.licenseType;  
	end loop ; 
  end;
end if;
if (seasId is null ) then
	declare cursor licenseTypes is 
        select distinct LICENSE_LKP_ID as licenseType from RPM_DEAL_TERRITORY_MEDIA where rpm_request_id in(select distinct rdp.rpm_request_id 
		from RPM_Deal_product rdp, rpm_deal_product_station rpds where rdp.gpms_prog_id = progId and rdp.gpms_seas_id is null   
        and rpds.rpm_request_id = rdp.rpm_request_id and rpds.b2b_station_id = b2bstationId) and LICENSE_LKP_ID is not null order by LICENSE_LKP_ID asc;
  begin	 
  for i in licenseTypes
  loop 
     licenseTypeIds := licenseTypeIds || ',' || i.licenseType;
  end loop ;
  end;
end if;
  IF licenseTypeIds IS NOT NULL THEN
      licenseTypeIds := SUBSTR(licenseTypeIds,2);
  END IF;
return licenseTypeIds;
end Get_LicenseType_Ids;
/


  CREATE OR REPLACE EDITIONABLE FUNCTION "DART_B2B2"."GET_LICENSETYPE_IDS_03AUG" (progId in varchar2,seasId in varchar2,stationId in varchar2)
return varchar2 is licenseTypeIds varchar2(4000);
begin
if (seasId is not null ) then
	declare cursor licenseTypes is 
        select distinct LICENSE_LKP_ID as licenseType  from RPM_DEAL_TERRITORY_MEDIA where rpm_request_id in(select distinct rpm_request_id from RPM_DEAL_Product where gpms_prog_id = progId and gpms_seas_id = seasId 
        and rpm_station_id = stationId) and LICENSE_LKP_ID is not null order by LICENSE_LKP_ID asc;
  begin
	for i in licenseTypes 
	loop  
		licenseTypeIds := licenseTypeIds || ',' || i.licenseType;  
	end loop ; 
  end;
end if;
if (seasId is null ) then
	declare cursor licenseTypes is 
        select distinct LICENSE_LKP_ID as licenseType from RPM_DEAL_TERRITORY_MEDIA where rpm_request_id in(select distinct rpm_request_id from RPM_DEAL_Product where gpms_prog_id = progId
        and gpms_seas_id is null 
        and rpm_station_id = stationId) and LICENSE_LKP_ID is not null order by LICENSE_LKP_ID asc;
  begin	 
  for i in licenseTypes
  loop 
     licenseTypeIds := licenseTypeIds || ',' || i.licenseType;
  end loop ;
  end;
end if;
  IF licenseTypeIds IS NOT NULL THEN
      licenseTypeIds := SUBSTR(licenseTypeIds,2);
  END IF;
return licenseTypeIds;
end Get_LicenseType_Ids_03AUG;
/


  CREATE OR REPLACE EDITIONABLE FUNCTION "DART_B2B2"."GET_LICENSETYPE_IDS_HIST" (progId in varchar2,seasId in varchar2,b2bstationId in varchar2)
return varchar2 is licenseTypeIds varchar2(4000);
begin
if (seasId is not null ) then
	declare cursor licenseTypes is 
        select distinct LICENSE_LKP_ID as licenseType  from RPM_DEAL_TERRITORY_MEDIA_HIST where rpm_request_id in(select distinct rdp.rpm_request_id 
		from RPM_Deal_product_historical rdp, rpm_deal_product_station_hist rpds where rdp.gpms_prog_id = progId and rdp.gpms_seas_id = seasId   
        and rpds.rpm_request_id = rdp.rpm_request_id and rpds.b2b_station_id = b2bstationId) and LICENSE_LKP_ID is not null order by LICENSE_LKP_ID asc;
  begin
	for i in licenseTypes 
	loop  
		licenseTypeIds := licenseTypeIds || ',' || i.licenseType;  
	end loop ; 
  end;
end if;
if (seasId is null ) then
	declare cursor licenseTypes is 
        select distinct LICENSE_LKP_ID as licenseType from RPM_DEAL_TERRITORY_MEDIA_HIST where rpm_request_id in(select distinct rdp.rpm_request_id 
		from RPM_Deal_product_historical rdp, rpm_deal_product_station_hist rpds where rdp.gpms_prog_id = progId and rdp.gpms_seas_id is null   
        and rpds.rpm_request_id = rdp.rpm_request_id and rpds.b2b_station_id = b2bstationId) and LICENSE_LKP_ID is not null order by LICENSE_LKP_ID asc;
  begin	 
  for i in licenseTypes
  loop 
     licenseTypeIds := licenseTypeIds || ',' || i.licenseType;
  end loop ;
  end;
end if;
  IF licenseTypeIds IS NOT NULL THEN
      licenseTypeIds := SUBSTR(licenseTypeIds,2);
  END IF;
return licenseTypeIds;
end Get_LicenseType_Ids_hist;
/


  CREATE OR REPLACE EDITIONABLE FUNCTION "DART_B2B2"."GET_LICENSETYPE_VALUES" (progId in varchar2,seasId in varchar2,b2bstationId in varchar2)
return varchar2 is licenseTypeValues varchar2(4000);
begin
if (seasId is not null ) then
	declare cursor licenseTypes is 
        select value as licensetype,lkp_id from DTV_B2B2.lookup_value where lkp_id in (select distinct LICENSE_LKP_ID from RPM_DEAL_TERRITORY_MEDIA 
		where rpm_request_id in(select distinct rdp.rpm_request_id from RPM_Deal_product rdp, rpm_deal_product_station rpds where rdp.gpms_prog_id = progId   
		and rdp.gpms_seas_id = seasId and rpds.rpm_request_id = rdp.rpm_request_id and rpds.b2b_station_id = b2bstationId) and LICENSE_LKP_ID is not null) order by lkp_id asc;  
  begin
	for i in licenseTypes 
	loop  
		licenseTypeValues := licenseTypeValues || ',' || i.licenseType;  
	end loop ; 
  end;
end if;
if (seasId is null ) then
	declare cursor licenseTypes is 
        select value as licensetype,lkp_id from DTV_B2B2.lookup_value where lkp_id in (select distinct LICENSE_LKP_ID from RPM_DEAL_TERRITORY_MEDIA 
		where rpm_request_id in(select distinct rdp.rpm_request_id from RPM_DEAL_Product rdp, rpm_deal_product_station rpds where rdp.gpms_prog_id = progId  
        and rdp.gpms_seas_id is null and rpds.rpm_request_id = rdp.rpm_request_id and rpds.b2b_station_id = b2bstationId ) and LICENSE_LKP_ID is not null) order by lkp_id asc;
  begin	 
  for i in licenseTypes
  loop 
     licenseTypeValues := licenseTypeValues || ',' || i.licenseType;
  end loop ;
  end;
end if;
  IF licenseTypeValues IS NOT NULL THEN
      licenseTypeValues := SUBSTR(licenseTypeValues,2);
  END IF;
return licenseTypeValues;
end Get_LicenseType_Values;
/


  CREATE OR REPLACE EDITIONABLE FUNCTION "DART_B2B2"."GET_LICENSETYPE_VALUES_03AUG" (progId in varchar2,seasId in varchar2,stationId in varchar2)
return varchar2 is licenseTypeValues varchar2(4000);
begin
if (seasId is not null ) then
	declare cursor licenseTypes is 
        select value as licensetype,lkp_id from DTV_B2B2.lookup_value where lkp_id in (select distinct LICENSE_LKP_ID from RPM_DEAL_TERRITORY_MEDIA where rpm_request_id in(select distinct rpm_request_id from RPM_DEAL_Product where gpms_prog_id = progId and gpms_seas_id = seasId 
        and rpm_station_id = stationId) and LICENSE_LKP_ID is not null) order by lkp_id asc;
  begin
	for i in licenseTypes 
	loop  
		licenseTypeValues := licenseTypeValues || ',' || i.licenseType;  
	end loop ; 
  end;
end if;
if (seasId is null ) then
	declare cursor licenseTypes is 
        select value as licensetype,lkp_id from DTV_B2B2.lookup_value where lkp_id in (select distinct LICENSE_LKP_ID from RPM_DEAL_TERRITORY_MEDIA where rpm_request_id in(select distinct rpm_request_id from RPM_DEAL_Product where gpms_prog_id = progId
        and gpms_seas_id is null 
        and rpm_station_id = stationId) and LICENSE_LKP_ID is not null) order by lkp_id asc;
  begin	 
  for i in licenseTypes
  loop 
     licenseTypeValues := licenseTypeValues || ',' || i.licenseType;
  end loop ;
  end;
end if;
  IF licenseTypeValues IS NOT NULL THEN
      licenseTypeValues := SUBSTR(licenseTypeValues,2);
  END IF;
return licenseTypeValues;
end Get_LicenseType_Values_03AUG;
/


  CREATE OR REPLACE EDITIONABLE FUNCTION "DART_B2B2"."GET_LICENSETYPE_VALUES_HIST" (progId in varchar2,seasId in varchar2,b2bstationId in varchar2)
return varchar2 is licenseTypeValues varchar2(4000);
begin
if (seasId is not null ) then
	declare cursor licenseTypes is 
        select value as licensetype,lkp_id from DTV_B2B2.lookup_value where lkp_id in (select distinct LICENSE_LKP_ID from RPM_DEAL_TERRITORY_MEDIA_HIST 
		where rpm_request_id in(select distinct rdp.rpm_request_id from RPM_Deal_product_historical rdp, rpm_deal_product_station_hist rpds where rdp.gpms_prog_id = progId   
		and rdp.gpms_seas_id = seasId and rpds.rpm_request_id = rdp.rpm_request_id and rpds.b2b_station_id = b2bstationId) and LICENSE_LKP_ID is not null) order by lkp_id asc;  
  begin
	for i in licenseTypes 
	loop  
		licenseTypeValues := licenseTypeValues || ',' || i.licenseType;  
	end loop ; 
  end;
end if;
if (seasId is null ) then
	declare cursor licenseTypes is 
        select value as licensetype,lkp_id from DTV_B2B2.lookup_value where lkp_id in (select distinct LICENSE_LKP_ID from RPM_DEAL_TERRITORY_MEDIA_HIST 
		where rpm_request_id in(select distinct rdp.rpm_request_id from RPM_Deal_product_historical rdp, rpm_deal_product_station_hist rpds where rdp.gpms_prog_id = progId  
        and rdp.gpms_seas_id is null and rpds.rpm_request_id = rdp.rpm_request_id and rpds.b2b_station_id = b2bstationId ) and LICENSE_LKP_ID is not null) order by lkp_id asc;
  begin	 
  for i in licenseTypes
  loop 
     licenseTypeValues := licenseTypeValues || ',' || i.licenseType;
  end loop ;
  end;
end if;
  IF licenseTypeValues IS NOT NULL THEN
      licenseTypeValues := SUBSTR(licenseTypeValues,2);
  END IF;
return licenseTypeValues;
end Get_LicenseType_Values_hist;
/


  CREATE OR REPLACE EDITIONABLE FUNCTION "DART_B2B2"."GET_PROGRAM_NAME" (gprogId in varchar2, Station_Name in varchar2)
return varchar2 is pName varchar2(256);
prog_name varchar2(256) :=null;
cnt1 Number(10) := 0;
begin
  select count(*) into cnt1 from RPM_DEAL_PRODUCT where station_name = Station_Name and GPMS_PRODUCT_ID = gprogId;
if (cnt1 >= 1) then
	select prog_name into prog_name from RPM_DEAL_PRODUCT where station_name = Station_Name and GPMS_PRODUCT_ID = gprogId and prog_name is not null and ROWNUM=1 ; 
end if;
pname := prog_name;
return pname;
end GET_PROGRAM_NAME;
/


  CREATE OR REPLACE EDITIONABLE FUNCTION "DART_B2B2"."GET_PROGRAM_TYPE" (gprogId in varchar2, Station_Name in varchar2)
return varchar2 is pName varchar2(256);
prog_type varchar2(256) :=null;
cnt1 Number(10) := 0;
begin
  select count(*) into cnt1 from RPM_DEAL_PRODUCT where station_name = Station_Name and GPMS_PRODUCT_ID = gprogId;
if (cnt1 >= 1) then
	select prog_type into prog_type  from RPM_DEAL_PRODUCT where station_name = Station_Name and GPMS_PRODUCT_ID = gprogId and prog_type is not null and ROWNUM=1 ; 
end if;
pname := prog_type;
return pname;
end get_program_type;
/


  CREATE OR REPLACE EDITIONABLE FUNCTION "DART_B2B2"."GET_TERRITORY_CSV_03AUG" (progId in varchar2,seasId in varchar2,stationId in varchar2)
return varchar2 is territoryValues varchar2(4000);
begin
if (seasId is not null ) then
	declare cursor territorys is 
        select  TERRITORY_NAME as territory, territory_id  from RPM_Territory where territory_id in (select distinct territory_id from RPM_DEAL_TERRITORY_MEDIA where rpm_request_id in(select distinct rpm_request_id from RPM_DEAL_Product where gpms_prog_id = progId and gpms_seas_id = seasId 
        and rpm_station_id = stationId)) order by territory_id asc;
  begin
	for i in territorys 
	loop  
		territoryValues := territoryValues || ',' || i.territory;  
	end loop ; 
  end;
end if;
if (seasId is null ) then
	declare cursor territorys is 
        select  TERRITORY_NAME as territory,territory_id from RPM_Territory where territory_id in (select distinct territory_id from RPM_DEAL_TERRITORY_MEDIA where rpm_request_id in(select distinct rpm_request_id from RPM_DEAL_Product where gpms_prog_id = progId
        and gpms_seas_id is null 
        and rpm_station_id = stationId)) order by territory_id asc;
  begin	 
  for i in territorys
  loop 
     territoryValues := territoryValues || ',' || i.territory;
  end loop ;
  end;
end if;
  IF territoryValues IS NOT NULL THEN
      territoryValues := SUBSTR(territoryValues,2);
  END IF;
return territoryValues;
end Get_territory_CSV_03AUG;
/


  CREATE INDEX "DART_B2B2"."CONTRACT_STATUS_LKP_ID_IDX" ON "DART_B2B2"."RPM_DEAL_PRODUCT" ("CONTRACT_STATUS_LKP_ID") 
  PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SPT_DATA1" ;


  CREATE INDEX "DART_B2B2"."CONT_STATUS_LKP_ID_IDX" ON "DART_B2B2"."RPM_DEAL_PRODUCT_HISTORICAL" ("CONTRACT_STATUS_LKP_ID") 
  PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SPT_DATA1" ;


  CREATE INDEX "DART_B2B2"."CREATED_DT" ON "DART_B2B2"."RPM_JSON_LOG" ("CREATED_DT") 
  PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SPT_DATA1" ;


  CREATE INDEX "DART_B2B2"."CREATED_DT_SYND" ON "DART_B2B2"."RPM_JSON_LOG_SYND" ("CREATED_DT") 
  PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SPT_DATA1" ;


  CREATE INDEX "DART_B2B2"."CUST_HIST_CNAME_IDX" ON "DART_B2B2"."INTL_CUSTOMER_HISTORICAL" ("CUSTOMER_NAME") 
  PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SPT_DATA1" ;


  CREATE INDEX "DART_B2B2"."CUST_HIST_CNO_IDX" ON "DART_B2B2"."INTL_CUSTOMER_HISTORICAL" ("CUSTOMER_NUMBER") 
  PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SPT_DATA1" ;


  CREATE INDEX "DART_B2B2"."CUST_HIST_LDEL_DAT_IDX" ON "DART_B2B2"."RPM_DEAL_PRODUCT_HISTORICAL" ("DELIVER_BY_DT") 
  PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SPT_DATA1" ;


  CREATE INDEX "DART_B2B2"."CUST_HIST_LDEL_DT_IDX" ON "DART_B2B2"."RPM_DEAL_PRODUCT_HISTORICAL" ("DELIVERY_LEAD_DAYS") 
  PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SPT_DATA1" ;


  CREATE INDEX "DART_B2B2"."CUST_HIST_LUD_BY_IDX" ON "DART_B2B2"."RPM_DEAL_PRODUCT_HISTORICAL" ("LAST_UPDATED_BY") 
  PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SPT_DATA1" ;


  CREATE INDEX "DART_B2B2"."CUST_HIST_LUD_DT_IDX" ON "DART_B2B2"."RPM_DEAL_PRODUCT_HISTORICAL" ("LAST_UPDATED_DT") 
  PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SPT_DATA1" ;


  CREATE INDEX "DART_B2B2"."CUST_HIST_ST_ID_IDX" ON "DART_B2B2"."RPM_DEAL_PRODUCT_STITCHED_HIST" ("DELIVERY_LEAD_DAYS") 
  PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SPT_DATA1" ;


  CREATE INDEX "DART_B2B2"."CUST_HIST_S_NUM_IDX" ON "DART_B2B2"."RPM_DEAL_PRODUCT_HISTORICAL" ("SEASON_NUM") 
  PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SPT_DATA1" ;


  CREATE INDEX "DART_B2B2"."CUST_STIT_CTY_ID_IDX" ON "DART_B2B2"."RPM_DEAL_PRODUCT_STITCHED_HIST" ("CONTRACT_STATUS_TYPE_CSV") 
  PCTFREE 10 INITRANS 2 MAXTRANS 167 COMPUTE STATISTICS 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SPT_DATA1" ;


  CREATE INDEX "DART_B2B2"."CUST_STIT_CVAL_ID_IDX" ON "DART_B2B2"."RPM_DEAL_PRODUCT_STITCHED_HIST" ("CONTRACT_STATUS_VALUE_CSV") 
  PCTFREE 10 INITRANS 2 MAXTRANS 167 COMPUTE STATISTICS 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SPT_DATA1" ;


  CREATE INDEX "DART_B2B2"."CUST_STIT_LIC_TVID_IDX" ON "DART_B2B2"."RPM_DEAL_PRODUCT_STITCHED_HIST" ("LICENSE_TYPE_ID_CSV") 
  PCTFREE 10 INITRANS 2 MAXTRANS 167 COMPUTE STATISTICS 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SPT_DATA1" ;


  CREATE INDEX "DART_B2B2"."CUST_STIT_LIC_TV_IDX" ON "DART_B2B2"."RPM_DEAL_PRODUCT_STITCHED_HIST" ("LICENSE_TYPE_VALUE_CSV") 
  PCTFREE 10 INITRANS 2 MAXTRANS 167 COMPUTE STATISTICS 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SPT_DATA1" ;


  CREATE INDEX "DART_B2B2"."CUST_STIT_STNVAL_ID_IDX" ON "DART_B2B2"."RPM_DEAL_PRODUCT_STITCHED_HIST" ("TERRITORY_VALUE_CSV") 
  PCTFREE 10 INITRANS 2 MAXTRANS 167 COMPUTE STATISTICS 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SPT_DATA1" ;


  CREATE INDEX "DART_B2B2"."CUST_STN_CID_IDX" ON "DART_B2B2"."INTL_STATION_HISTORICAL" ("CUST_ID") 
  PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SPT_DATA1" ;


  CREATE INDEX "DART_B2B2"."CUST_STN_ISAC_IDX" ON "DART_B2B2"."INTL_STATION_HISTORICAL" ("IS_ACTIVE") 
  PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SPT_DATA1" ;


  CREATE INDEX "DART_B2B2"."CUST_STN_ISDE_IDX" ON "DART_B2B2"."INTL_STATION_HISTORICAL" ("IS_DELETED") 
  PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SPT_DATA1" ;


  CREATE INDEX "DART_B2B2"."CUST_STN_NA_IDX" ON "DART_B2B2"."INTL_STATION_HISTORICAL" ("STATION_NAME") 
  PCTFREE 10 INITRANS 2 MAXTRANS 167 COMPUTE STATISTICS 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SPT_DATA1" ;


  CREATE INDEX "DART_B2B2"."CUST_STN_RSID_IDX" ON "DART_B2B2"."INTL_STATION_HISTORICAL" ("RPM_STATION_ID") 
  PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SPT_DATA1" ;


  CREATE INDEX "DART_B2B2"."CUST_TER_LANG_ID_IDX" ON "DART_B2B2"."RPM_DEAL_TERRITORY_MEDIA_LA_HI" ("LANGUAGE_ID") 
  PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SPT_DATA1" ;


  CREATE INDEX "DART_B2B2"."CUST_TER_MED_ID_IDX" ON "DART_B2B2"."RPM_DEAL_TERRITORY_MEDIA_HIST" ("RPM_TER_MEDIA_ID") 
  PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SPT_DATA1" ;


  CREATE INDEX "DART_B2B2"."CUST_TER_M_ID_IDX" ON "DART_B2B2"."RPM_DEAL_TERRITORY_MEDIA_LA_HI" ("RPM_TER_MEDIA_ID") 
  PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SPT_DATA1" ;


  CREATE INDEX "DART_B2B2"."CUST_TER_M_LANG_ID_IDX" ON "DART_B2B2"."RPM_DEAL_TERRITORY_MEDIA_LA_HI" ("RPM_TER_MEDIA_LANG_ID") 
  PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SPT_DATA1" ;


  CREATE INDEX "DART_B2B2"."GPMS_PRODUCT_ID_IDX" ON "DART_B2B2"."RPM_DEAL_PRODUCT" ("GPMS_PRODUCT_ID") 
  PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SPT_DATA1" ;


  CREATE INDEX "DART_B2B2"."GPMS_PROD_ID_IDX" ON "DART_B2B2"."RPM_DEAL_PRODUCT_HISTORICAL" ("GPMS_PRODUCT_ID") 
  PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SPT_DATA1" ;


  CREATE INDEX "DART_B2B2"."INX_PROG_NAME" ON "DART_B2B2"."PROG_MANAGE_ACCESS_INTL" ("PROG_NAME") 
  PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SPT_DATA1" ;


  CREATE INDEX "DART_B2B2"."LKP_VALUE_IDX" ON "DART_B2B2"."LOOKUP_VALUE" ("VALUE") 
  PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SPT_DATA1" ;


  CREATE UNIQUE INDEX "DART_B2B2"."LOOKUP_TYPE_PK" ON "DART_B2B2"."LOOKUP_TYPE" ("LKP_TYPE_ID") 
  PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SPT_DATA1" ;


  CREATE UNIQUE INDEX "DART_B2B2"."LOOKUP_VALUE_PK" ON "DART_B2B2"."LOOKUP_VALUE" ("LKP_ID") 
  PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SPT_DATA1" ;


  CREATE INDEX "DART_B2B2"."MEDIA_ID_IDX" ON "DART_B2B2"."RPM_DEAL_TERRITORY_MEDIA" ("MEDIA_ID") 
  PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SPT_DATA1" ;


  CREATE INDEX "DART_B2B2"."PROG_ID_2_ID_IDX" ON "DART_B2B2"."PROG_MANAGE_ACCESS_INTL" ("PROG_ID") 
  PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SPT_DATA1" ;


  CREATE INDEX "DART_B2B2"."PROG_ID_3_ID_IDX" ON "DART_B2B2"."MANUAL_LEADDAYS_FOR_INTL" ("PROG_ID") 
  PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SPT_DATA1" ;


  CREATE INDEX "DART_B2B2"."RDPHT_CUST_STN_ID_IDX" ON "DART_B2B2"."RDPH_TEMP" ("CONTRACT_STATUS_LKP_ID") 
  PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SPT_DATA1" ;


  CREATE INDEX "DART_B2B2"."RDPHT_ID_IDX" ON "DART_B2B2"."RDPH_TEMP" ("RPM_REQUEST_ID") 
  PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SPT_DATA1" ;


  CREATE INDEX "DART_B2B2"."RDPH_ACT_ID_IDX" ON "DART_B2B2"."RPM_DEAL_PRODUCT_HISTORICAL" ("ID") 
  PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SPT_DATA1" ;


  CREATE INDEX "DART_B2B2"."RDPH_ACT_LKP_ID_IDX" ON "DART_B2B2"."RPM_DEAL_PRODUCT_HISTORICAL" ("ACTION_LKP_ID") 
  PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SPT_DATA1" ;


  CREATE INDEX "DART_B2B2"."RDPH_CUST_NAME_IDX" ON "DART_B2B2"."RPM_DEAL_PRODUCT_HISTORICAL" ("CUSTOMER_NAME") 
  PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SPT_DATA1" ;


  CREATE INDEX "DART_B2B2"."RDPH_CUST_NO_IDX" ON "DART_B2B2"."RPM_DEAL_PRODUCT_HISTORICAL" ("CUSTOMER_NO") 
  PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SPT_DATA1" ;


  CREATE INDEX "DART_B2B2"."RDPH_CUST_NO_ISP_IDX" ON "DART_B2B2"."RPM_DEAL_PRODUCT_HISTORICAL" ("IS_PROCESSED") 
  PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SPT_DATA1" ;


  CREATE INDEX "DART_B2B2"."RDPH_EX_END_DT_IDX" ON "DART_B2B2"."RPM_DEAL_PRODUCT_HISTORICAL" ("EXHIBITION_END_DT") 
  PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SPT_DATA1" ;


  CREATE INDEX "DART_B2B2"."RDPH_EX_ST_DT_IDX" ON "DART_B2B2"."RPM_DEAL_PRODUCT_HISTORICAL" ("EXHIBITION_ST_DT") 
  PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SPT_DATA1" ;


  CREATE INDEX "DART_B2B2"."RDPH_INI_DATA_IDX" ON "DART_B2B2"."RPM_DEAL_PRODUCT_HISTORICAL" ("IS_INITIAL_DATA") 
  PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SPT_DATA1" ;


  CREATE INDEX "DART_B2B2"."RDPH_PROG_ID_IDX" ON "DART_B2B2"."RPM_DEAL_PRODUCT_HISTORICAL" ("PROG_ID") 
  PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SPT_DATA1" ;


  CREATE INDEX "DART_B2B2"."RDPH_SEAS_ID_IDX" ON "DART_B2B2"."RPM_DEAL_PRODUCT_HISTORICAL" ("SEAS_ID") 
  PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SPT_DATA1" ;


  CREATE INDEX "DART_B2B2"."RDPH_STN_NAME_IDX" ON "DART_B2B2"."RPM_DEAL_PRODUCT_HISTORICAL" ("STATION_NAME") 
  PCTFREE 10 INITRANS 2 MAXTRANS 167 COMPUTE STATISTICS 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SPT_DATA1" ;


  CREATE INDEX "DART_B2B2"."RDPH_TITLE_STS_IDX" ON "DART_B2B2"."RPM_DEAL_PRODUCT_HISTORICAL" ("TITLE_STATUS") 
  PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SPT_DATA1" ;


  CREATE INDEX "DART_B2B2"."RDPM_IS_PLLKP_IDX" ON "DART_B2B2"."RPM_DEAL_PRODUCT_HISTORICAL" ("PRIMARY_LANGUAGE_LKP_ID") 
  PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SPT_DATA1" ;


  CREATE INDEX "DART_B2B2"."RDPM_IS_PMLKP_IDX" ON "DART_B2B2"."RPM_DEAL_PRODUCT_HISTORICAL" ("PRIMARY_MEDIA_LKP_ID") 
  PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SPT_DATA1" ;


  CREATE INDEX "DART_B2B2"."RDPM_IS_PTLKP_IDX" ON "DART_B2B2"."RPM_DEAL_PRODUCT_HISTORICAL" ("PRIMARY_TERRITORY_LKP_ID") 
  PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SPT_DATA1" ;


  CREATE INDEX "DART_B2B2"."RDPST_GPMS_PROG_ID" ON "DART_B2B2"."RPM_DEAL_PRODUCT_STITCHED" ("GPMS_PROG_ID") 
  PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SPT_DATA1" ;


  CREATE INDEX "DART_B2B2"."RDPST_GPMS_PROG_ID_H" ON "DART_B2B2"."RPM_DEAL_PRODUCT_STITCHED_HIST" ("GPMS_PROG_ID") 
  PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SPT_DATA1" ;


  CREATE INDEX "DART_B2B2"."RDPST_GPMS_SEAS_ID" ON "DART_B2B2"."RPM_DEAL_PRODUCT_STITCHED" ("GPMS_SEAS_ID") 
  PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SPT_DATA1" ;


  CREATE INDEX "DART_B2B2"."RDPST_GPMS_SEAS_ID_H" ON "DART_B2B2"."RPM_DEAL_PRODUCT_STITCHED_HIST" ("GPMS_SEAS_ID") 
  PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SPT_DATA1" ;


  CREATE INDEX "DART_B2B2"."RDPST_RPM_STATION_ID" ON "DART_B2B2"."RPM_DEAL_PRODUCT_STITCHED" ("RPM_STATION_ID") 
  PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SPT_DATA1" ;


  CREATE INDEX "DART_B2B2"."RDPST_RPM_STATION_ID_H" ON "DART_B2B2"."RPM_DEAL_PRODUCT_STITCHED_HIST" ("RPM_STATION_ID") 
  PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SPT_DATA1" ;


  CREATE INDEX "DART_B2B2"."RDP_GPMS_PROG_ID" ON "DART_B2B2"."RPM_DEAL_PRODUCT" ("GPMS_PROG_ID") 
  PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SPT_DATA1" ;


  CREATE INDEX "DART_B2B2"."RDP_GPMS_SEAS_ID" ON "DART_B2B2"."RPM_DEAL_PRODUCT" ("GPMS_SEAS_ID") 
  PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SPT_DATA1" ;


  CREATE INDEX "DART_B2B2"."RDP_GP_PROG_ID" ON "DART_B2B2"."RPM_DEAL_PRODUCT_HISTORICAL" ("GPMS_PROG_ID") 
  PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SPT_DATA1" ;


  CREATE INDEX "DART_B2B2"."RDP_GP_SEAS_ID" ON "DART_B2B2"."RPM_DEAL_PRODUCT_HISTORICAL" ("GPMS_SEAS_ID") 
  PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SPT_DATA1" ;


  CREATE INDEX "DART_B2B2"."RDP_RPM_STATION_ID" ON "DART_B2B2"."RPM_DEAL_PRODUCT" ("RPM_STATION_ID") 
  PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SPT_DATA1" ;


  CREATE INDEX "DART_B2B2"."RDP_RPM_STAT_ID" ON "DART_B2B2"."RPM_DEAL_PRODUCT_HISTORICAL" ("RPM_STATION_ID") 
  PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SPT_DATA1" ;


  CREATE INDEX "DART_B2B2"."RDTMH_LICE_ID_IDX" ON "DART_B2B2"."RPM_DEAL_TERRITORY_MEDIA_HIST" ("LICENSE_LKP_ID") 
  PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SPT_DATA1" ;


  CREATE INDEX "DART_B2B2"."RDTMH_MDA_ID_IDX" ON "DART_B2B2"."RPM_DEAL_TERRITORY_MEDIA_HIST" ("MEDIA_ID") 
  PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SPT_DATA1" ;


  CREATE INDEX "DART_B2B2"."RDTMH_REQ_ID_IDX" ON "DART_B2B2"."RPM_DEAL_TERRITORY_MEDIA_HIST" ("RPM_REQUEST_ID") 
  PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SPT_DATA1" ;


  CREATE INDEX "DART_B2B2"."RDTMH_TER_ID_IDX" ON "DART_B2B2"."RPM_DEAL_TERRITORY_MEDIA_HIST" ("TERRITORY_ID") 
  PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SPT_DATA1" ;


  CREATE INDEX "DART_B2B2"."RPDPS_CLOUT_IDX" ON "DART_B2B2"."RPM_DEAL_PRODUCT_STITCHED_HIST" ("CREDIT_LOCKOUT") 
  PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SPT_DATA1" ;


  CREATE INDEX "DART_B2B2"."RPDPS_DBYDT_IDX" ON "DART_B2B2"."RPM_DEAL_PRODUCT_STITCHED_HIST" ("DELIVER_BY_DT") 
  PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SPT_DATA1" ;


  CREATE INDEX "DART_B2B2"."RPDPS_EEDT_IDX" ON "DART_B2B2"."RPM_DEAL_PRODUCT_STITCHED_HIST" ("EXHIBITION_END_DT") 
  PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SPT_DATA1" ;


  CREATE INDEX "DART_B2B2"."RPDPS_ESDT_IDX" ON "DART_B2B2"."RPM_DEAL_PRODUCT_STITCHED_HIST" ("EXHIBITION_ST_DT") 
  PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SPT_DATA1" ;


  CREATE INDEX "DART_B2B2"."RPDPS_PID_IDX" ON "DART_B2B2"."RPM_DEAL_PRODUCT_STITCHED_HIST" ("PROG_ID") 
  PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SPT_DATA1" ;


  CREATE INDEX "DART_B2B2"."RPDPS_PNAME_IDX" ON "DART_B2B2"."RPM_DEAL_PRODUCT_STITCHED_HIST" ("PROG_NAME") 
  PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SPT_DATA1" ;


  CREATE INDEX "DART_B2B2"."RPDPS_SEASID_IDX" ON "DART_B2B2"."RPM_DEAL_PRODUCT_STITCHED_HIST" ("SEAS_ID") 
  PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SPT_DATA1" ;


  CREATE INDEX "DART_B2B2"."RPDPS_SP_IDX" ON "DART_B2B2"."RPM_DEAL_PRODUCT_STITCHED_HIST" ("SALES_PERSON") 
  PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SPT_DATA1" ;


  CREATE INDEX "DART_B2B2"."RPDPS_STN_SNAME_IDX" ON "DART_B2B2"."RPM_DEAL_PRODUCT_STITCHED_HIST" ("STATION_NAME") 
  PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SPT_DATA1" ;


  CREATE INDEX "DART_B2B2"."RPDPS_STN_STID_IDX" ON "DART_B2B2"."RPM_DEAL_PRODUCT_STITCHED_HIST" ("STATION_ID") 
  PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SPT_DATA1" ;


  CREATE INDEX "DART_B2B2"."RPDS_STN_ID_IDX" ON "DART_B2B2"."RPM_DEAL_PRODUCT_STATION_HIST" ("RPM_REQUEST_ID") 
  PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SPT_DATA1" ;


  CREATE INDEX "DART_B2B2"."RPDS_STN_NA_IDX" ON "DART_B2B2"."RPM_DEAL_PRODUCT_STATION_HIST" ("B2B_STATION_ID") 
  PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SPT_DATA1" ;


  CREATE UNIQUE INDEX "DART_B2B2"."RPM_JSON_ID" ON "DART_B2B2"."RPM_JSON_LOG" ("RPM_JSON_ID") 
  PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SPT_DATA1" ;


  CREATE UNIQUE INDEX "DART_B2B2"."RPM_JSON_ID_SYND" ON "DART_B2B2"."RPM_JSON_LOG_SYND" ("RPM_JSON_ID") 
  PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SPT_DATA1" ;


  CREATE INDEX "DART_B2B2"."RPM_REQUEST_ID" ON "DART_B2B2"."RPM_JSON_LOG" ("RPM_REQUEST_ID") 
  PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SPT_DATA1" ;


  CREATE INDEX "DART_B2B2"."RPM_REQUEST_ID_2_IDX" ON "DART_B2B2"."RPM_DEAL_TERRITORY_MEDIA" ("RPM_REQUEST_ID") 
  PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SPT_DATA1" ;


  CREATE INDEX "DART_B2B2"."RPM_REQUEST_ID_3_IDX" ON "DART_B2B2"."PROG_MANAGE_ACCESS_INTL" ("RPM_REQUEST_ID") 
  PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SPT_DATA1" ;


  CREATE INDEX "DART_B2B2"."RPM_REQUEST_ID_IDX" ON "DART_B2B2"."RPM_DEAL_PRODUCT" ("RPM_REQUEST_ID") 
  PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SPT_DATA1" ;


  CREATE INDEX "DART_B2B2"."RPM_REQUEST_ID_SYND" ON "DART_B2B2"."RPM_JSON_LOG_SYND" ("RPM_REQUEST_ID") 
  PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SPT_DATA1" ;


  CREATE INDEX "DART_B2B2"."RPM_REQU_ID_IDX" ON "DART_B2B2"."RPM_DEAL_PRODUCT_HISTORICAL" ("RPM_REQUEST_ID") 
  PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SPT_DATA1" ;


  CREATE INDEX "DART_B2B2"."RPM_TER_MEDIA_ID_IDX" ON "DART_B2B2"."RPM_DEAL_TERRITORY_MEDIA_LANG" ("RPM_TER_MEDIA_ID") 
  PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SPT_DATA1" ;


  CREATE UNIQUE INDEX "DART_B2B2"."SYS_C007202" ON "DART_B2B2"."RPM_DEAL_TERRITORY_MEDIA_STG" ("RPM_TER_MEDIA_ID") 
  PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SPT_DATA1" ;


  CREATE UNIQUE INDEX "DART_B2B2"."SYS_C007204" ON "DART_B2B2"."INTL_STATION_HISTORICAL" ("STATION_ID") 
  PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SPT_DATA1" ;


  CREATE UNIQUE INDEX "DART_B2B2"."SYS_C007236" ON "DART_B2B2"."RPM_DEAL_PRODUCT_STITCHED_HIST" ("RPM_STITCHED_ID") 
  PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SPT_DATA1" ;


  CREATE UNIQUE INDEX "DART_B2B2"."SYS_C007245" ON "DART_B2B2"."RPM_AUDIT_EMAIL" ("AUDIT_ID") 
  PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SPT_DATA1" ;


  CREATE UNIQUE INDEX "DART_B2B2"."SYS_C007306" ON "DART_B2B2"."RPM_DEAL_PRODUCT_STG" ("STG_ID") 
  PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SPT_DATA1" ;


  CREATE UNIQUE INDEX "DART_B2B2"."SYS_C007309" ON "DART_B2B2"."INTL_CUSTOMER_HISTORICAL" ("CUST_ID") 
  PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SPT_DATA1" ;


  CREATE UNIQUE INDEX "DART_B2B2"."SYS_C007331" ON "DART_B2B2"."RPM_TERRITORY" ("TERRITORY_ID") 
  PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SPT_DATA1" ;


  CREATE UNIQUE INDEX "DART_B2B2"."SYS_C007339" ON "DART_B2B2"."INTL_CUSTOMER" ("CUST_ID") 
  PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SPT_DATA1" ;


  CREATE UNIQUE INDEX "DART_B2B2"."SYS_C007353" ON "DART_B2B2"."RPM_LANGUAGE" ("LANGUAGE_ID") 
  PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SPT_DATA1" ;


  CREATE UNIQUE INDEX "DART_B2B2"."SYS_C007360" ON "DART_B2B2"."INTL_STATION" ("STATION_ID") 
  PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SPT_DATA1" ;


  CREATE UNIQUE INDEX "DART_B2B2"."SYS_C007390" ON "DART_B2B2"."RPM_DEAL_PRODUCT_STITCHED" ("RPM_STITCHED_ID") 
  PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SPT_DATA1" ;


  CREATE UNIQUE INDEX "DART_B2B2"."SYS_C007429" ON "DART_B2B2"."RPM_DEAL_TERRITORY_MEDIA" ("RPM_TER_MEDIA_ID") 
  PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SPT_DATA1" ;


  CREATE UNIQUE INDEX "DART_B2B2"."SYS_C007447" ON "DART_B2B2"."RDPH_TEMP" ("RPM_REQUEST_ID", "CONTRACT_STATUS_LKP_ID") 
  PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SPT_DATA1" ;


  CREATE UNIQUE INDEX "DART_B2B2"."SYS_C007471" ON "DART_B2B2"."PROG_MANAGE_ACCESS_INTL" ("ACCESS_ID") 
  PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SPT_DATA1" ;


  CREATE UNIQUE INDEX "DART_B2B2"."SYS_C007473" ON "DART_B2B2"."RPM_DEAL_TERRITORY_MEDIA_LANG" ("RPM_TER_MEDIA_LANG_ID") 
  PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SPT_DATA1" ;


  CREATE UNIQUE INDEX "DART_B2B2"."SYS_C007476" ON "DART_B2B2"."RDP_TCL" ("GPMS_PROG_ID", "GPMS_SEAS_ID", "B2B_STATION_ID") 
  PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SPT_DATA1" ;


  CREATE UNIQUE INDEX "DART_B2B2"."SYS_C007493" ON "DART_B2B2"."RPM_MEDIA" ("MEDIA_ID") 
  PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SPT_DATA1" ;


  CREATE UNIQUE INDEX "DART_B2B2"."SYS_C0087296" ON "DART_B2B2"."SYNDICATION_STATION_MASTER" ("STATION_ID") 
  PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SPT_DATA1" ;


  CREATE UNIQUE INDEX "DART_B2B2"."SYS_C0087299" ON "DART_B2B2"."SYNDICATION_CUSTOMER" ("CUST_ID") 
  PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SPT_DATA1" ;


  CREATE INDEX "DART_B2B2"."TCL_B2BSID_IDX" ON "DART_B2B2"."RDP_TCL" ("B2B_STATION_ID") 
  PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SPT_DATA1" ;


  CREATE INDEX "DART_B2B2"."TCL_CSTID_IDX" ON "DART_B2B2"."RDP_TCL" ("CONTRACT_STATUS_TYPE_CSV") 
  PCTFREE 10 INITRANS 2 MAXTRANS 167 COMPUTE STATISTICS 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SPT_DATA1" ;


  CREATE INDEX "DART_B2B2"."TCL_CSVID_IDX" ON "DART_B2B2"."RDP_TCL" ("CONTRACT_STATUS_VALUE_CSV") 
  PCTFREE 10 INITRANS 2 MAXTRANS 167 COMPUTE STATISTICS 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SPT_DATA1" ;


  CREATE INDEX "DART_B2B2"."TCL_LTID_IDX" ON "DART_B2B2"."RDP_TCL" ("LICENSE_TYPE_ID_CSV") 
  PCTFREE 10 INITRANS 2 MAXTRANS 167 COMPUTE STATISTICS 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SPT_DATA1" ;


  CREATE INDEX "DART_B2B2"."TCL_LTV_IDX" ON "DART_B2B2"."RDP_TCL" ("LICENSE_TYPE_VALUE_CSV") 
  PCTFREE 10 INITRANS 2 MAXTRANS 167 COMPUTE STATISTICS 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SPT_DATA1" ;


  CREATE INDEX "DART_B2B2"."TCL_PID_IDX" ON "DART_B2B2"."RDP_TCL" ("GPMS_PROG_ID") 
  PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SPT_DATA1" ;


  CREATE INDEX "DART_B2B2"."TCL_SID_IDX" ON "DART_B2B2"."RDP_TCL" ("GPMS_SEAS_ID") 
  PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SPT_DATA1" ;


  CREATE INDEX "DART_B2B2"."TCL_TIID_IDX" ON "DART_B2B2"."RDP_TCL" ("TERRITORY_ID_CSV") 
  PCTFREE 10 INITRANS 2 MAXTRANS 167 COMPUTE STATISTICS 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SPT_DATA1" ;


  CREATE INDEX "DART_B2B2"."TCL_TVID_IDX" ON "DART_B2B2"."RDP_TCL" ("TERRITORY_VALUE_CSV") 
  PCTFREE 10 INITRANS 2 MAXTRANS 167 COMPUTE STATISTICS 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SPT_DATA1" ;


  CREATE INDEX "DART_B2B2"."TERRITORY_ID_3_IDX" ON "DART_B2B2"."PROG_MANAGE_ACCESS_INTL" ("TERRITORY_ID") 
  PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SPT_DATA1" ;


  CREATE INDEX "DART_B2B2"."TERRITORY_ID_IDX" ON "DART_B2B2"."RPM_DEAL_TERRITORY_MEDIA" ("TERRITORY_ID") 
  PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SPT_DATA1" ;


  CREATE INDEX "DART_B2B2"."TERR_NAM_ID_IDX" ON "DART_B2B2"."RPM_TERRITORY_HIST" ("TERRITORY_NAME") 
  PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SPT_DATA1" ;


  CREATE INDEX "DART_B2B2"."TERR_NM_ID_IDX" ON "DART_B2B2"."RPM_TERRITORY_HIST" ("TERRITORY_ID") 
  PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SPT_DATA1" ;


  CREATE OR REPLACE EDITIONABLE PROCEDURE "DART_B2B2"."DELETE_DUPLICATE" As
cursor deal is
  select rpm_station_id,gpms_prog_id, gpms_seas_id,count(*) from RPM_DEAL_PRODUCT_STITCHED group by rpm_station_id,gpms_prog_id, gpms_seas_id having count(*)=2;
begin
	for i in deal 
		loop  
			 delete from RPM_DEAL_PRODUCT_STITCHED where rpm_station_id = i.rpm_station_id and gpms_prog_id = i.gpms_prog_id and gpms_seas_id = i.gpms_seas_id;   
			 commit;   
		end loop;   
end delete_duplicate;
/


  CREATE OR REPLACE EDITIONABLE PROCEDURE "DART_B2B2"."MIGRATE_DATA_TO_DEAL_PRODUCT" AS 
cursor deal is
	select * from TEMP_RPM_SYNDICATION_DATA where rownum <= 10; 
  
rpm_station_id number(10) := 0;	 

begin
	for i in deal 
		loop  
       existing_records := 0;
			 select count(*) into existing_records from rpm_deal_product_synd where rpm_request_id = i.rpm_request_id;   
		end loop;  
END MIGRATE_DATA_TO_DEAL_PRODUCT;
/


  CREATE OR REPLACE EDITIONABLE PROCEDURE "DART_B2B2"."MIGRATE_DATA_TO_DEAL_PRODUCT_SYND" 
IS 
cursor deal is
	select * from dtv_b2b2.TEMP_RPM_SYNDICATION_DATA2 where STATIONNAME in('KOKI (COX TELEVISION TULSA, LLC)', 
'KCRG (GRAY TELEVISION LICENSEE, LLC)',
'WNAC (WNAC, LLC)',
'WLUK (WLUK LICENSEE, LLC)',
'WLFL (SINCLAIR BROADCAST GROUP)',
'WSFL (SCRIPPS HOWARD BCSTG. CO.)',
'WFLI (SINCLAIR BROADCAST GROUP)',
'KTTV (FOX TELEVISION STATIONS, INC.)',
'WISC (MORGAN MURPHY STATIONS)');
existing_records number;
begin
	for i in deal 
		loop  
		existing_records := 0;  
		select count(*) into existing_records from dart_b2b2.rpm_deal_product_synd where rpm_request_id = i.rpmrequestid;  
		 delete from dart_b2b2.RPM_DEAL_PRODUCT_STATION_SYND where rpm_request_id = i.rpmrequestid;  
		 if existing_records > 0 then  
			update dart_b2b2.rpm_deal_product_synd set COMMENTS=TRIM(i.COMMENTS),   
				CONTRACT_NO=TRIM(i.CONTRACTNO), CUSTOMER_NAME=TRIM(i.CUSTOMERNAME), DEAL_PRODUCT_ID=i.DEALPRODUCTID, DELIVER_BY_DT=TO_DATE(i.DELIVERBYDATE, 'YYYY-MM-DD'),DELIVERY_LEAD_DAYS=DECODE(i.DELIVERYLEADDAYS, null, '120', i.DELIVERYLEADDAYS),EIDR_ID=i.EIDRID,    
				EXHIBITION_END_DT=CAST(i.EXHIBITIONENDDATE as DATE), EXHIBITION_ST_DT= CAST(i.EXHIBITIONSTARTDATE as DATE),GPMS_PRODUCT_ID=i.GPMSPRODUCTID,MPM_NO=i.MPMNO,ORDER_DESC=TRIM(i.ORDERDESCRIPTION),ORDER_NO=i.ORDERNO,PRIMARY_LANGUAGE_LKP_ID=i.PRIMARYLANGUAGEID,PRIMARY_MEDIA_LKP_ID=i.PRIMARYMEDIAID,    
				PRIMARY_TERRITORY_LKP_ID=i.PRIMARYTERRITORYID, SALES_PERSON=TRIM(i.SALESPERSON), SOURCE_SYSTEM=i.SOURCESYSTEM, STATION_NAME = TRIM(NVL(SUBSTR(i.STATIONNAME, 0, INSTR(i.STATIONNAME, '(')-1), i.STATIONNAME)), SOURCE_STATION_NAME= TRIM(i.STATIONNAME), SUB_DUB_LKP_ID=null, TERM_YEAR_DESC= TRIM(i.TERMYEARDESCRIPTION), TERM_YEAR_NO=i.TERMYEARNUMBER, TERM_YEAR_STATUS=TRIM(i.TERMYEARSTATUS),    
				TITLE_STATUS=TRIM(i.TITLESTATUS), CREATED_DT=sysdate, LAST_UPDATED_DT=sysdate, CREATED_BY='Migration', LAST_UPDATED_BY='Migration', RPM_STATION_ID=i.STATIONID, CUSTOMER_NO=TRIM(i.CUSTOMERNUMBER), AGREEMENT_ID=i.AGREEMENTID,    
				LICENSE_FEE=i.LICENSEFEE, LICENSE_FEE_CURRENCY=i.LICENSEFEECURRENCY, SUB_DUB_REQUESTED=null, KEY_CATEGORY=i.KEYCATEGORY, PRICE_CATEGORY=i.PRICECATEGORY, MARKET=i.MARKET, AGREEMENT_TYPE=TRIM(i.AGREEMENTTYPE), DEAL_TYPE=TRIM(i.DEALTYPE), SYNDICATION_RUNS=null, CONTRACT_STATUS=TRIM(i.CONTRACTSTATUS),     
				ACTION_LKP_ID = null,    
				CONTRACT_STATUS_LKP_ID = null,    
				GPMS_PROG_ID = 0,    
				GPMS_SEAS_ID = 0,    
				GPMS_EPS_ID = 0,    
				PROG_TYPE= null,    
				PROG_NAME= null,    
        PACKAGE_ID=TRIM(i.PACKAGEID),
        PACKAGE_NAME=TRIM(i.PACKAGENAME)
				where rpm_request_id = i.rpmrequestid;    
		 else  
			insert into dart_b2b2.rpm_deal_product_synd(RPM_REQUEST_ID,COMMENTS,CONTRACT_NO,CUSTOMER_NAME,DEAL_PRODUCT_ID,DELIVER_BY_DT,DELIVERY_LEAD_DAYS,EIDR_ID,   
				EXHIBITION_END_DT,EXHIBITION_ST_DT,GPMS_PRODUCT_ID,MPM_NO,ORDER_DESC,ORDER_NO,PRIMARY_LANGUAGE_LKP_ID,PRIMARY_MEDIA_LKP_ID,    
				PRIMARY_TERRITORY_LKP_ID,SALES_PERSON,SOURCE_SYSTEM,STATION_NAME,SOURCE_STATION_NAME,SUB_DUB_LKP_ID,TERM_YEAR_DESC,TERM_YEAR_NO,TERM_YEAR_STATUS,    
				TITLE_STATUS,CREATED_DT,LAST_UPDATED_DT,CREATED_BY,LAST_UPDATED_BY,RPM_STATION_ID,CUSTOMER_NO,AGREEMENT_ID,    
				LICENSE_FEE,LICENSE_FEE_CURRENCY,SUB_DUB_REQUESTED,KEY_CATEGORY,PRICE_CATEGORY,MARKET,AGREEMENT_TYPE,DEAL_TYPE,SYNDICATION_RUNS,CONTRACT_STATUS,    
				ACTION_LKP_ID,CONTRACT_STATUS_LKP_ID,GPMS_PROG_ID,GPMS_SEAS_ID,GPMS_EPS_ID,PROG_TYPE,PROG_NAME,PACKAGE_ID,PACKAGE_NAME)    
				values(i.RPMREQUESTID,TRIM(i.COMMENTS),i.CONTRACTNO,TRIM(i.CUSTOMERNAME),i.DEALPRODUCTID,TO_DATE(i.DELIVERBYDATE, 'YYYY-MM-DD'),DECODE(i.DELIVERYLEADDAYS, null, '120', i.DELIVERYLEADDAYS),i.EIDRID,CAST(i.EXHIBITIONENDDATE as DATE),CAST(i.EXHIBITIONSTARTDATE as DATE),    
				i.GPMSPRODUCTID,i.MPMNO,TRIM(i.ORDERDESCRIPTION),i.ORDERNO,i.PRIMARYLANGUAGEID,i.PRIMARYMEDIAID,    
				i.PRIMARYTERRITORYID,TRIM(i.SALESPERSON),i.SOURCESYSTEM,TRIM(NVL(SUBSTR(i.STATIONNAME, 0, INSTR(i.STATIONNAME, '(')-1), i.STATIONNAME)),TRIM(i.STATIONNAME),null,TRIM(i.TERMYEARDESCRIPTION),i.TERMYEARNUMBER,TRIM(i.TERMYEARSTATUS),    
				TRIM(i.TITLESTATUS),sysdate,sysdate,'Migration','Migration',i.STATIONID,TRIM(i.CUSTOMERNUMBER),i.AGREEMENTID,    
				i.LICENSEFEE,i.LICENSEFEECURRENCY,null,i.KEYCATEGORY,i.PRICECATEGORY,i.MARKET,TRIM(i.AGREEMENTTYPE),TRIM(i.DEALTYPE),null,TRIM(i.CONTRACTSTATUS),    
				null,    
				null,    
				0,    
				0,    
				0,    
				null,    
				null,    
        TRIM(i.PACKAGEID),
        TRIM(i.PACKAGENAME));
		 end if;   
		    insert into dart_b2b2.RPM_DEAL_PRODUCT_STATION_SYND  
			select i.rpmrequestid, ssm.station_id from dart_b2b2.syndication_station_master ssm where ssm.synd_station_id in (WITH DATA AS(   
			SELECT temp.stationid str FROM dtv_b2b2.TEMP_RPM_SYNDICATION_DATA2 temp    
				where rpmrequestid = i.rpmrequestid)    
				SELECT regexp_substr(str,'[^;]+',1,level) str    
				FROM DATA    
				CONNECT BY regexp_substr(str, '[^;]+', 1, level) IS NOT NULL);    
      commit;
		end loop;           
END MIGRATE_DATA_TO_DEAL_PRODUCT_SYND;
/


  CREATE OR REPLACE EDITIONABLE PROCEDURE "DART_B2B2"."MIGRATE_DATA_TO_DEAL_PRODUCT_SYND_BATCH_1" 
IS 
cursor deal is
	select * from dtv_b2b2.TEMP_RPM_SYNDICATION_DATA2 where STATIONNAME in('Syndication Customer','KOKI (COX TELEVISION TULSA, LLC)','KCRG (GRAY TELEVISION LICENSEE, LLC)','WNAC (WNAC, LLC)','WLUK (WLUK LICENSEE, LLC)','WLFL (SINCLAIR BROADCAST GROUP)','WSFL (SCRIPPS HOWARD BCSTG. CO.)','WFLI (SINCLAIR BROADCAST GROUP)','KTTV (FOX TELEVISION STATIONS, INC.)','WISC (MORGAN MURPHY STATIONS)','WGMB (NEXSTAR MEDIA GROUP)','WXCW (SUN BROADCASTING, INC.)','WPIX (MISSION BROADCASTING, INC.)','WOLF (NEW AGE MEDIA OF PA, LLC)','KPTM (TTBG/KPTM LICENSE SUB, LLC)','WOOD (WOOD LICENSE COMPANY, LLC)','KXAN (NEXSTAR MEDIA GROUP)','WBFF (SINCLAIR BROADCAST GROUP)','WSAZ (GRAY COMMUNICATIONS SYSTEMS)','WTVO (MISSION BROADCASTING, INC.)','WZTV (SINCLAIR BROADCAST GROUP)','WABG (CALA BROADCAST PARTNERS LLC)','WDRB (BLOCK COMMUNICATIONS)','WJXT (GRAHAM MEDIA GROUP, INC.)','KFMB (KFMB-TV, LLC)','WVLT (GRAY COMMUNICATIONS SYSTEMS)','WKYT (GRAY COMMUNICATIONS SYSTEMS)','WCIU (WEIGEL BROADCASTING)','KNPN (NEWS- 
PRESS TV, LLC)','WAGM (GRAY TELEVISION LICENSEE, LLC)','KSTC (KSTC-TV, LLC)','WUPV (WUPV LICENSE SUBSIDIARY, LLC)','KMSB (TEGNA, INC.)','KTUU (GRAY TELEVISION LICENSE, LLC)','KJNB (Waypoint Media, LLC)','WPGH (SINCLAIR BROADCAST GROUP)','WSYT (BRISTLECONE BROADCASTING LLC)','KDVR (COMMUNITY TELEVISION OF CO LLC)','WSKY (TIDEWATER TV LLC)','KTVD (TEGNA, INC.)','WCWW (WEIGEL BROADCASTING)','WATM (PEAK MEDIA LLC)','WCIV (SINCLAIR BROADCAST GROUP)');
existing_records number;
begin
	for i in deal 
		loop  
		existing_records := 0;  
		select count(*) into existing_records from dart_b2b2.rpm_deal_product_synd where rpm_request_id = i.rpmrequestid;  
		 delete from dart_b2b2.RPM_DEAL_PRODUCT_STATION_SYND where rpm_request_id = i.rpmrequestid;  
		 if existing_records > 0 then  
			update dart_b2b2.rpm_deal_product_synd set COMMENTS=TRIM(i.COMMENTS),   
				CONTRACT_NO=TRIM(i.CONTRACTNO), CUSTOMER_NAME=TRIM(i.CUSTOMERNAME), DEAL_PRODUCT_ID=i.DEALPRODUCTID, DELIVER_BY_DT=TO_DATE(i.DELIVERBYDATE, 'YYYY-MM-DD'),DELIVERY_LEAD_DAYS=DECODE(i.DELIVERYLEADDAYS, null, '120', i.DELIVERYLEADDAYS),EIDR_ID=i.EIDRID,    
				EXHIBITION_END_DT=CAST(i.EXHIBITIONENDDATE as DATE), EXHIBITION_ST_DT= CAST(i.EXHIBITIONSTARTDATE as DATE),GPMS_PRODUCT_ID=i.GPMSPRODUCTID,MPM_NO=i.MPMNO,ORDER_DESC=TRIM(i.ORDERDESCRIPTION),ORDER_NO=i.ORDERNO,PRIMARY_LANGUAGE_LKP_ID=i.PRIMARYLANGUAGEID,PRIMARY_MEDIA_LKP_ID=i.PRIMARYMEDIAID,    
				PRIMARY_TERRITORY_LKP_ID=i.PRIMARYTERRITORYID, SALES_PERSON=TRIM(i.SALESPERSON), SOURCE_SYSTEM=i.SOURCESYSTEM, STATION_NAME = TRIM(NVL(SUBSTR(i.STATIONNAME, 0, INSTR(i.STATIONNAME, '(')-1), i.STATIONNAME)), SOURCE_STATION_NAME= TRIM(i.STATIONNAME), SUB_DUB_LKP_ID=null, TERM_YEAR_DESC= TRIM(i.TERMYEARDESCRIPTION), TERM_YEAR_NO=i.TERMYEARNUMBER, TERM_YEAR_STATUS=TRIM(i.TERMYEARSTATUS),    
				TITLE_STATUS=TRIM(i.TITLESTATUS), CREATED_DT=sysdate, LAST_UPDATED_DT=sysdate, CREATED_BY='Migration', LAST_UPDATED_BY='Migration', RPM_STATION_ID=i.STATIONID, CUSTOMER_NO=TRIM(i.CUSTOMERNUMBER), AGREEMENT_ID=i.AGREEMENTID,    
				LICENSE_FEE=i.LICENSEFEE, LICENSE_FEE_CURRENCY=i.LICENSEFEECURRENCY, SUB_DUB_REQUESTED=null, KEY_CATEGORY=i.KEYCATEGORY, PRICE_CATEGORY=i.PRICECATEGORY, MARKET=i.MARKET, AGREEMENT_TYPE=TRIM(i.AGREEMENTTYPE), DEAL_TYPE=TRIM(i.DEALTYPE), SYNDICATION_RUNS=null, CONTRACT_STATUS=TRIM(i.CONTRACTSTATUS),     
				ACTION_LKP_ID = null,    
				CONTRACT_STATUS_LKP_ID = null,    
				GPMS_PROG_ID = 0,    
				GPMS_SEAS_ID = 0,    
				GPMS_EPS_ID = 0,    
				PROG_TYPE= null,    
				PROG_NAME= null,    
        PACKAGE_ID=TRIM(i.PACKAGEID),
        PACKAGE_NAME=TRIM(i.PACKAGENAME)
				where rpm_request_id = i.rpmrequestid;    
		 else  
			insert into dart_b2b2.rpm_deal_product_synd(RPM_REQUEST_ID,COMMENTS,CONTRACT_NO,CUSTOMER_NAME,DEAL_PRODUCT_ID,DELIVER_BY_DT,DELIVERY_LEAD_DAYS,EIDR_ID,   
				EXHIBITION_END_DT,EXHIBITION_ST_DT,GPMS_PRODUCT_ID,MPM_NO,ORDER_DESC,ORDER_NO,PRIMARY_LANGUAGE_LKP_ID,PRIMARY_MEDIA_LKP_ID,    
				PRIMARY_TERRITORY_LKP_ID,SALES_PERSON,SOURCE_SYSTEM,STATION_NAME,SOURCE_STATION_NAME,SUB_DUB_LKP_ID,TERM_YEAR_DESC,TERM_YEAR_NO,TERM_YEAR_STATUS,    
				TITLE_STATUS,CREATED_DT,LAST_UPDATED_DT,CREATED_BY,LAST_UPDATED_BY,RPM_STATION_ID,CUSTOMER_NO,AGREEMENT_ID,    
				LICENSE_FEE,LICENSE_FEE_CURRENCY,SUB_DUB_REQUESTED,KEY_CATEGORY,PRICE_CATEGORY,MARKET,AGREEMENT_TYPE,DEAL_TYPE,SYNDICATION_RUNS,CONTRACT_STATUS,    
				ACTION_LKP_ID,CONTRACT_STATUS_LKP_ID,GPMS_PROG_ID,GPMS_SEAS_ID,GPMS_EPS_ID,PROG_TYPE,PROG_NAME,PACKAGE_ID,PACKAGE_NAME)    
				values(i.RPMREQUESTID,TRIM(i.COMMENTS),i.CONTRACTNO,TRIM(i.CUSTOMERNAME),i.DEALPRODUCTID,TO_DATE(i.DELIVERBYDATE, 'YYYY-MM-DD'),DECODE(i.DELIVERYLEADDAYS, null, '120', i.DELIVERYLEADDAYS),i.EIDRID,CAST(i.EXHIBITIONENDDATE as DATE),CAST(i.EXHIBITIONSTARTDATE as DATE),    
				i.GPMSPRODUCTID,i.MPMNO,TRIM(i.ORDERDESCRIPTION),i.ORDERNO,i.PRIMARYLANGUAGEID,i.PRIMARYMEDIAID,    
				i.PRIMARYTERRITORYID,TRIM(i.SALESPERSON),i.SOURCESYSTEM,TRIM(NVL(SUBSTR(i.STATIONNAME, 0, INSTR(i.STATIONNAME, '(')-1), i.STATIONNAME)),TRIM(i.STATIONNAME),null,TRIM(i.TERMYEARDESCRIPTION),i.TERMYEARNUMBER,TRIM(i.TERMYEARSTATUS),    
				TRIM(i.TITLESTATUS),sysdate,sysdate,'Migration','Migration',i.STATIONID,TRIM(i.CUSTOMERNUMBER),i.AGREEMENTID,    
				i.LICENSEFEE,i.LICENSEFEECURRENCY,null,i.KEYCATEGORY,i.PRICECATEGORY,i.MARKET,TRIM(i.AGREEMENTTYPE),TRIM(i.DEALTYPE),null,TRIM(i.CONTRACTSTATUS),    
				null,    
				null,    
				0,    
				0,    
				0,    
				null,    
				null,    
        TRIM(i.PACKAGEID),
        TRIM(i.PACKAGENAME));
		 end if;   
		    insert into dart_b2b2.RPM_DEAL_PRODUCT_STATION_SYND  
			select i.rpmrequestid, ssm.station_id from dart_b2b2.syndication_station_master ssm where ssm.synd_station_id in (WITH DATA AS(   
			SELECT temp.stationid str FROM dtv_b2b2.TEMP_RPM_SYNDICATION_DATA2 temp    
				where rpmrequestid = i.rpmrequestid)    
				SELECT regexp_substr(str,'[^;]+',1,level) str    
				FROM DATA    
				CONNECT BY regexp_substr(str, '[^;]+', 1, level) IS NOT NULL);    
      commit;
		end loop;           
END MIGRATE_DATA_TO_DEAL_PRODUCT_SYND_BATCH_1;
/


  CREATE OR REPLACE EDITIONABLE PROCEDURE "DART_B2B2"."MIGRATE_DATA_TO_DEAL_PRODUCT_SYND_BATCH_2" 
IS 
cursor deal is
	select * from dtv_b2b2.TEMP_RPM_SYNDICATION_DATA2 where STATIONNAME in('WJAX (BAYSHORE TELEVISION, LLC)','WMOR (HEARST TELEVISION INC.)','KTVU (FOX TELEVISION STATIONS, INC.)','KXLT (SAGAMOREHILL OF MINNESOTA, LLC)','KCWX (CORRIDOR BROADCASTING CORP.)','WNAB (NASHVILLE LICENSE HLDINGS, LLC)','WBNX (WINSTON BROADCASTING NETWORK,)','WJZY (NEXSTAR MEDIA GROUP)','WHPM (WHPM-TV, LLC)','WYTV (WYTV TELEVISION, LLC)','WRAL (CAPITOL BROADCASTING CO., INC.)','KCWI (TEGNA, INC.)','WPBY (Star City Broadcasting, LLC)','KLCW (COMMITTEE OF WB100+ BROADCSTRS)','KCRA (HEARST TELEVISION INC.)','WHAM (Deerfield Media)','WABM (SINCLAIR BROADCAST GROUP)','WESH (HEARST TELEVISION INC.)','KUBE (TTBG HOUSTON OP CO, LLC)','KTXL (NEXSTAR MEDIA GROUP)','WGNO (NEXSTAR MEDIA GROUP)','WPFO (CUNNINGHAM BROADCASTING)','KXRM (NEXSTAR MEDIA GROUP)','KWKT (NEXSTAR MEDIA GROUP)','WSIL (WSIL TV, INC.)','WSBK (CBS TELEVISION STATIONS)','KHII (NEXSTAR MEDIA GROUP)','KABB (SINCLAIR BROADCAST GROUP)','WSOC (COX COMMUNICATION 
S)','WRDQ (COX COMMUNICATIONS)','WHSV (GRAY COMMUNICATIONS SYSTEMS)','KOZL (NEXSTAR MEDIA GROUP)','KSTW (CBS TELEVISION STATIONS)','WXII (HEARST TELEVISION INC.)','WYDC (VISION COMMUNICATIONS, LLC)','WPTA (QUINCY BROADCASTING)','KVIA (NPG OF TEXAS, L.P.)','KLSR (CALIF)','WNYW (FOX TELEVISION STATIONS, INC.)','KARK (NEXSTAR MEDIA GROUP)','WWJ (CBS TELEVISION STATIONS)','WAXN (COX COMMUNICATIONS)','WTVW (MISSION BROADCASTING, INC.)','WVNS (NEXSTAR MEDIA GROUP)','WKRG (NEXSTAR MEDIA GROUP)','KSAS (KSAS LICENSEE, LLC)','WKBD (CBS TELEVISION STATIONS)','WITN (GRAY COMMUNICATIONS SYSTEMS)','KYW (CBS TELEVISION STATIONS)','WSPA (NEXSTAR MEDIA GROUP)','KTVL-DT2 (COMMITTEE OF WB100+ BRDCSTRS)','KIMO-DT2 (COMMITTEE OF WB100+ BRDCSTRS)','KXLF-DT2 (COMMITTEE OF WB100+ BRDCSTRS)','KWVB (COMMITTEE OF WB100+ BRDCSTRS)','KWZB (COMMITTEE OF WB100+ BRDCSTRS)','WNYT (WNYT-TV, LLC)','WFXR (NEXSTAR MEDIA GROUP)','WSMH (SINCLAIR BROADCAST GROUP)','KJTL (MISSION BROADCASTING, INC.)','WJTV (NEXSTAR MEDIA GROU
P)','WDTN (WDTN BROADCASTING, LLC)','WZDX (TEGNA, INC.)','WIS (WIS LICENSE SUBSIDIARY, LLC)','WSAW (GRAY TELEVISION LICENSEE, LLC)','KSTU (SCRIPPS HOWARD BCSTG. CO.)','KAVU (QUEENB TELEVISION OF TEXAS, LLC)');
existing_records number;
begin
	for i in deal 
		loop  
		existing_records := 0;  
		select count(*) into existing_records from dart_b2b2.rpm_deal_product_synd where rpm_request_id = i.rpmrequestid;  
		 delete from dart_b2b2.RPM_DEAL_PRODUCT_STATION_SYND where rpm_request_id = i.rpmrequestid;  
		 if existing_records > 0 then  
			update dart_b2b2.rpm_deal_product_synd set COMMENTS=TRIM(i.COMMENTS),   
				CONTRACT_NO=TRIM(i.CONTRACTNO), CUSTOMER_NAME=TRIM(i.CUSTOMERNAME), DEAL_PRODUCT_ID=i.DEALPRODUCTID, DELIVER_BY_DT=TO_DATE(i.DELIVERBYDATE, 'YYYY-MM-DD'),DELIVERY_LEAD_DAYS=DECODE(i.DELIVERYLEADDAYS, null, '120', i.DELIVERYLEADDAYS),EIDR_ID=i.EIDRID,    
				EXHIBITION_END_DT=CAST(i.EXHIBITIONENDDATE as DATE), EXHIBITION_ST_DT= CAST(i.EXHIBITIONSTARTDATE as DATE),GPMS_PRODUCT_ID=i.GPMSPRODUCTID,MPM_NO=i.MPMNO,ORDER_DESC=TRIM(i.ORDERDESCRIPTION),ORDER_NO=i.ORDERNO,PRIMARY_LANGUAGE_LKP_ID=i.PRIMARYLANGUAGEID,PRIMARY_MEDIA_LKP_ID=i.PRIMARYMEDIAID,    
				PRIMARY_TERRITORY_LKP_ID=i.PRIMARYTERRITORYID, SALES_PERSON=TRIM(i.SALESPERSON), SOURCE_SYSTEM=i.SOURCESYSTEM, STATION_NAME = TRIM(NVL(SUBSTR(i.STATIONNAME, 0, INSTR(i.STATIONNAME, '(')-1), i.STATIONNAME)), SOURCE_STATION_NAME= TRIM(i.STATIONNAME), SUB_DUB_LKP_ID=null, TERM_YEAR_DESC= TRIM(i.TERMYEARDESCRIPTION), TERM_YEAR_NO=i.TERMYEARNUMBER, TERM_YEAR_STATUS=TRIM(i.TERMYEARSTATUS),    
				TITLE_STATUS=TRIM(i.TITLESTATUS), CREATED_DT=sysdate, LAST_UPDATED_DT=sysdate, CREATED_BY='Migration', LAST_UPDATED_BY='Migration', RPM_STATION_ID=i.STATIONID, CUSTOMER_NO=TRIM(i.CUSTOMERNUMBER), AGREEMENT_ID=i.AGREEMENTID,    
				LICENSE_FEE=i.LICENSEFEE, LICENSE_FEE_CURRENCY=i.LICENSEFEECURRENCY, SUB_DUB_REQUESTED=null, KEY_CATEGORY=i.KEYCATEGORY, PRICE_CATEGORY=i.PRICECATEGORY, MARKET=i.MARKET, AGREEMENT_TYPE=TRIM(i.AGREEMENTTYPE), DEAL_TYPE=TRIM(i.DEALTYPE), SYNDICATION_RUNS=null, CONTRACT_STATUS=TRIM(i.CONTRACTSTATUS),     
				ACTION_LKP_ID = null,    
				CONTRACT_STATUS_LKP_ID = null,    
				GPMS_PROG_ID = 0,    
				GPMS_SEAS_ID = 0,    
				GPMS_EPS_ID = 0,    
				PROG_TYPE= null,    
				PROG_NAME= null,    
        PACKAGE_ID=TRIM(i.PACKAGEID),
        PACKAGE_NAME=TRIM(i.PACKAGENAME)
				where rpm_request_id = i.rpmrequestid;    
		 else  
			insert into dart_b2b2.rpm_deal_product_synd(RPM_REQUEST_ID,COMMENTS,CONTRACT_NO,CUSTOMER_NAME,DEAL_PRODUCT_ID,DELIVER_BY_DT,DELIVERY_LEAD_DAYS,EIDR_ID,   
				EXHIBITION_END_DT,EXHIBITION_ST_DT,GPMS_PRODUCT_ID,MPM_NO,ORDER_DESC,ORDER_NO,PRIMARY_LANGUAGE_LKP_ID,PRIMARY_MEDIA_LKP_ID,    
				PRIMARY_TERRITORY_LKP_ID,SALES_PERSON,SOURCE_SYSTEM,STATION_NAME,SOURCE_STATION_NAME,SUB_DUB_LKP_ID,TERM_YEAR_DESC,TERM_YEAR_NO,TERM_YEAR_STATUS,    
				TITLE_STATUS,CREATED_DT,LAST_UPDATED_DT,CREATED_BY,LAST_UPDATED_BY,RPM_STATION_ID,CUSTOMER_NO,AGREEMENT_ID,    
				LICENSE_FEE,LICENSE_FEE_CURRENCY,SUB_DUB_REQUESTED,KEY_CATEGORY,PRICE_CATEGORY,MARKET,AGREEMENT_TYPE,DEAL_TYPE,SYNDICATION_RUNS,CONTRACT_STATUS,    
				ACTION_LKP_ID,CONTRACT_STATUS_LKP_ID,GPMS_PROG_ID,GPMS_SEAS_ID,GPMS_EPS_ID,PROG_TYPE,PROG_NAME,PACKAGE_ID,PACKAGE_NAME)    
				values(i.RPMREQUESTID,TRIM(i.COMMENTS),i.CONTRACTNO,TRIM(i.CUSTOMERNAME),i.DEALPRODUCTID,TO_DATE(i.DELIVERBYDATE, 'YYYY-MM-DD'),DECODE(i.DELIVERYLEADDAYS, null, '120', i.DELIVERYLEADDAYS),i.EIDRID,CAST(i.EXHIBITIONENDDATE as DATE),CAST(i.EXHIBITIONSTARTDATE as DATE),    
				i.GPMSPRODUCTID,i.MPMNO,TRIM(i.ORDERDESCRIPTION),i.ORDERNO,i.PRIMARYLANGUAGEID,i.PRIMARYMEDIAID,    
				i.PRIMARYTERRITORYID,TRIM(i.SALESPERSON),i.SOURCESYSTEM,TRIM(NVL(SUBSTR(i.STATIONNAME, 0, INSTR(i.STATIONNAME, '(')-1), i.STATIONNAME)),TRIM(i.STATIONNAME),null,TRIM(i.TERMYEARDESCRIPTION),i.TERMYEARNUMBER,TRIM(i.TERMYEARSTATUS),    
				TRIM(i.TITLESTATUS),sysdate,sysdate,'Migration','Migration',i.STATIONID,TRIM(i.CUSTOMERNUMBER),i.AGREEMENTID,    
				i.LICENSEFEE,i.LICENSEFEECURRENCY,null,i.KEYCATEGORY,i.PRICECATEGORY,i.MARKET,TRIM(i.AGREEMENTTYPE),TRIM(i.DEALTYPE),null,TRIM(i.CONTRACTSTATUS),    
				null,    
				null,    
				0,    
				0,    
				0,    
				null,    
				null,    
        TRIM(i.PACKAGEID),
        TRIM(i.PACKAGENAME));
		 end if;   
		    insert into dart_b2b2.RPM_DEAL_PRODUCT_STATION_SYND  
			select i.rpmrequestid, ssm.station_id from dart_b2b2.syndication_station_master ssm where ssm.synd_station_id in (WITH DATA AS(   
			SELECT temp.stationid str FROM dtv_b2b2.TEMP_RPM_SYNDICATION_DATA2 temp    
				where rpmrequestid = i.rpmrequestid)    
				SELECT regexp_substr(str,'[^;]+',1,level) str    
				FROM DATA    
				CONNECT BY regexp_substr(str, '[^;]+', 1, level) IS NOT NULL);    
      commit;
		end loop;           
END MIGRATE_DATA_TO_DEAL_PRODUCT_SYND_BATCH_2;
/


  CREATE OR REPLACE EDITIONABLE PROCEDURE "DART_B2B2"."MIGRATE_DATA_TO_DEAL_PRODUCT_SYND_BATCH_3" 
IS 
cursor deal is
	select * from dtv_b2b2.TEMP_RPM_SYNDICATION_DATA2 where STATIONNAME in('KTVZ (NEWS PRESS AND GAZETTE CO)','KSVI (NEXSTAR MEDIA GROUP)','KPVM (ION MEDIA NETWORKS, INC.)','WTVC (WTVC LICENSEE, LLC)','WTRF (NEXSTAR MEDIA GROUP)','WFLX (WFLX, LLC)','KIFI (NEWS PRESS AND GAZETTE CO)','WDCW (NEXSTAR MEDIA GROUP)','WKBT (QUEENB TELEVISION, LLC.)','KSAZ (FOX TELEVISION STATIONS, INC.)','WDBJ (GRAY TELEVISION LICENSEE, LLC)','KXLY (MORGAN MURPHY STATIONS)','WBND (WEIGEL BROADCASTING)','WHP (WHP LICENSEE, LLC)','KRIV (FOX TELEVISION STATIONS, INC.)','WTVQ (WTVQ-TV, LLC)','WXIN (NEXSTAR MEDIA GROUP)','WVTV (SINCLAIR BROADCAST GROUP)','WTIC (TEGNA, INC.)','KEYC (GRAY COMMUNICATIONS SYSTEMS)','WWHO (SINCLAIR BROADCAST GROUP)','WFXT (COX COMMUNICATIONS)','KIEM (POLLACK-BELZ BRDCSTNG CO.,LLC)','KECY (NEWS PRESS AND GAZETTE CO)','WDAY (FORUM COMMUNICATIONS)','KTVX (NEXSTAR MEDIA GROUP)','KELO (NEXSTAR MEDIA GROUP)','WCIX (NEXSTAR MEDIA GROUP)','KXVA (TEGNA, INC.)','KMOV (MEREDITH CORPORATION)','KIDY  
(TEGNA, INC.)','KAPP (MORGAN MURPHY STATIONS)','WBBH (WATERMAN BROADCASTING OF FLORI)','WBAL (HEARST TELEVISION INC.)','KOBI (CALIF)','WLWT (HEARST TELEVISION INC.)','WGAL (HEARST TELEVISION INC.)','WYFF (HEARST TELEVISION INC.)','KOCO (HEARST TELEVISION INC.)','KHBS (HEARST TELEVISION INC.)','KSBW (HEARST TELEVISION INC.)','KCCI (HEARST TELEVISION INC.)','KOAT (HEARST TELEVISION INC.)','KETV (HEARST TELEVISION INC.)','WTAE (HEARST TELEVISION INC.)','WAPT (HEARST TELEVISION INC.)','KAYU (MOUNTAIN BROADCASTING, L.L.C.)','WISN (HEARST TELEVISION INC.)','WPBF (HEARST TELEVISION INC.)','WUTV (SINCLAIR BROADCAST GROUP)','WTTG (FOX TELEVISION STATIONS, INC.)','KBAK (SINCLAIR BROADCAST GROUP)','KIII (TEGNA, INC.)','KESQ (NEWS PRESS AND GAZETTE CO)','WPCH (MEREDITH CORPORATION)','WBOC (DRAPER COMMUNICATIONS)','KEVN (GRAY TELEVISION LICENSEE, LLC)','WBKB (STEPHEN MARKS)','WSYM (SCRIPPS HOWARD BCSTG. CO.)','WCWG (GREENSBORO TV, LLC)','KUTV (KUTV LICENSEE, LLC)','WTVG (GRAY TELEVISION LICENSEE, L
LC)','KKTQ (VISION COMMUNICATIONS, INC.)','KHSL (CALIFORNIA TV LICENSE CO, LLC)','KTWO (VISION COMMUNICATIONS, INC.)','WTHR (TEGNA, INC.)','WOAI (WOAI LICENSEE, LLC)','WBKO (GRAY COMMUNICATIONS SYSTEMS)','KFYR (GRAY TELEVISION LICENSEE, LLC)','KMVT (GRAY COMMUNICATIONS SYSTEMS)','WLUC (GRAY TELEVISION LICENSEE, LLC)','KNIN (KNIN, LLC)','KMPH (TTBG/KMPH LICENSE SUB, LLC)','KVCW (SINCLAIR BROADCAST GROUP)','WQAD (LOCAL TV ILLINOIS LICENSE, LLC)','WIVT (NEXSTAR MEDIA GROUP)','WOFL (FOX TELEVISION STATIONS, INC.)','WHBF (NEXSTAR MEDIA GROUP)','KHSL-DT2 (COMMITTEE OF WB100+ BRDCSTRS)','WBUP-DT2 (COMMITTEE OF WB100+ BRDCSTRS)','KRIS-DT2 (COMMITTEE OF WB100+ BRDCSTRS)','WBGP (COMMITTEE OF WB100+ BRDCSTRS)','KJOS (COMMITTEE OF WB100+ BRDCSTRS)','KUVU (COMMITTEE OF WB100+ BRDCSTRS)','KRTV-DT2 (COMMITTEE OF WB100+ BRDCSTRS)');
existing_records number;
begin
	for i in deal 
		loop  
		existing_records := 0;  
		select count(*) into existing_records from dart_b2b2.rpm_deal_product_synd where rpm_request_id = i.rpmrequestid;  
		 delete from dart_b2b2.RPM_DEAL_PRODUCT_STATION_SYND where rpm_request_id = i.rpmrequestid;  
		 if existing_records > 0 then  
			update dart_b2b2.rpm_deal_product_synd set COMMENTS=TRIM(i.COMMENTS),   
				CONTRACT_NO=TRIM(i.CONTRACTNO), CUSTOMER_NAME=TRIM(i.CUSTOMERNAME), DEAL_PRODUCT_ID=i.DEALPRODUCTID, DELIVER_BY_DT=TO_DATE(i.DELIVERBYDATE, 'YYYY-MM-DD'),DELIVERY_LEAD_DAYS=DECODE(i.DELIVERYLEADDAYS, null, '120', i.DELIVERYLEADDAYS),EIDR_ID=i.EIDRID,    
				EXHIBITION_END_DT=CAST(i.EXHIBITIONENDDATE as DATE), EXHIBITION_ST_DT= CAST(i.EXHIBITIONSTARTDATE as DATE),GPMS_PRODUCT_ID=i.GPMSPRODUCTID,MPM_NO=i.MPMNO,ORDER_DESC=TRIM(i.ORDERDESCRIPTION),ORDER_NO=i.ORDERNO,PRIMARY_LANGUAGE_LKP_ID=i.PRIMARYLANGUAGEID,PRIMARY_MEDIA_LKP_ID=i.PRIMARYMEDIAID,    
				PRIMARY_TERRITORY_LKP_ID=i.PRIMARYTERRITORYID, SALES_PERSON=TRIM(i.SALESPERSON), SOURCE_SYSTEM=i.SOURCESYSTEM, STATION_NAME = TRIM(NVL(SUBSTR(i.STATIONNAME, 0, INSTR(i.STATIONNAME, '(')-1), i.STATIONNAME)), SOURCE_STATION_NAME= TRIM(i.STATIONNAME), SUB_DUB_LKP_ID=null, TERM_YEAR_DESC= TRIM(i.TERMYEARDESCRIPTION), TERM_YEAR_NO=i.TERMYEARNUMBER, TERM_YEAR_STATUS=TRIM(i.TERMYEARSTATUS),    
				TITLE_STATUS=TRIM(i.TITLESTATUS), CREATED_DT=sysdate, LAST_UPDATED_DT=sysdate, CREATED_BY='Migration', LAST_UPDATED_BY='Migration', RPM_STATION_ID=i.STATIONID, CUSTOMER_NO=TRIM(i.CUSTOMERNUMBER), AGREEMENT_ID=i.AGREEMENTID,    
				LICENSE_FEE=i.LICENSEFEE, LICENSE_FEE_CURRENCY=i.LICENSEFEECURRENCY, SUB_DUB_REQUESTED=null, KEY_CATEGORY=i.KEYCATEGORY, PRICE_CATEGORY=i.PRICECATEGORY, MARKET=i.MARKET, AGREEMENT_TYPE=TRIM(i.AGREEMENTTYPE), DEAL_TYPE=TRIM(i.DEALTYPE), SYNDICATION_RUNS=null, CONTRACT_STATUS=TRIM(i.CONTRACTSTATUS),     
				ACTION_LKP_ID = null,    
				CONTRACT_STATUS_LKP_ID = null,    
				GPMS_PROG_ID = 0,    
				GPMS_SEAS_ID = 0,    
				GPMS_EPS_ID = 0,    
				PROG_TYPE= null,    
				PROG_NAME= null,    
        PACKAGE_ID=TRIM(i.PACKAGEID),
        PACKAGE_NAME=TRIM(i.PACKAGENAME)
				where rpm_request_id = i.rpmrequestid;    
		 else  
			insert into dart_b2b2.rpm_deal_product_synd(RPM_REQUEST_ID,COMMENTS,CONTRACT_NO,CUSTOMER_NAME,DEAL_PRODUCT_ID,DELIVER_BY_DT,DELIVERY_LEAD_DAYS,EIDR_ID,   
				EXHIBITION_END_DT,EXHIBITION_ST_DT,GPMS_PRODUCT_ID,MPM_NO,ORDER_DESC,ORDER_NO,PRIMARY_LANGUAGE_LKP_ID,PRIMARY_MEDIA_LKP_ID,    
				PRIMARY_TERRITORY_LKP_ID,SALES_PERSON,SOURCE_SYSTEM,STATION_NAME,SOURCE_STATION_NAME,SUB_DUB_LKP_ID,TERM_YEAR_DESC,TERM_YEAR_NO,TERM_YEAR_STATUS,    
				TITLE_STATUS,CREATED_DT,LAST_UPDATED_DT,CREATED_BY,LAST_UPDATED_BY,RPM_STATION_ID,CUSTOMER_NO,AGREEMENT_ID,    
				LICENSE_FEE,LICENSE_FEE_CURRENCY,SUB_DUB_REQUESTED,KEY_CATEGORY,PRICE_CATEGORY,MARKET,AGREEMENT_TYPE,DEAL_TYPE,SYNDICATION_RUNS,CONTRACT_STATUS,    
				ACTION_LKP_ID,CONTRACT_STATUS_LKP_ID,GPMS_PROG_ID,GPMS_SEAS_ID,GPMS_EPS_ID,PROG_TYPE,PROG_NAME,PACKAGE_ID,PACKAGE_NAME)    
				values(i.RPMREQUESTID,TRIM(i.COMMENTS),i.CONTRACTNO,TRIM(i.CUSTOMERNAME),i.DEALPRODUCTID,TO_DATE(i.DELIVERBYDATE, 'YYYY-MM-DD'),DECODE(i.DELIVERYLEADDAYS, null, '120', i.DELIVERYLEADDAYS),i.EIDRID,CAST(i.EXHIBITIONENDDATE as DATE),CAST(i.EXHIBITIONSTARTDATE as DATE),    
				i.GPMSPRODUCTID,i.MPMNO,TRIM(i.ORDERDESCRIPTION),i.ORDERNO,i.PRIMARYLANGUAGEID,i.PRIMARYMEDIAID,    
				i.PRIMARYTERRITORYID,TRIM(i.SALESPERSON),i.SOURCESYSTEM,TRIM(NVL(SUBSTR(i.STATIONNAME, 0, INSTR(i.STATIONNAME, '(')-1), i.STATIONNAME)),TRIM(i.STATIONNAME),null,TRIM(i.TERMYEARDESCRIPTION),i.TERMYEARNUMBER,TRIM(i.TERMYEARSTATUS),    
				TRIM(i.TITLESTATUS),sysdate,sysdate,'Migration','Migration',i.STATIONID,TRIM(i.CUSTOMERNUMBER),i.AGREEMENTID,    
				i.LICENSEFEE,i.LICENSEFEECURRENCY,null,i.KEYCATEGORY,i.PRICECATEGORY,i.MARKET,TRIM(i.AGREEMENTTYPE),TRIM(i.DEALTYPE),null,TRIM(i.CONTRACTSTATUS),    
				null,    
				null,    
				0,    
				0,    
				0,    
				null,    
				null,    
        TRIM(i.PACKAGEID),
        TRIM(i.PACKAGENAME));
		 end if;   
		    insert into dart_b2b2.RPM_DEAL_PRODUCT_STATION_SYND  
			select i.rpmrequestid, ssm.station_id from dart_b2b2.syndication_station_master ssm where ssm.synd_station_id in (WITH DATA AS(   
			SELECT temp.stationid str FROM dtv_b2b2.TEMP_RPM_SYNDICATION_DATA2 temp    
				where rpmrequestid = i.rpmrequestid)    
				SELECT regexp_substr(str,'[^;]+',1,level) str    
				FROM DATA    
				CONNECT BY regexp_substr(str, '[^;]+', 1, level) IS NOT NULL);    
      commit;
		end loop;           
END MIGRATE_DATA_TO_DEAL_PRODUCT_SYND_BATCH_3;
/


  CREATE OR REPLACE EDITIONABLE PROCEDURE "DART_B2B2"."MIGRATE_DATA_TO_DEAL_PRODUCT_SYND_BATCH_4" 
IS 
cursor deal is
	select * from dtv_b2b2.TEMP_RPM_SYNDICATION_DATA2 where STATIONNAME in('KSBY-DT2 (COMMITTEE OF WB100+ BRDCSTRS)','WENY-DT3 (COMMITTEE OF WB100+ BRDCSTRS)','KWMK (COMMITTEE OF WB100+ BRDCSTRS)','WBAE (COMMITTEE OF WB100+ BRDCSTRS)','WWTI-DT2 (COMMITTEE OF WB100+ BRDCSTRS)','WKTV-DT2 (COMMITTEE OF WB100+ BRDCSTRS)','WXOW-DT2 (COMMITTEE OF WB100+ BRDCSTRS)','KNOE-DT2 (COMMITTEE OF WB100+ BRDCSTRS)','KBCA (COMMITTEE OF WB100+ BRDCSTRS)','KGET-DT2 (COMMITTEE OF WB100+ BRDCSTRS)','KMTF-CW (COMMITTEE OF WB100+ BRDCSTRS)','WAOW-DT2 (COMMITTEE OF WB100+ BRDCSTRS)','WLTZ-DT2 (COMMITTEE OF WB100+ BRDCSTRS)','WBQT (COMMITTEE OF WB100+ BRDCSTRS)','WVIR-CW (COMMITTEE OF WB100+ BRDCSTRS)','KWPL (COMMITTEE OF WB100+ BRDCSTRS)','WAGT-DT2 (COMMITTEE OF WB100+ BRDCSTRS)','WBI (COMMITTEE OF WB100+ BRDCSTRS)','WPTZ-DT2 (COMMITTEE OF WB100+ BRDCSTRS)','WREX-DT2 (COMMITTEE OF WB100+ BRDCSTRS)','WVFX-DT2 (COMMITTEE OF WB100+ BRDCSTRS)','WBKO-DT3 (COMMITTEE OF WB100+ BRDCSTRS)','KOMU-DT3 (COMMITTEE OF WB100+  
BRDCSTRS)','WPTA-DT2 (COMMITTEE OF WB100+ BRDCSTRS)','KTXS-DT2 (COMMITTEE OF WB100+ BRDCSTRS)','WSEE-DT2 (COMMITTEE OF WB100+ BRDCSTRS)','KTTC-DT2 (COMMITTEE OF WB100+ BRDCSTRS)','WABI-DT2 (COMMITTEE OF WB100+ BRDCSTRS)','WVVA-DT2 (COMMITTEE OF WB100+ BRDCSTRS)','KFDM-DT2 (COMMITTEE OF WB100+ BRDCSTRS)','WTOK-DT3 (COMMITTEE OF WB100+ BRDCSTRS)','KREN-DT2 (COMMITTEE OF WB100+ BRDCSTRS)','KTVZ-DT2 (COMMITTEE OF WB100+ BRDCSTRS)','WGSA-DT2 (COMMITTEE OF WB100+ BRDCSTRS)','KMTR-DT2 (COMMITTEE OF WB100+ BRDCSTRS)','WCBD-DT2 (COMMITTEE OF WB100+ BRDCSTRS)','KWBH (COMMITTEE OF WB100+ BRDCSTRS)','KDLH-DT2 (COMMITTEE OF WB100+ BRDCSTRS)','KCEB (COMMITTEE OF WB100+ BRDCSTRS)','WBWO (COMMITTEE OF WB100+ BRDCSTRS)','WJHG-DT2 (COMMITTEE OF WB100+ BRDCSTRS)','KWYE (COMMITTEE OF WB100+ BRDCSTRS)','KIFI-DT3 (COMMITTEE OF WB100+ BRDCSTRS)','WBH (COMMITTEE OF WB100+ BRDCSTRS)','WHOI-DT2 (COMMITTEE OF WB100+ BRDCSTRS)','KTEN-DT2 (COMMITTEE OF WB100+ BRDCSTRS)','KECY-DT3 (COMMITTEE OF WB100+ BRDCSTRS)','W
BPQ (COMMITTEE OF WB100+ BRDCSTRS)','WLAJ-DT2 (COMMITTEE OF WB100+ BRDCSTRS)','KIMA-DT2 (COMMITTEE OF WB100+ BRDCSTRS)','KTKA-DT3 (COMMITTEE OF WB100+ BRDCSTRS)','WNCT-DT2 (COMMITTEE OF WB100+ BROADCSTRS)','KCWQ (COMMITTEE OF WB100+ BRDCSTRS)','WBFY-CW (COMMITTEE OF WB100+ BRDCSTRS)','KCWT (COMMITTEE OF WB100+ BRDCSTRS)','WBWD (COMMITTEE OF WB100+ BRDCSTRS)','KWSA (COMMITTEE OF WB100+ BRDCSTRS)','KWOT (COMMITTEE OF WB100+ BRDCSTRS)','KAUZ-DT2 (COMMITTEE OF WB100+ BRDCSTRS)','KPAX-DT2 (COMMITTEE OF WB100+ BRDCSTRS)','WBJO (COMMITTEE OF WB100+ BRDCSTRS)','WBW (COMMITTEE OF WB100+ BRDCSTRS)','WGEM-DT2 (COMMITTEE OF WB100+ BRDCSTRS)','WVIR-DT3 (COMMITTEE OF WB100+ BRDCSTRS)','WWMB-DT2 (COMMITTEE OF WB100+ BRDCSTRS)','KWBL (COMMITTEE OF WB100+ BRDCSTRS)','WCWP (COMMITTEE OF WB100+ BRDCSTRS)','WTVY-DT3 (COMMITTEE OF WB100+ BRDCSTRS)','KATN-DT2 (COMMITTEE OF WB100+ BRDCSTRS)','WCBI-DT3 (COMMITTEE OF WB100+ BRDCSTRS)','KVII-DT2 (COMMITTEE OF WB100+ BRDCSTRS)','KHBS-DT2 (COMMITTEE OF WB100+ BRD
CSTRS)','WBOH (COMMITTEE OF WB100+ BRDCSTRS)','WBJK (COMMITTEE OF WB100+ BRDCSTRS)','KATC-DT2 (COMMITTEE OF WB100+ BRDCSTRS)','WBVC (COMMITTEE OF WB100+ BRDCSTRS)','KTVQ-DT2 (COMMITTEE OF WB100+ BRDCSTRS)','WDAY-DT2 (COMMITTEE OF WB100+ BRDCSTRS)','WBNG-DT2 (COMMITTEE OF WB100+ BRDCSTRS)','WCJB-DT2 (COMMITTEE OF WB100+ BRDCSTRS)','KTIV-DT2 (COMMITTEE OF WB100+ BRDCSTRS)','KNIN-DT2 (COMMITTEE OF WB100+ BRDCSTRS)','KGNS-DT2 (COMMITTEE OF WB100+ BRDCSTRS)','KVHP-DT2 (COMMITTEE OF WB100+ BRDCSTRS)','KMVT-DT2 (COMMITTEE OF WB100+ BRDCSTRS)','WBZV (COMMITTEE OF WB100+ BRDCSTRS)','K26ES (COMMITTEE OF WB100+ BRDCSTRS)','WTLH-DT2 (COMMITTEE OF WB100+ BRDCSTRS)','WBSK (COMMITTEE OF WB100+ BRDCSTRS)','KJCT-DT3 (COMMITTEE OF WB100+ BRDCSTRS)','KWWT (COMMITTEE OF WB100+ BRDCSTRS)','WMDT-DT2 (COMMITTEE OF WB100+ BRDCSTRS)','WNCF-DT2 (COMMITTEE OF WB100+ BRDCSTRS)','KCHW (COMMITTEE OF WB100+ BRDCSTRS)','KSXF (COMMITTEE OF WB100+ BRDCSTRS)','WBMN (COMMITTEE OF WB100+ BRDCSTRS)');
existing_records number;
begin
	for i in deal 
		loop  
		existing_records := 0;  
		select count(*) into existing_records from dart_b2b2.rpm_deal_product_synd where rpm_request_id = i.rpmrequestid;  
		 delete from dart_b2b2.RPM_DEAL_PRODUCT_STATION_SYND where rpm_request_id = i.rpmrequestid;  
		 if existing_records > 0 then  
			update dart_b2b2.rpm_deal_product_synd set COMMENTS=TRIM(i.COMMENTS),   
				CONTRACT_NO=TRIM(i.CONTRACTNO), CUSTOMER_NAME=TRIM(i.CUSTOMERNAME), DEAL_PRODUCT_ID=i.DEALPRODUCTID, DELIVER_BY_DT=TO_DATE(i.DELIVERBYDATE, 'YYYY-MM-DD'),DELIVERY_LEAD_DAYS=DECODE(i.DELIVERYLEADDAYS, null, '120', i.DELIVERYLEADDAYS),EIDR_ID=i.EIDRID,    
				EXHIBITION_END_DT=CAST(i.EXHIBITIONENDDATE as DATE), EXHIBITION_ST_DT= CAST(i.EXHIBITIONSTARTDATE as DATE),GPMS_PRODUCT_ID=i.GPMSPRODUCTID,MPM_NO=i.MPMNO,ORDER_DESC=TRIM(i.ORDERDESCRIPTION),ORDER_NO=i.ORDERNO,PRIMARY_LANGUAGE_LKP_ID=i.PRIMARYLANGUAGEID,PRIMARY_MEDIA_LKP_ID=i.PRIMARYMEDIAID,    
				PRIMARY_TERRITORY_LKP_ID=i.PRIMARYTERRITORYID, SALES_PERSON=TRIM(i.SALESPERSON), SOURCE_SYSTEM=i.SOURCESYSTEM, STATION_NAME = TRIM(NVL(SUBSTR(i.STATIONNAME, 0, INSTR(i.STATIONNAME, '(')-1), i.STATIONNAME)), SOURCE_STATION_NAME= TRIM(i.STATIONNAME), SUB_DUB_LKP_ID=null, TERM_YEAR_DESC= TRIM(i.TERMYEARDESCRIPTION), TERM_YEAR_NO=i.TERMYEARNUMBER, TERM_YEAR_STATUS=TRIM(i.TERMYEARSTATUS),    
				TITLE_STATUS=TRIM(i.TITLESTATUS), CREATED_DT=sysdate, LAST_UPDATED_DT=sysdate, CREATED_BY='Migration', LAST_UPDATED_BY='Migration', RPM_STATION_ID=i.STATIONID, CUSTOMER_NO=TRIM(i.CUSTOMERNUMBER), AGREEMENT_ID=i.AGREEMENTID,    
				LICENSE_FEE=i.LICENSEFEE, LICENSE_FEE_CURRENCY=i.LICENSEFEECURRENCY, SUB_DUB_REQUESTED=null, KEY_CATEGORY=i.KEYCATEGORY, PRICE_CATEGORY=i.PRICECATEGORY, MARKET=i.MARKET, AGREEMENT_TYPE=TRIM(i.AGREEMENTTYPE), DEAL_TYPE=TRIM(i.DEALTYPE), SYNDICATION_RUNS=null, CONTRACT_STATUS=TRIM(i.CONTRACTSTATUS),     
				ACTION_LKP_ID = null,    
				CONTRACT_STATUS_LKP_ID = null,    
				GPMS_PROG_ID = 0,    
				GPMS_SEAS_ID = 0,    
				GPMS_EPS_ID = 0,    
				PROG_TYPE= null,    
				PROG_NAME= null,    
        PACKAGE_ID=TRIM(i.PACKAGEID),
        PACKAGE_NAME=TRIM(i.PACKAGENAME)
				where rpm_request_id = i.rpmrequestid;    
		 else  
			insert into dart_b2b2.rpm_deal_product_synd(RPM_REQUEST_ID,COMMENTS,CONTRACT_NO,CUSTOMER_NAME,DEAL_PRODUCT_ID,DELIVER_BY_DT,DELIVERY_LEAD_DAYS,EIDR_ID,   
				EXHIBITION_END_DT,EXHIBITION_ST_DT,GPMS_PRODUCT_ID,MPM_NO,ORDER_DESC,ORDER_NO,PRIMARY_LANGUAGE_LKP_ID,PRIMARY_MEDIA_LKP_ID,    
				PRIMARY_TERRITORY_LKP_ID,SALES_PERSON,SOURCE_SYSTEM,STATION_NAME,SOURCE_STATION_NAME,SUB_DUB_LKP_ID,TERM_YEAR_DESC,TERM_YEAR_NO,TERM_YEAR_STATUS,    
				TITLE_STATUS,CREATED_DT,LAST_UPDATED_DT,CREATED_BY,LAST_UPDATED_BY,RPM_STATION_ID,CUSTOMER_NO,AGREEMENT_ID,    
				LICENSE_FEE,LICENSE_FEE_CURRENCY,SUB_DUB_REQUESTED,KEY_CATEGORY,PRICE_CATEGORY,MARKET,AGREEMENT_TYPE,DEAL_TYPE,SYNDICATION_RUNS,CONTRACT_STATUS,    
				ACTION_LKP_ID,CONTRACT_STATUS_LKP_ID,GPMS_PROG_ID,GPMS_SEAS_ID,GPMS_EPS_ID,PROG_TYPE,PROG_NAME,PACKAGE_ID,PACKAGE_NAME)    
				values(i.RPMREQUESTID,TRIM(i.COMMENTS),i.CONTRACTNO,TRIM(i.CUSTOMERNAME),i.DEALPRODUCTID,TO_DATE(i.DELIVERBYDATE, 'YYYY-MM-DD'),DECODE(i.DELIVERYLEADDAYS, null, '120', i.DELIVERYLEADDAYS),i.EIDRID,CAST(i.EXHIBITIONENDDATE as DATE),CAST(i.EXHIBITIONSTARTDATE as DATE),    
				i.GPMSPRODUCTID,i.MPMNO,TRIM(i.ORDERDESCRIPTION),i.ORDERNO,i.PRIMARYLANGUAGEID,i.PRIMARYMEDIAID,    
				i.PRIMARYTERRITORYID,TRIM(i.SALESPERSON),i.SOURCESYSTEM,TRIM(NVL(SUBSTR(i.STATIONNAME, 0, INSTR(i.STATIONNAME, '(')-1), i.STATIONNAME)),TRIM(i.STATIONNAME),null,TRIM(i.TERMYEARDESCRIPTION),i.TERMYEARNUMBER,TRIM(i.TERMYEARSTATUS),    
				TRIM(i.TITLESTATUS),sysdate,sysdate,'Migration','Migration',i.STATIONID,TRIM(i.CUSTOMERNUMBER),i.AGREEMENTID,    
				i.LICENSEFEE,i.LICENSEFEECURRENCY,null,i.KEYCATEGORY,i.PRICECATEGORY,i.MARKET,TRIM(i.AGREEMENTTYPE),TRIM(i.DEALTYPE),null,TRIM(i.CONTRACTSTATUS),    
				null,    
				null,    
				0,    
				0,    
				0,    
				null,    
				null,    
        TRIM(i.PACKAGEID),
        TRIM(i.PACKAGENAME));
		 end if;   
		    insert into dart_b2b2.RPM_DEAL_PRODUCT_STATION_SYND  
			select i.rpmrequestid, ssm.station_id from dart_b2b2.syndication_station_master ssm where ssm.synd_station_id in (WITH DATA AS(   
			SELECT temp.stationid str FROM dtv_b2b2.TEMP_RPM_SYNDICATION_DATA2 temp    
				where rpmrequestid = i.rpmrequestid)    
				SELECT regexp_substr(str,'[^;]+',1,level) str    
				FROM DATA    
				CONNECT BY regexp_substr(str, '[^;]+', 1, level) IS NOT NULL);    
      commit;
		end loop;           
END MIGRATE_DATA_TO_DEAL_PRODUCT_SYND_BATCH_4;
/


  CREATE OR REPLACE EDITIONABLE PROCEDURE "DART_B2B2"."MIGRATE_DATA_TO_DEAL_PRODUCT_SYND_BATCH_5" 
IS 
cursor deal is
	select * from dtv_b2b2.TEMP_RPM_SYNDICATION_DATA2 where STATIONNAME in('KWSD (COMMITTEE OF WB100+ BRDCSTRS)','KION-DT2 (COMMITTEE OF WB100+ BRDCSTRS)','KJUD-DT2 (COMMITTEE OF WB100+ BRDCSTRS)','WCYB (SINCLAIR BROADCAST GROUP)','WTVZ (WTVZ LICENSEE, LLC)','KDSM (SINCLAIR BROADCAST GROUP)','KSTP (KSTP-TV, LLC)','WFLD (FOX TELEVISION STATIONS, INC.)','KATH (GRAY COMMUNICATIONS SYSTEMS)','KMSP (FOX TELEVISION STATIONS, INC.)','WTAP (GRAY COMMUNICATIONS SYSTEMS)','WAFB (WAFB, LLC)','WCGV (SINCLAIR BROADCAST GROUP)','KJTV (SAGAMOREHILL BROADCASTING, LLC)','KEYT (NPG OF CALIFORNIA, LLC)','WWNY (GRAY COMMUNICATIONS SYSTEMS)','KBMT (TEGNA, INC.)','KLKN (STANDARD MEDIA)','WCBS (CBS TELEVISION STATIONS)','WSYX (SINCLAIR BROADCAST GROUP)','KBSI (SINCLAIR BROADCAST GROUP)','KLRT (MISSION BROADCASTING, INC.)','KGCW (NEXSTAR MEDIA GROUP)','KSPR (GRAY COMMUNICATIONS SYSTEMS)','KSHB (SCRIPPS HOWARD BCSTG. CO.)','KONG (TEGNA, INC.)','WKRC (WKRC LICENSEE, LLC)','WIVB (WIVB BROADCASTING, LLC)','KYOU (KYO 
U LICENSE SUBSIDIARY, LLC)','WNYO (SINCLAIR BROADCAST GROUP)','WTTA (NEXSTAR MEDIA GROUP)','TBD','WJW (NEXSTAR MEDIA GROUP)','KCAU (NEXSTAR MEDIA GROUP)','KPVI (IDAHO BROADCAST PARTNERS LLC)','WXIX (WXIX, LLC)','KAIL (TRANS-AMERICA B''CSTING CORP.)','WPEC (WPEC LICENSEE, LLC)','KSNV (KUPN LICENSEE, LLC)','CW PLUS, THE (CW PLUS, THE)','WUPW (WUPW LICENSE SUBSIDIARY, LLC)','KTVI (NEXSTAR MEDIA GROUP)','WPHL (NEXSTAR MEDIA GROUP)','WMBB (NEXSTAR MEDIA GROUP)','KDOC (ELLIS COMMUNICATIONS)','KTXA (TELEVISION STATION KTXA L.P.)','KXII (GRAY TELEVISION LICENSEE, LLC)','KCYU (MOUNTAIN BROADCASTING, L.L.C.)','WLIO (BLOCK COMMUNICATIONS)','KXOF (ENTRAVISION HOLDINGS LLC)','WPDE (WPDE LICENSEE, LLC)','KFXV (ENTRAVISION HOLDINGS, LLC)','WXXV (MORRIS NETWORK)','WBOY (NEXSTAR MEDIA GROUP)','WATL (WATL, L.L.C.)','WCOV (WOODS COMMUNICATIONS)','WSWG (GRAY TELEVISION LICENSEE, LLC)','WUPA (CBS TELEVISION STATIONS)','KAZT (KAZT, LLC)','KRCW (NEXSTAR MEDIA GROUP)','WTOG (CBS TELEVISION STATIONS)','KPIX (C
BS TELEVISION STATIONS)','WNUV (CUNNINGHAM BROADCASTING)','WRDW (GRAY TELEVISION LICENSEE, LLC)','WINK (FORT MYERS BROADCASTING CORP.)','KASY (KASY-TV LICENSEE LLC)','KSBI (GRIFFIN COMMUNICATIONS)','KJCT (EXCALIBUR GRAND JUCTION, LLC)','WVUA (University of Alabama)','WAGT (GRAY TELEVISION LICENSEE, LLC)','WCIA (NEXSTAR MEDIA GROUP)','KDKA (CBS TELEVISION STATIONS)','KVHP (KVHP LICENSE SUBSIDIARY, LLC)','KWCH (GRAY TELEVISION LICENSEE, LLC)','KPTV (MEREDITH CORPORATION)','WCAX (GRAY COMMUNICATIONS SYSTEMS)','WVLA (NEXSTAR MEDIA GROUP)','WGEM (QUINCY BROADCASTING)','KREX (NEXSTAR MEDIA GROUP)','XETV (BAY CITY TELEVISION, INC.)','KREM (TEGNA, INC.)','WNEM (MEREDITH CORPORATION)','WHDF (HUNTSVILLE TELEVISION LLC)','WRGT (WRGT LICENSEE, LLC)','KOKH (SINCLAIR BROADCAST GROUP)','KLAX (COX COMMUNICATIONS)','WCTV (GRAY COMMUNICATIONS SYSTEMS)','WGCL (MEREDITH CORPORATION)','KTVO (KTVO LICENSEE, LLC)','KQFX (NPG OF MISSOURI, LLC)','TVW (MORGAN MURPHY STATIONS)','WRSP (GOCOM MEDIA OF ILLINOIS, LL
C)','WORA (TELECINCO, INC.)','WISH (INDIANA BROADCASTING, LLC)','WPRI (NEXSTAR MEDIA GROUP)','KFDA (GRAY COMMUNICATIONS SYSTEMS)','KIIT (GRAY TELEVISION LICENSEE, LLC)','KOLO (GRAY COMMUNICATIONS SYSTEMS)','KTXE (SINCLAIR BROADCAST GROUP)','WGTU (CUNNINGHAM BROADCASTING)','KMBC (HEARST TELEVISION INC.)','WTHI (Allen Media Broadcasting LLC)','WGGB (MEREDITH CORPORATION)','WVIR (GRAY COMMUNICATIONS SYSTEMS)','KODE (MISSION BROADCASTING, INC.)','KRDO (NEWS PRESS AND GAZETTE CO)','WILX (GRAY COMMUNICATIONS SYSTEMS)','WBRE (NEXSTAR MEDIA GROUP)','KVOA (EVENING POST PUBLISHING)','KTBC (FOX TELEVISION STATIONS, INC.)','KTXS (SINCLAIR BROADCAST GROUP)','KDFW (FOX TELEVISION STATIONS, INC.)','WHIZ (SOUTHEASTERN OHIO TV SYSTEM)','KHQA (KHQA LICENSEE, LLC)','KAKE (KNOXVILLE TV, LLC)','WGME (SINCLAIR BROADCAST GROUP)','KITV (Allen Media Broadcasting LLC)','KTVE (MISSION BROADCASTING, INC.)','WTOK (GRAY COMMUNICATIONS SYSTEMS)');
existing_records number;
begin
	for i in deal 
		loop  
		existing_records := 0;  
		select count(*) into existing_records from dart_b2b2.rpm_deal_product_synd where rpm_request_id = i.rpmrequestid;  
		 delete from dart_b2b2.RPM_DEAL_PRODUCT_STATION_SYND where rpm_request_id = i.rpmrequestid;  
		 if existing_records > 0 then  
			update dart_b2b2.rpm_deal_product_synd set COMMENTS=TRIM(i.COMMENTS),   
				CONTRACT_NO=TRIM(i.CONTRACTNO), CUSTOMER_NAME=TRIM(i.CUSTOMERNAME), DEAL_PRODUCT_ID=i.DEALPRODUCTID, DELIVER_BY_DT=TO_DATE(i.DELIVERBYDATE, 'YYYY-MM-DD'),DELIVERY_LEAD_DAYS=DECODE(i.DELIVERYLEADDAYS, null, '120', i.DELIVERYLEADDAYS),EIDR_ID=i.EIDRID,    
				EXHIBITION_END_DT=CAST(i.EXHIBITIONENDDATE as DATE), EXHIBITION_ST_DT= CAST(i.EXHIBITIONSTARTDATE as DATE),GPMS_PRODUCT_ID=i.GPMSPRODUCTID,MPM_NO=i.MPMNO,ORDER_DESC=TRIM(i.ORDERDESCRIPTION),ORDER_NO=i.ORDERNO,PRIMARY_LANGUAGE_LKP_ID=i.PRIMARYLANGUAGEID,PRIMARY_MEDIA_LKP_ID=i.PRIMARYMEDIAID,    
				PRIMARY_TERRITORY_LKP_ID=i.PRIMARYTERRITORYID, SALES_PERSON=TRIM(i.SALESPERSON), SOURCE_SYSTEM=i.SOURCESYSTEM, STATION_NAME = TRIM(NVL(SUBSTR(i.STATIONNAME, 0, INSTR(i.STATIONNAME, '(')-1), i.STATIONNAME)), SOURCE_STATION_NAME= TRIM(i.STATIONNAME), SUB_DUB_LKP_ID=null, TERM_YEAR_DESC= TRIM(i.TERMYEARDESCRIPTION), TERM_YEAR_NO=i.TERMYEARNUMBER, TERM_YEAR_STATUS=TRIM(i.TERMYEARSTATUS),    
				TITLE_STATUS=TRIM(i.TITLESTATUS), CREATED_DT=sysdate, LAST_UPDATED_DT=sysdate, CREATED_BY='Migration', LAST_UPDATED_BY='Migration', RPM_STATION_ID=i.STATIONID, CUSTOMER_NO=TRIM(i.CUSTOMERNUMBER), AGREEMENT_ID=i.AGREEMENTID,    
				LICENSE_FEE=i.LICENSEFEE, LICENSE_FEE_CURRENCY=i.LICENSEFEECURRENCY, SUB_DUB_REQUESTED=null, KEY_CATEGORY=i.KEYCATEGORY, PRICE_CATEGORY=i.PRICECATEGORY, MARKET=i.MARKET, AGREEMENT_TYPE=TRIM(i.AGREEMENTTYPE), DEAL_TYPE=TRIM(i.DEALTYPE), SYNDICATION_RUNS=null, CONTRACT_STATUS=TRIM(i.CONTRACTSTATUS),     
				ACTION_LKP_ID = null,    
				CONTRACT_STATUS_LKP_ID = null,    
				GPMS_PROG_ID = 0,    
				GPMS_SEAS_ID = 0,    
				GPMS_EPS_ID = 0,    
				PROG_TYPE= null,    
				PROG_NAME= null,    
        PACKAGE_ID=TRIM(i.PACKAGEID),
        PACKAGE_NAME=TRIM(i.PACKAGENAME)
				where rpm_request_id = i.rpmrequestid;    
		 else  
			insert into dart_b2b2.rpm_deal_product_synd(RPM_REQUEST_ID,COMMENTS,CONTRACT_NO,CUSTOMER_NAME,DEAL_PRODUCT_ID,DELIVER_BY_DT,DELIVERY_LEAD_DAYS,EIDR_ID,   
				EXHIBITION_END_DT,EXHIBITION_ST_DT,GPMS_PRODUCT_ID,MPM_NO,ORDER_DESC,ORDER_NO,PRIMARY_LANGUAGE_LKP_ID,PRIMARY_MEDIA_LKP_ID,    
				PRIMARY_TERRITORY_LKP_ID,SALES_PERSON,SOURCE_SYSTEM,STATION_NAME,SOURCE_STATION_NAME,SUB_DUB_LKP_ID,TERM_YEAR_DESC,TERM_YEAR_NO,TERM_YEAR_STATUS,    
				TITLE_STATUS,CREATED_DT,LAST_UPDATED_DT,CREATED_BY,LAST_UPDATED_BY,RPM_STATION_ID,CUSTOMER_NO,AGREEMENT_ID,    
				LICENSE_FEE,LICENSE_FEE_CURRENCY,SUB_DUB_REQUESTED,KEY_CATEGORY,PRICE_CATEGORY,MARKET,AGREEMENT_TYPE,DEAL_TYPE,SYNDICATION_RUNS,CONTRACT_STATUS,    
				ACTION_LKP_ID,CONTRACT_STATUS_LKP_ID,GPMS_PROG_ID,GPMS_SEAS_ID,GPMS_EPS_ID,PROG_TYPE,PROG_NAME,PACKAGE_ID,PACKAGE_NAME)    
				values(i.RPMREQUESTID,TRIM(i.COMMENTS),i.CONTRACTNO,TRIM(i.CUSTOMERNAME),i.DEALPRODUCTID,TO_DATE(i.DELIVERBYDATE, 'YYYY-MM-DD'),DECODE(i.DELIVERYLEADDAYS, null, '120', i.DELIVERYLEADDAYS),i.EIDRID,CAST(i.EXHIBITIONENDDATE as DATE),CAST(i.EXHIBITIONSTARTDATE as DATE),    
				i.GPMSPRODUCTID,i.MPMNO,TRIM(i.ORDERDESCRIPTION),i.ORDERNO,i.PRIMARYLANGUAGEID,i.PRIMARYMEDIAID,    
				i.PRIMARYTERRITORYID,TRIM(i.SALESPERSON),i.SOURCESYSTEM,TRIM(NVL(SUBSTR(i.STATIONNAME, 0, INSTR(i.STATIONNAME, '(')-1), i.STATIONNAME)),TRIM(i.STATIONNAME),null,TRIM(i.TERMYEARDESCRIPTION),i.TERMYEARNUMBER,TRIM(i.TERMYEARSTATUS),    
				TRIM(i.TITLESTATUS),sysdate,sysdate,'Migration','Migration',i.STATIONID,TRIM(i.CUSTOMERNUMBER),i.AGREEMENTID,    
				i.LICENSEFEE,i.LICENSEFEECURRENCY,null,i.KEYCATEGORY,i.PRICECATEGORY,i.MARKET,TRIM(i.AGREEMENTTYPE),TRIM(i.DEALTYPE),null,TRIM(i.CONTRACTSTATUS),    
				null,    
				null,    
				0,    
				0,    
				0,    
				null,    
				null,    
        TRIM(i.PACKAGEID),
        TRIM(i.PACKAGENAME));
		 end if;   
		    insert into dart_b2b2.RPM_DEAL_PRODUCT_STATION_SYND  
			select i.rpmrequestid, ssm.station_id from dart_b2b2.syndication_station_master ssm where ssm.synd_station_id in (WITH DATA AS(   
			SELECT temp.stationid str FROM dtv_b2b2.TEMP_RPM_SYNDICATION_DATA2 temp    
				where rpmrequestid = i.rpmrequestid)    
				SELECT regexp_substr(str,'[^;]+',1,level) str    
				FROM DATA    
				CONNECT BY regexp_substr(str, '[^;]+', 1, level) IS NOT NULL);    
      commit;
		end loop;           
END MIGRATE_DATA_TO_DEAL_PRODUCT_SYND_BATCH_5;
/


  CREATE OR REPLACE EDITIONABLE PROCEDURE "DART_B2B2"."MIGRATE_DATA_TO_DEAL_PRODUCT_SYND_BATCH_6" 
IS 
cursor deal is
	select * from dtv_b2b2.TEMP_RPM_SYNDICATION_DATA2 where STATIONNAME in('WROC (NEXSTAR MEDIA GROUP)','KVVU (MEREDITH CORPORATION)','WFSB (MEREDITH CORPORATION)','WXTX (WXTX LICENSE SUBSIDIARY, LLC)','WKTV (HEARTLAND MEDIA, LLC)','KYTX (TEGNA, INC.)','WRGX (GRAY TELEVISION LICENSEE, LLC)','KSNT (LIN LICENSE COMPANY, LLC)','WJET (NEXSTAR MEDIA GROUP)','WTVA (MISSISSIPPI TV, LLC)','KOMU (University of Missouri)','KQCW (GRIFFIN TULSA II LICENSING,LLC)','WEEK (WEEK LICENSE, LLC)','WWAY (WWAY-LLC)','KFSN (KFSN TELEVISION, LLC.)','WMGT (MORRIS NETWORK)','WTXF (FOX TELEVISION STATIONS, INC.)','KAMR (NEXSTAR MEDIA GROUP)','WEYI (HSH FLINT (WEYI) LICENSEE, LLC)','WJHL (NEXSTAR MEDIA GROUP)','KVAL (SINCLAIR EUGENE LICENSEE, LLC)','KWES (KWES LICENSE SUBSIDIARY, LLC)','WNBW (SINCLAIR BROADCAST GROUP)','WBNS (TEGNA, INC.)','KCEN (TEGNA, INC.)','KTVF (GRAY TELEVISION LICENSEE, LLC)','KATV (KATV LICENSEE, LLC)','KXGN (Glendive Broadcasting Corp.)','KTEN (LOCKWOOD BROADCASTING)','KGTV (SCRIPPS HOWARD  
BCSTG. CO.)','KCWE (HEARST TELEVISION INC.)','KOCB (SINCLAIR BROADCAST GROUP)','WLMB (DOMINION BROADCASTING, INC.)','WCWF (WCWF LICENSEE, LLC)','WFOX (COX COMMUNICATIONS)','KASW (SCRIPPS HOWARD BCSTG. CO.)','KQDS (RED RIVER BROADCASTING CORP.)','WNYS (COX COMMUNICATIONS)','WBMA (WBMA LICENSEE, LLC)','WSTM (WSTQ LICENSEE, LLC)','KCPO (G.I.G.,INC.)','KGW (TEGNA, INC.)','WOTV (WOOD LICENSE COMPANY, LLC)','WTNZ (WTNZ, LLC)','KDAF (NEXSTAR MEDIA GROUP)','WDAF (NEXSTAR MEDIA GROUP)','WUPL (TEGNA, INC.)','KSNF (NEXSTAR MEDIA GROUP)','WNBJ (JACKSON TV, LLC)','WMDN (MERIDIAN MEDIA, LLC)','WEAR (SINCLAIR BROADCAST GROUP)','WJHG (GRAY TELEVISION LICENSEE, LLC)','KPLR (COMMUNITY TV OF MISSOURI, LLC)','KFSM (LOCAL TV ARKANSAS LICENSE, LLC)','KWTX (GRAY COMMUNICATIONS SYSTEMS)','WEHT (NEXSTAR MEDIA GROUP)','WEVV (Allen Media Broadcasting LLC)','KTVB (TEGNA, INC.)','WBBM (CBS TELEVISION STATIONS)','KVEO (NEXSTAR MEDIA GROUP)','WETM (NEXSTAR MEDIA GROUP)','KTFT (TEGNA, INC.)','WEWS (SCRIPPS HOWARD BCS
TG. CO.)','KSEE (NEXSTAR MEDIA GROUP)','WDHN (NEXSTAR MEDIA GROUP)','KYLE (NEXSTAR MEDIA GROUP)','WAWV (MISSION BROADCASTING, INC.)','KOAA (SCRIPPS HOWARD BCSTG. CO.)','KLAS (KLAS, LLC)','WSWB (KB PRIME MEDIA, LLC)','KRQE (LIN OF NEW MEXICO, LLC)','KGMB (KHNL/KGMB,LLC)','KFBB (COWLES COMMUNICATIONS)','KTMF (COWLES COMMUNICATIONS)','KAEF (BONTEN MEDIA GROUP, LLC)','WKTC (WBHQ COLUMBIA, LLC)','WCBI (WCBI-TV, LLC)','KWYB (COWLES COMMUNICATIONS)','WGHP (NEXSTAR MEDIA GROUP)','WITI (FOX TELEVISION STATIONS, INC.)','KHBB (COWLES COMMUNICATIONS)','WQCW (GRAY TELEVISION LICENSEE, LLC)','KSWB (NEXSTAR MEDIA GROUP)','WHVL (CHANNEL COMMUNICATIONS, LLC)','WLAX (NEXSTAR MEDIA GROUP)','KCPQ (FOX TELEVISION STATIONS, INC.)','WDCA (FOX TELEVISION STATIONS, INC.)','KCIT (MISSION BROADCASTING, INC.)','WFXV (NEXSTAR MEDIA GROUP)','WYDO (CUNNINGHAM BROADCASTING)','WTOV (WTOV LICENSEE, LLC)','KPTH (KPTH LICENSEE, LLC)','WPXT (HEARST TELEVISION INC.)','KMVU (BROADCASTING COMMUNICAT''NS,LLC)','KBVO (KXAN, LL
C)','KXXV (LONDON BROADCASTING, LLC)','WMNT (COMMUNITY BROADCAST GROUP,INC.)','WGBC (WGBC-TV,LLC)','WFNA (LIN OF ALABAMA, LLC)','WIYE (GRAY COMMUNICATIONS SYSTEMS)','WBGT (WBGT, LLC)','WHNT (LOCAL TV ALABAMA LICENSE, LLC)','KCLO (NEXSTAR MEDIA GROUP)','KSWT (BLACKHAWK BROADCASTING)','KSWL (LAKE CHARLES TELEVISION, LLC)','WCMH (NEXSTAR MEDIA GROUP)','WVII (BANGOR COMMUNICATIONS, LLC)','WKBN (LIN LICENSE COMPANY, LLC)','WAVY (WAVY BROADCASTING, LLC)','WFRV (NEXSTAR MEDIA GROUP)','KTSM (NEXSTAR MEDIA GROUP)','WLKY (HEARST TELEVISION INC.)','WCVB (HEARST TELEVISION INC.)','WDSU (HEARST TELEVISION INC.)','WTXL (WTXL-TV LICENSE LLC)','WMTW (HEARST TELEVISION INC.)','KMID (NEXSTAR MEDIA GROUP)','WVTM (HEARST TELEVISION INC.)','WJCL (WJCL HEARST TELEVISION, LLC)','WKBW (SCRIPPS HOWARD BCSTG. CO.)','WNNE (HEARST TELEVISION INC.)','KIAH (NEXSTAR MEDIA GROUP)','KOFY (GRANITE BROADCASTING CORP.)','WGFL (SINCLAIR BROADCAST GROUP)','KRXI (KRXI LICENSEE, LLC)','WMSN (SINCLAIR BROADCAST GROUP)','WLOS 
(SINCLAIR BROADCAST GROUP)','KMYS (Deerfield Media)','KOVR (CBS TELEVISION STATIONS)','KBTV (Deerfield Media)','KMCI (SCRIPPS HOWARD BCSTG. CO.)','WSTR (Deerfield Media)','WWL (TEGNA, INC.)','WFXP (MISSION BROADCASTING, INC.)','KARD (NEXSTAR MEDIA GROUP)','KSHV (NEXSTAR MEDIA GROUP)','WBUP (Lake Superior Community Broadcasting Corporation)','WBDT (WBDT TELEVISION, LLC)','WHNS (MEREDITH CORPORATION)','WBRL (NEXSTAR MEDIA GROUP)','WKEF (SINCLAIR BROADCAST GROUP)','KRBK (NEXSTAR MEDIA GROUP)','WWCP (PEAK MEDIA OF PA. LLC)','WNEP (TEGNA, INC.)','KING (TEGNA, INC.)','WTVF (SCRIPPS HOWARD BCSTG. CO.)','KPRC (GRAHAM MEDIA GROUP, INC.)','KETK (NEXSTAR MEDIA GROUP)','KFXF (GRAY COMMUNICATIONS SYSTEMS)','KWBQ (KASY-TV LICENSEE LLC)','WPCW (CBS TELEVISION STATIONS)','KGNS (YELLOWSTONE LICENSECO LLC)','KRVU (SAINTE PARTNERS II, L.P.)','KOSA (GRAY TELEVISION LICENSEE, LLC)','WIFS (BYRNE ACQUISITION GROUP, LLC)','WLFI (Allen Media Broadcasting LLC)','WYZZ (CUNNINGHAM BROADCASTING)','WBRC (WBRC, LLC)
','KFXO (NEWS PRESS AND GAZETTE CO)','WFTV (COX COMMUNICATIONS)','WFVX (ROCKFLEET BROADCASTING, INC.)','WVFX (GRAY TELEVISION LICENSEE, LLC)','WICZ (STAINLESS BROADCASTING, LLC)','WNTZ (NEXSTAR MEDIA GROUP)','WVAW (LOCKWOOD BROADCASTING)','WBXX (GRAY COMMUNICATIONS SYSTEMS)','WLNE (CITADEL COMMUNICATIONS, LLC)','WSNN (CITADEL COMMUNICATIONS)','KASN (MISSION BROADCASTING, INC.)','WBZ (CBS TELEVISION STATIONS)','KGUN (SCRIPPS HOWARD BCSTG. CO.)','KTXD (CUNNINGHAM BROADCASTING)','KASA (RAMAR COMMUNICATIONS, INC.)','WBUI (GOCOM MEDIA OF ILLINOIS, LLC)','WMDT (Marquee Broadcasting)','KWWL (QUINCY BROADCASTING)','NVIA (NEWS PRESS AND GAZETTE CO)','KTTU (TUCKER OPERATING CO. LLC)','WXSP (WOOD TELEVISION, LLC)','KICU (FOX TELEVISION STATIONS, INC.)','WPMT (TEGNA, INC.)','KNVA (Vaughan Media)','WUHF (SINCLAIR BROADCAST GROUP)','KBJR (KBJR LICENSE, LLC)','WTTO (SINCLAIR BROADCAST GROUP)','KPXJ (WRAY PROPERTIES TRUST)','WTVJ (NATIONAL BROADCASTING CO.)');
existing_records number;
begin
	for i in deal 
		loop  
		existing_records := 0;  
		select count(*) into existing_records from dart_b2b2.rpm_deal_product_synd where rpm_request_id = i.rpmrequestid;  
		 delete from dart_b2b2.RPM_DEAL_PRODUCT_STATION_SYND where rpm_request_id = i.rpmrequestid;  
		 if existing_records > 0 then  
			update dart_b2b2.rpm_deal_product_synd set COMMENTS=TRIM(i.COMMENTS),   
				CONTRACT_NO=TRIM(i.CONTRACTNO), CUSTOMER_NAME=TRIM(i.CUSTOMERNAME), DEAL_PRODUCT_ID=i.DEALPRODUCTID, DELIVER_BY_DT=TO_DATE(i.DELIVERBYDATE, 'YYYY-MM-DD'),DELIVERY_LEAD_DAYS=DECODE(i.DELIVERYLEADDAYS, null, '120', i.DELIVERYLEADDAYS),EIDR_ID=i.EIDRID,    
				EXHIBITION_END_DT=CAST(i.EXHIBITIONENDDATE as DATE), EXHIBITION_ST_DT= CAST(i.EXHIBITIONSTARTDATE as DATE),GPMS_PRODUCT_ID=i.GPMSPRODUCTID,MPM_NO=i.MPMNO,ORDER_DESC=TRIM(i.ORDERDESCRIPTION),ORDER_NO=i.ORDERNO,PRIMARY_LANGUAGE_LKP_ID=i.PRIMARYLANGUAGEID,PRIMARY_MEDIA_LKP_ID=i.PRIMARYMEDIAID,    
				PRIMARY_TERRITORY_LKP_ID=i.PRIMARYTERRITORYID, SALES_PERSON=TRIM(i.SALESPERSON), SOURCE_SYSTEM=i.SOURCESYSTEM, STATION_NAME = TRIM(NVL(SUBSTR(i.STATIONNAME, 0, INSTR(i.STATIONNAME, '(')-1), i.STATIONNAME)), SOURCE_STATION_NAME= TRIM(i.STATIONNAME), SUB_DUB_LKP_ID=null, TERM_YEAR_DESC= TRIM(i.TERMYEARDESCRIPTION), TERM_YEAR_NO=i.TERMYEARNUMBER, TERM_YEAR_STATUS=TRIM(i.TERMYEARSTATUS),    
				TITLE_STATUS=TRIM(i.TITLESTATUS), CREATED_DT=sysdate, LAST_UPDATED_DT=sysdate, CREATED_BY='Migration', LAST_UPDATED_BY='Migration', RPM_STATION_ID=i.STATIONID, CUSTOMER_NO=TRIM(i.CUSTOMERNUMBER), AGREEMENT_ID=i.AGREEMENTID,    
				LICENSE_FEE=i.LICENSEFEE, LICENSE_FEE_CURRENCY=i.LICENSEFEECURRENCY, SUB_DUB_REQUESTED=null, KEY_CATEGORY=i.KEYCATEGORY, PRICE_CATEGORY=i.PRICECATEGORY, MARKET=i.MARKET, AGREEMENT_TYPE=TRIM(i.AGREEMENTTYPE), DEAL_TYPE=TRIM(i.DEALTYPE), SYNDICATION_RUNS=null, CONTRACT_STATUS=TRIM(i.CONTRACTSTATUS),     
				ACTION_LKP_ID = null,    
				CONTRACT_STATUS_LKP_ID = null,    
				GPMS_PROG_ID = 0,    
				GPMS_SEAS_ID = 0,    
				GPMS_EPS_ID = 0,    
				PROG_TYPE= null,    
				PROG_NAME= null,    
        PACKAGE_ID=TRIM(i.PACKAGEID),
        PACKAGE_NAME=TRIM(i.PACKAGENAME)
				where rpm_request_id = i.rpmrequestid;    
		 else  
			insert into dart_b2b2.rpm_deal_product_synd(RPM_REQUEST_ID,COMMENTS,CONTRACT_NO,CUSTOMER_NAME,DEAL_PRODUCT_ID,DELIVER_BY_DT,DELIVERY_LEAD_DAYS,EIDR_ID,   
				EXHIBITION_END_DT,EXHIBITION_ST_DT,GPMS_PRODUCT_ID,MPM_NO,ORDER_DESC,ORDER_NO,PRIMARY_LANGUAGE_LKP_ID,PRIMARY_MEDIA_LKP_ID,    
				PRIMARY_TERRITORY_LKP_ID,SALES_PERSON,SOURCE_SYSTEM,STATION_NAME,SOURCE_STATION_NAME,SUB_DUB_LKP_ID,TERM_YEAR_DESC,TERM_YEAR_NO,TERM_YEAR_STATUS,    
				TITLE_STATUS,CREATED_DT,LAST_UPDATED_DT,CREATED_BY,LAST_UPDATED_BY,RPM_STATION_ID,CUSTOMER_NO,AGREEMENT_ID,    
				LICENSE_FEE,LICENSE_FEE_CURRENCY,SUB_DUB_REQUESTED,KEY_CATEGORY,PRICE_CATEGORY,MARKET,AGREEMENT_TYPE,DEAL_TYPE,SYNDICATION_RUNS,CONTRACT_STATUS,    
				ACTION_LKP_ID,CONTRACT_STATUS_LKP_ID,GPMS_PROG_ID,GPMS_SEAS_ID,GPMS_EPS_ID,PROG_TYPE,PROG_NAME,PACKAGE_ID,PACKAGE_NAME)    
				values(i.RPMREQUESTID,TRIM(i.COMMENTS),i.CONTRACTNO,TRIM(i.CUSTOMERNAME),i.DEALPRODUCTID,TO_DATE(i.DELIVERBYDATE, 'YYYY-MM-DD'),DECODE(i.DELIVERYLEADDAYS, null, '120', i.DELIVERYLEADDAYS),i.EIDRID,CAST(i.EXHIBITIONENDDATE as DATE),CAST(i.EXHIBITIONSTARTDATE as DATE),    
				i.GPMSPRODUCTID,i.MPMNO,TRIM(i.ORDERDESCRIPTION),i.ORDERNO,i.PRIMARYLANGUAGEID,i.PRIMARYMEDIAID,    
				i.PRIMARYTERRITORYID,TRIM(i.SALESPERSON),i.SOURCESYSTEM,TRIM(NVL(SUBSTR(i.STATIONNAME, 0, INSTR(i.STATIONNAME, '(')-1), i.STATIONNAME)),TRIM(i.STATIONNAME),null,TRIM(i.TERMYEARDESCRIPTION),i.TERMYEARNUMBER,TRIM(i.TERMYEARSTATUS),    
				TRIM(i.TITLESTATUS),sysdate,sysdate,'Migration','Migration',i.STATIONID,TRIM(i.CUSTOMERNUMBER),i.AGREEMENTID,    
				i.LICENSEFEE,i.LICENSEFEECURRENCY,null,i.KEYCATEGORY,i.PRICECATEGORY,i.MARKET,TRIM(i.AGREEMENTTYPE),TRIM(i.DEALTYPE),null,TRIM(i.CONTRACTSTATUS),    
				null,    
				null,    
				0,    
				0,    
				0,    
				null,    
				null,    
        TRIM(i.PACKAGEID),
        TRIM(i.PACKAGENAME));
		 end if;   
		    insert into dart_b2b2.RPM_DEAL_PRODUCT_STATION_SYND  
			select i.rpmrequestid, ssm.station_id from dart_b2b2.syndication_station_master ssm where ssm.synd_station_id in (WITH DATA AS(   
			SELECT temp.stationid str FROM dtv_b2b2.TEMP_RPM_SYNDICATION_DATA2 temp    
				where rpmrequestid = i.rpmrequestid)    
				SELECT regexp_substr(str,'[^;]+',1,level) str    
				FROM DATA    
				CONNECT BY regexp_substr(str, '[^;]+', 1, level) IS NOT NULL);    
      commit;
		end loop;           
END MIGRATE_DATA_TO_DEAL_PRODUCT_SYND_BATCH_6;
/


  CREATE OR REPLACE EDITIONABLE PROCEDURE "DART_B2B2"."MIGRATE_DATA_TO_DEAL_PRODUCT_SYND_BATCH_7" 
IS 
cursor deal is
	select * from dtv_b2b2.TEMP_RPM_SYNDICATION_DATA2 where STATIONNAME in('KATU (SINCLAIR PORTLAND LICENSEE,LLC)','KTVQ (SCRIPPS HOWARD BCSTG. CO.)','WACY (SCRIPPS HOWARD BCSTG. CO.)','KRTV (SCRIPPS HOWARD BCSTG. CO.)','WFOR (CBS TELEVISION STATIONS)','KUSI (MCKINNON BROADCASTING)','WICU (SJL BROADCAST MANAGEMENT)','KPAX (SCRIPPS HOWARD BCSTG. CO.)','WFIE (WFIE, LLC)','WZVN (Montclair Communications, Inc.)','WSAV (NEXSTAR MEDIA GROUP)','WDIO (HUBBARD BROADCASTING, INC.)','WVBT (WAVY BROADCASTING, LLC)','WFGX (SINCLAIR BROADCAST GROUP)','WTEN (NEXSTAR MEDIA GROUP)','KXLF (SCRIPPS HOWARD BCSTG. CO.)','WFTS (SCRIPPS HOWARD BCSTG. CO.)','KTBS (KTBS, INC.)','WNYA (WNYT-TV, LLC)','KXLH (SCRIPPS HOWARD BCSTG. CO.)','KATC (SCRIPPS HOWARD BCSTG. CO.)','WAOE (FOUR SEASONS BROADCASTING, LLC)','WDAM (WDAM, LLC)','KCPM (G.I.G.,INC.)','WRLH (SINCLAIR BROADCAST GROUP)','KXVO (MITTS BROADCASTING, LLC)','KCVU (CUNNINGHAM BROADCASTING)','WSTQ (WSTQ LICENSEE, LLC)','WVAH (WVAH LICENSEE, LLC)','KGWC (BIG HO 
RN COMMUNICATIONS)','WPBN (WPBN LICENSEE, LLC)','KFXA (SINCLAIR BROADCAST GROUP)','KIMA (SINCLAIR YAKIMA LICENSEE, LLC)','WBNA (Word Broadcasting Network, Inc.)','WWMT (WWMT LICENSEE, LLC)','KRGV (MANSHIP STATIONS)','WDTV (GRAY TELEVISION LICENSEE, LLC)','WFXG (LOCKWOOD BROADCASTING)','WTWC (SINCLAIR BROADCAST GROUP)','WGXA (WGXA LICENSEE, LLC)','KDFI (FOX TELEVISION STATIONS, INC.)','KAMC (MISSION BROADCASTING, INC.)','WDFX (LOCKWOOD BROADCASTING)','KTVL (KTVL LICENSEE, LLC)','KSBY (SCRIPPS HOWARD BCSTG. CO.)','WSBT (WLUC LICENSEE, LLC)','KVRR (RED RIVER BROADCASTING CORP.)','WPMI (DEERFIELD MEDIA LICENSEE, LLC)','WPSG (CBS TELEVISION STATIONS)','WMYV (WUPN, LLC)','WCWN (WCWN LICENSEE, LLC)','WWMB (Howard Stirk Holdings)','WNWO (WNWO LICENSEE, LLC)','KCPN (MISSION BROADCASTING, INC.)','WTWO (NEXSTAR BROADCASTING GROUP LLC)','KTUL (KTUL LICENSEE, LLC)','KSCC (SINCLAIR BROADCAST GROUP)','KFRE (TTBG/KFRE LICENSE SUB, LLC)','WPGX (WPGX, LLC)','KBVU (CUNNINGHAM BROADCASTING)','WCTI (SINCLA
IR BROADCAST GROUP)','WQMY (SINCLAIR BROADCAST GROUP)','WDVM (NEXSTAR MEDIA GROUP)','KXTU (NEXSTAR MEDIA GROUP)','WATN (TEGNA, INC.)','WLBZ (TEGNA, INC.)','WVEC (TEGNA, INC.)','KSDK (TEGNA, INC.)','WJMN (NEXSTAR MEDIA GROUP)','WFAA (TEGNA, INC.)','WLTX (TEGNA, INC.)','WMAZ (GANNETT GEORGIA, L.P.)','KPNX (TEGNA, INC.)','KSCW (GRAY TELEVISION LICENSEE, LLC)','KNTV (NATIONAL BROADCASTING CO.)','WNBC (NATIONAL BROADCASTING CO.)','WDIV (GRAHAM MEDIA GROUP, INC.)','KJBO (MISSION BROADCASTING, INC.)','WVIT (NATIONAL BROADCASTING CO.)','KMCY (FORUM COMMUNICATIONS)','WTVT (FOX TELEVISION STATIONS, INC.)','WTLW (AMERICAN CHRISTIAN TELEVISION)','KHGI (KHGI LICENSEE, LLC)','WHMB (LESEA BROADCASTING, INC.)','WADL (ADELL BROADCASTING CORP.)','WWTI (NEXSTAR MEDIA GROUP)','KJRW (NORTHWEST BROADCASTING, INC.)','WMBD (NEXSTAR MEDIA GROUP)','WXXA (WXXA-TV LLC)','KFVS (KFVS, LLC)','WKCF (HEARST TELEVISION INC.)','KQCA (HEARST TELEVISION INC.)','KFOR (LOCAL TV OKLAHOMA LICENSE, LLC)','WPNT (SINCLAIR BROADC
AST GROUP)','WGN (NEXSTAR MEDIA GROUP)','KBCW (CBS TELEVISION STATIONS)','WNOL (NEXSTAR MEDIA GROUP)','KTLA (NEXSTAR MEDIA GROUP)','WTTE (CUNNINGHAM BROADCASTING)','WLVI (SUNBEAM TELEVISION)','WUTB (DEERFIELD MEDIA LICENSEE, LLC)','WACH (WACH LICENSEE, LLC)','WDJT (WEIGEL BROADCASTING)','WJXX (TEGNA, INC.)','KOTV (GRIFFIN TELEVISION TULSA, LLC)','WTKR (LOCAL TV VIRGINIA LICENSEE LLC)','WPVI (ABC/CAPITAL CITIES)','KTVT (CBS TELEVISION STATIONS)','KHNL (GRAY TELEVISION, LLC)','KKTV (GRAY COMMUNICATIONS SYSTEMS)','WOI (TEGNA, INC.)','KFBI (BROADCASTING LICENSES, L.P.)','WBPN (STAINLESS BROADCASTING, LLC)','KTVM (SINCLAIR BROADCAST GROUP)','KULR (COWLES COMMUNICATIONS)','KMSS (MISSION BROADCASTING, INC.)','WTOL (WTOL TELEVISION, LLC)','KERO (SCRIPPS HOWARD BCSTG. CO.)','KMYL (GRAY COMMUNICATIONS SYSTEMS)','KXMC (NEXSTAR MEDIA GROUP)','WVUE (WVUE LICENSE SUBSIDIARY, LLC)','WNDY (INDIANA BROADCASTING, LLC)','WMYD (SCRIPPS HOWARD BCSTG. CO.)','KRHD (SCRIPPS HOWARD BCSTG. CO.)','WAVE (GRAY COM
MUNICATIONS SYSTEMS)','KXD (GRAY COMMUNICATIONS SYSTEMS)','KAUZ (KAUZ LICENSE SUBSIDIARY, LLC)','WCCT (TEGNA, INC.)','KTAB (NEXSTAR MEDIA GROUP)','WAAY (ALABAMA TV LICENSE COMPANY LLC)','KLAF (BCBL LICENSE SUBSIDIARY, LLC)','WFFT (Allen Media Broadcasting LLC)','KLST (NEXSTAR MEDIA GROUP)','KRCR (SINCLAIR BROADCAST GROUP)','KCBA (SEAL ROCK BROADCASTERS, LLC)','KMYT (COX TELEVISION TULSA, LLC)','WXLV (SINCLAIR BROADCAST GROUP)','WOWK (NEXSTAR MEDIA GROUP)','KIMT (Allen Media Broadcasting LLC)','KFXK (NEXSTAR MEDIA GROUP)','KECI (SINCLAIR BROADCAST GROUP)','KMIZ (NPG OF MISSOURI, LLC)','WAOW (QUINCY BROADCASTING)','WALA (MEREDITH CORPORATION)','WHTV (SPARTAN-TV, LLC)','WBSF (CUNNINGHAM BROADCASTING)','WPGA (Marquee Broadcasting)','KADN (BCBL LICENSE SUBSIDIARY, LLC)','KYCW (GREY TELEVISION LICENSEE, LLC)','WANE (INDIANA BROADCASTING, LLC)','KBMY (FORUM COMMUNICATIONS)','WUSA (TEGNA, INC.)','KALB (GRAY TELEVISION LICENSEE, LLC)','KNOE (GRAY TELEVISION LICENSEE, LLC)','KEVU (CALIF)','KARE 
(TEGNA, INC.)','KCOP (FOX TELEVISION STATIONS, INC.)','WRIC (NEXSTAR MEDIA GROUP)','WLOX (WLOX, LLC)','WGSA (Tri)','KDUH (GRAY COMMUNICATIONS SYSTEMS)','KOTA (GRAY TELEVISION LICENSEE, LLC)','KCFW (SINCLAIR BROADCAST GROUP)','KFQX (PARKER BROADCASTING OF CO, LLC)','WMEU (WEIGEL BROADCASTING)','WEMT (CUNNINGHAM BROADCASTING)','WGBA (SCRIPPS HOWARD BCSTG. CO.)','WSFX (WSFX LICENSE SUBSIDIARY, LLC)','KUSA (TEGNA, INC.)','KSAW (SCRIPPS HOWARD BCSTG. CO.)','WLNY (CBS LITV LLC)','KZJO (FOX TELEVISION STATIONS, INC.)','KIDK (VISTAWEST MEDIA, LLC)','WWBT (WWBT LICENSE SUBSIDIARY, LLC)','KXMA (REITEN TELEVISION)','KTKA (Vaughan Media)','WTNH (WTNH BROADCASTING, LLC)','WCAV (LOCKWOOD BROADCASTING)','WTGS (WTGS LICENSEE, LLC)','KIVI (SCRIPPS HOWARD BCSTG. CO.)','KTRV (BLOCK COMMUNICATIONS)');
existing_records number;
begin
	for i in deal 
		loop  
		existing_records := 0;  
		select count(*) into existing_records from dart_b2b2.rpm_deal_product_synd where rpm_request_id = i.rpmrequestid;  
		 delete from dart_b2b2.RPM_DEAL_PRODUCT_STATION_SYND where rpm_request_id = i.rpmrequestid;  
		 if existing_records > 0 then  
			update dart_b2b2.rpm_deal_product_synd set COMMENTS=TRIM(i.COMMENTS),   
				CONTRACT_NO=TRIM(i.CONTRACTNO), CUSTOMER_NAME=TRIM(i.CUSTOMERNAME), DEAL_PRODUCT_ID=i.DEALPRODUCTID, DELIVER_BY_DT=TO_DATE(i.DELIVERBYDATE, 'YYYY-MM-DD'),DELIVERY_LEAD_DAYS=DECODE(i.DELIVERYLEADDAYS, null, '120', i.DELIVERYLEADDAYS),EIDR_ID=i.EIDRID,    
				EXHIBITION_END_DT=CAST(i.EXHIBITIONENDDATE as DATE), EXHIBITION_ST_DT= CAST(i.EXHIBITIONSTARTDATE as DATE),GPMS_PRODUCT_ID=i.GPMSPRODUCTID,MPM_NO=i.MPMNO,ORDER_DESC=TRIM(i.ORDERDESCRIPTION),ORDER_NO=i.ORDERNO,PRIMARY_LANGUAGE_LKP_ID=i.PRIMARYLANGUAGEID,PRIMARY_MEDIA_LKP_ID=i.PRIMARYMEDIAID,    
				PRIMARY_TERRITORY_LKP_ID=i.PRIMARYTERRITORYID, SALES_PERSON=TRIM(i.SALESPERSON), SOURCE_SYSTEM=i.SOURCESYSTEM, STATION_NAME = TRIM(NVL(SUBSTR(i.STATIONNAME, 0, INSTR(i.STATIONNAME, '(')-1), i.STATIONNAME)), SOURCE_STATION_NAME= TRIM(i.STATIONNAME), SUB_DUB_LKP_ID=null, TERM_YEAR_DESC= TRIM(i.TERMYEARDESCRIPTION), TERM_YEAR_NO=i.TERMYEARNUMBER, TERM_YEAR_STATUS=TRIM(i.TERMYEARSTATUS),    
				TITLE_STATUS=TRIM(i.TITLESTATUS), CREATED_DT=sysdate, LAST_UPDATED_DT=sysdate, CREATED_BY='Migration', LAST_UPDATED_BY='Migration', RPM_STATION_ID=i.STATIONID, CUSTOMER_NO=TRIM(i.CUSTOMERNUMBER), AGREEMENT_ID=i.AGREEMENTID,    
				LICENSE_FEE=i.LICENSEFEE, LICENSE_FEE_CURRENCY=i.LICENSEFEECURRENCY, SUB_DUB_REQUESTED=null, KEY_CATEGORY=i.KEYCATEGORY, PRICE_CATEGORY=i.PRICECATEGORY, MARKET=i.MARKET, AGREEMENT_TYPE=TRIM(i.AGREEMENTTYPE), DEAL_TYPE=TRIM(i.DEALTYPE), SYNDICATION_RUNS=null, CONTRACT_STATUS=TRIM(i.CONTRACTSTATUS),     
				ACTION_LKP_ID = null,    
				CONTRACT_STATUS_LKP_ID = null,    
				GPMS_PROG_ID = 0,    
				GPMS_SEAS_ID = 0,    
				GPMS_EPS_ID = 0,    
				PROG_TYPE= null,    
				PROG_NAME= null,    
        PACKAGE_ID=TRIM(i.PACKAGEID),
        PACKAGE_NAME=TRIM(i.PACKAGENAME)
				where rpm_request_id = i.rpmrequestid;    
		 else  
			insert into dart_b2b2.rpm_deal_product_synd(RPM_REQUEST_ID,COMMENTS,CONTRACT_NO,CUSTOMER_NAME,DEAL_PRODUCT_ID,DELIVER_BY_DT,DELIVERY_LEAD_DAYS,EIDR_ID,   
				EXHIBITION_END_DT,EXHIBITION_ST_DT,GPMS_PRODUCT_ID,MPM_NO,ORDER_DESC,ORDER_NO,PRIMARY_LANGUAGE_LKP_ID,PRIMARY_MEDIA_LKP_ID,    
				PRIMARY_TERRITORY_LKP_ID,SALES_PERSON,SOURCE_SYSTEM,STATION_NAME,SOURCE_STATION_NAME,SUB_DUB_LKP_ID,TERM_YEAR_DESC,TERM_YEAR_NO,TERM_YEAR_STATUS,    
				TITLE_STATUS,CREATED_DT,LAST_UPDATED_DT,CREATED_BY,LAST_UPDATED_BY,RPM_STATION_ID,CUSTOMER_NO,AGREEMENT_ID,    
				LICENSE_FEE,LICENSE_FEE_CURRENCY,SUB_DUB_REQUESTED,KEY_CATEGORY,PRICE_CATEGORY,MARKET,AGREEMENT_TYPE,DEAL_TYPE,SYNDICATION_RUNS,CONTRACT_STATUS,    
				ACTION_LKP_ID,CONTRACT_STATUS_LKP_ID,GPMS_PROG_ID,GPMS_SEAS_ID,GPMS_EPS_ID,PROG_TYPE,PROG_NAME,PACKAGE_ID,PACKAGE_NAME)    
				values(i.RPMREQUESTID,TRIM(i.COMMENTS),i.CONTRACTNO,TRIM(i.CUSTOMERNAME),i.DEALPRODUCTID,TO_DATE(i.DELIVERBYDATE, 'YYYY-MM-DD'),DECODE(i.DELIVERYLEADDAYS, null, '120', i.DELIVERYLEADDAYS),i.EIDRID,CAST(i.EXHIBITIONENDDATE as DATE),CAST(i.EXHIBITIONSTARTDATE as DATE),    
				i.GPMSPRODUCTID,i.MPMNO,TRIM(i.ORDERDESCRIPTION),i.ORDERNO,i.PRIMARYLANGUAGEID,i.PRIMARYMEDIAID,    
				i.PRIMARYTERRITORYID,TRIM(i.SALESPERSON),i.SOURCESYSTEM,TRIM(NVL(SUBSTR(i.STATIONNAME, 0, INSTR(i.STATIONNAME, '(')-1), i.STATIONNAME)),TRIM(i.STATIONNAME),null,TRIM(i.TERMYEARDESCRIPTION),i.TERMYEARNUMBER,TRIM(i.TERMYEARSTATUS),    
				TRIM(i.TITLESTATUS),sysdate,sysdate,'Migration','Migration',i.STATIONID,TRIM(i.CUSTOMERNUMBER),i.AGREEMENTID,    
				i.LICENSEFEE,i.LICENSEFEECURRENCY,null,i.KEYCATEGORY,i.PRICECATEGORY,i.MARKET,TRIM(i.AGREEMENTTYPE),TRIM(i.DEALTYPE),null,TRIM(i.CONTRACTSTATUS),    
				null,    
				null,    
				0,    
				0,    
				0,    
				null,    
				null,    
        TRIM(i.PACKAGEID),
        TRIM(i.PACKAGENAME));
		 end if;   
		    insert into dart_b2b2.RPM_DEAL_PRODUCT_STATION_SYND  
			select i.rpmrequestid, ssm.station_id from dart_b2b2.syndication_station_master ssm where ssm.synd_station_id in (WITH DATA AS(   
			SELECT temp.stationid str FROM dtv_b2b2.TEMP_RPM_SYNDICATION_DATA2 temp    
				where rpmrequestid = i.rpmrequestid)    
				SELECT regexp_substr(str,'[^;]+',1,level) str    
				FROM DATA    
				CONNECT BY regexp_substr(str, '[^;]+', 1, level) IS NOT NULL);    
      commit;
		end loop;           
END MIGRATE_DATA_TO_DEAL_PRODUCT_SYND_BATCH_7;
/


  CREATE OR REPLACE EDITIONABLE PROCEDURE "DART_B2B2"."MIGRATE_LOOKUP_DATA_TO_DEAL_PRODUCT_SYND" 
IS 
begin
update dart_b2b2.rpm_deal_product_synd rdp set (ACTION_LKP_ID, CONTRACT_STATUS_LKP_ID) = 
( select (select lkp_id from dart_b2b2.lookup_value where lkp_type_id = 12000 and lower(value) = lower(i.action)),
 (select lkp_id from dart_b2b2.lookup_value where lkp_type_id = 11000 and lower(value) = lower(i.CONTRACTSTATUS))
 from dtv_b2b2.TEMP_RPM_SYNDICATION_DATA2 i where i.rpmrequestid = rdp.rpm_Request_id) ;  
end MIGRATE_LOOKUP_DATA_TO_DEAL_PRODUCT_SYND;
/


  CREATE OR REPLACE EDITIONABLE PROCEDURE "DART_B2B2"."PROG_MANAGE_RUNNO_SYND_PROC" (
    gProgId         IN VARCHAR2,
    SYNDICATIONRUNS         IN VARCHAR2,
    stationName    IN VARCHAR2 )
as
   v_count             NUMBER;
   v_weekend_count             NUMBER;
   v_cust_name VARCHAR2 (255);
   v_lkp_num VARCHAR2(255);
   is_updated BOOLEAN;
   is_weekend_updated BOOLEAN;
   v_weekend_lkp_num VARCHAR2(255);
BEGIN
  
  select count(*) into v_count from DTV_B2B2.PROG_MANAGE_RUNNO_SYND where gpms_id = gProgId and STATION_NAME = stationName and lkp_runnum in (2301,2302,2303);
  is_updated := false;
  if v_count != 0 then
      DBMS_OUTPUT.put_line (' vcount found'); 
      SELECT CASE
          WHEN SYNDICATIONRUNS LIKE '%600157971%' THEN 
            'true'
          END into v_lkp_num
      FROM dual;   
        if v_lkp_num = 'true' AND is_updated = false then
          update DTV_B2B2.PROG_MANAGE_RUNNO_SYND set lkp_runnum = 2303 where gpms_id = gProgId and station_name = stationName and lkp_runnum in (2301,2302,2303);
          commit;
          is_updated := true;
        end if;
      
      SELECT CASE
          WHEN SYNDICATIONRUNS LIKE '%600157969%' THEN 
            'true'
          END into v_lkp_num
      FROM dual;   
        if v_lkp_num = 'true' AND is_updated = false then
          update DTV_B2B2.PROG_MANAGE_RUNNO_SYND set lkp_runnum = 2302 where gpms_id = gProgId and station_name = stationName and lkp_runnum in (2301,2302,2303);
          commit;
          is_updated := true;
        end if;
      
      SELECT CASE
          WHEN SYNDICATIONRUNS LIKE '%600157967%' THEN 
            'true'
          END into v_lkp_num
      FROM dual;   
        if v_lkp_num = 'true' AND is_updated = false then
          update DTV_B2B2.PROG_MANAGE_RUNNO_SYND set lkp_runnum = 2301 where gpms_id = gProgId and station_name = stationName and lkp_runnum in (2301,2302,2303);
          commit;
          is_updated := true;
        end if;
     
      ELSE
          DBMS_OUTPUT.put_line (' vcount found'); 
          SELECT CASE
            WHEN SYNDICATIONRUNS LIKE '%600157971%' THEN 
            'true'
          END into v_lkp_num
         FROM dual;   
            if v_lkp_num = 'true' AND is_updated = false then
              Insert into DTV_B2B2.PROG_MANAGE_RUNNO_SYND (ID,PROG_ID,GPMS_ID,LKP_RUNNUM,LKP_DIST_TYPE_ID,STATION_NAME,IS_DELETED,CREATED_BY,CREATED_DT,LAST_UPDATED_BY,LAST_UPDATED_DT,VERSION) 
              values (DART_B2B2.PROG_MANAGE_RUNNO_SYND_SEQ.nextval,null,gProgId,2303,5040,stationName,0,'RPM JMS',SYSDATE,'RPM JMS',SYSDATE,0);
              commit;
              is_updated := true;
            end if;
        
        SELECT CASE
            WHEN SYNDICATIONRUNS LIKE '%600157969%' THEN 
            'true'
        END into v_lkp_num
        FROM dual;   
            if v_lkp_num = 'true' AND is_updated = false then
              Insert into DTV_B2B2.PROG_MANAGE_RUNNO_SYND (ID,PROG_ID,GPMS_ID,LKP_RUNNUM,LKP_DIST_TYPE_ID,STATION_NAME,IS_DELETED,CREATED_BY,CREATED_DT,LAST_UPDATED_BY,LAST_UPDATED_DT,VERSION) 
              values (DART_B2B2.PROG_MANAGE_RUNNO_SYND_SEQ.nextval,null,gProgId,2302,5040,stationName,0,'RPM JMS',SYSDATE,'RPM JMS',SYSDATE,0);
              commit;
              is_updated := true;
            end if;
        
        SELECT CASE
            WHEN SYNDICATIONRUNS LIKE '%600157967%' THEN 
                'true'
            END into v_lkp_num
        FROM dual;   
          if v_lkp_num = 'true' AND is_updated = false then
              Insert into DTV_B2B2.PROG_MANAGE_RUNNO_SYND (ID,PROG_ID,GPMS_ID,LKP_RUNNUM,LKP_DIST_TYPE_ID,STATION_NAME,IS_DELETED,CREATED_BY,CREATED_DT,LAST_UPDATED_BY,LAST_UPDATED_DT,VERSION) 
              values (DART_B2B2.PROG_MANAGE_RUNNO_SYND_SEQ.nextval,null,gProgId,2301,5040,stationName,0,'RPM JMS',SYSDATE,'RPM JMS',SYSDATE,0);
              commit;
          end if;
      
  END IF;
  
    is_weekend_updated := false;
    select count(*) into v_weekend_count from DTV_B2B2.PROG_MANAGE_RUNNO_SYND where gpms_id = gProgId and STATION_NAME = stationName and lkp_runnum in (2310,2311);
    
    if v_weekend_count != 0 then
    DBMS_OUTPUT.put_line (' v_weekend_count found'); 
      SELECT CASE
          WHEN SYNDICATIONRUNS LIKE '%600157975%' THEN 
            'true'
          END into v_lkp_num
      FROM dual;   
        if v_lkp_num = 'true' AND is_weekend_updated = false then
          update DTV_B2B2.PROG_MANAGE_RUNNO_SYND set lkp_runnum = 2311 where gpms_id = gProgId and station_name = stationName and lkp_runnum  in (2310,2311);
          commit;
          is_weekend_updated := true;
        end if;
    
      SELECT CASE
          WHEN SYNDICATIONRUNS LIKE '%600157973%' THEN 
            'true'
          END into v_lkp_num
      FROM dual;   
        if v_lkp_num = 'true' AND is_weekend_updated = false then
          update DTV_B2B2.PROG_MANAGE_RUNNO_SYND set lkp_runnum = 2310 where gpms_id = gProgId and station_name = stationName and lkp_runnum  in (2310,2311);
          commit;
          is_weekend_updated := true;
        end if;
      ELSE
    DBMS_OUTPUT.put_line (' v_weekend_count not found'); 
          SELECT CASE
            WHEN SYNDICATIONRUNS LIKE '%600157975%' THEN 
            'true'
            END into v_lkp_num
          FROM dual;   
            if v_lkp_num = 'true' AND is_weekend_updated = false then
              Insert into DTV_B2B2.PROG_MANAGE_RUNNO_SYND (ID,PROG_ID,GPMS_ID,LKP_RUNNUM,LKP_DIST_TYPE_ID,STATION_NAME,IS_DELETED,CREATED_BY,CREATED_DT,LAST_UPDATED_BY,LAST_UPDATED_DT,VERSION) 
              values (DART_B2B2.PROG_MANAGE_RUNNO_SYND_SEQ.nextval,null,gProgId,2311,5040,stationName,0,'RPM JMS',SYSDATE,'RPM JMS',SYSDATE,0);
              commit;
              is_weekend_updated := true;
            end if;
    
          SELECT CASE
            WHEN SYNDICATIONRUNS LIKE '%600157973%' THEN 
            'true'
          END into v_lkp_num
          FROM dual;   
              if v_lkp_num = 'true' AND is_weekend_updated = false then
                Insert into DTV_B2B2.PROG_MANAGE_RUNNO_SYND (ID,PROG_ID,GPMS_ID,LKP_RUNNUM,LKP_DIST_TYPE_ID,STATION_NAME,IS_DELETED,CREATED_BY,CREATED_DT,LAST_UPDATED_BY,LAST_UPDATED_DT,VERSION) 
                values (DART_B2B2.PROG_MANAGE_RUNNO_SYND_SEQ.nextval,null,gProgId,2310,5040,stationName,0,'RPM JMS',SYSDATE,'RPM JMS',SYSDATE,0);
                commit;
          end if;
        
    END IF;
  
END PROG_MANAGE_RUNNO_SYND_PROC;
/


  CREATE OR REPLACE EDITIONABLE PROCEDURE "DART_B2B2"."RPM_STITCHING_TEMP" 
as 
CURSOR DEALS
  IS
    SELECT DISTINCT RDP.GPMS_PROG_ID,
      RDP.GPMS_SEAS_ID,
      IST.STATION_ID AS B2B_STATION_ID,
      IST.STATION_NAME,
      IST.RPM_STATION_ID,
      RDP.PROG_NAME,
      RDP.SALES_PERSON,
      RDP.SEASON_NUM,
      RDP.PROG_TYPE
    FROM RPM_DEAL_PRODUCT RDP
    JOIN RPM_DEAL_PRODUCT_STATION RS
    ON RS.RPM_REQUEST_ID                          = RDP.RPM_REQUEST_ID
    JOIN INTL_STATION IST
    ON RS.B2B_STATION_ID                           = IST.STATION_ID
    WHERE RDP.GPMS_PROG_ID                         !=0
    AND RDP.RPM_STATION_ID                         IS NOT NULL
    AND RDP.rpm_Request_id in ('24417898', '24417899');
  ------------variables declartions starts--------------------------------------------
  EXHIBITION_END_DT_V         TIMESTAMP(6)   := NULL;
  EXHIBITION_ST_DT_V          TIMESTAMP(6)   := NULL;
  DELIVER_BY_DT_V             TIMESTAMP(6)   := NULL;
  ALREADY_STITCHED_V          NUMBER(10)     := 0;
  TERRITORY_VALUE_CSV_V       VARCHAR2(4000) :=NULL;
  TERRITORY_ID_CSV_V          VARCHAR2(4000) := NULL;
  CONTRACT_STATUS_VALUE_CSV_V VARCHAR2(4000) :=NULL;
  CONTRACT_STATUS_TYPE_CSV_V  VARCHAR2(4000) :=NULL;
  LICENSE_TYPE_ID_CSV_V       VARCHAR2(4000) := NULL;
  LICENSE_TYPE_VALUE_CSV_V    VARCHAR2(4000) :=NULL;
  ------------variables declartions ends--------------------------------------------
BEGIN
  FOR I IN DEALS
  LOOP
    SELECT COUNT(*) INTO ALREADY_STITCHED_V FROM RPM_DEAL_PRODUCT_STITCHED
    WHERE GPMS_PROG_ID = I.GPMS_PROG_ID
    AND GPMS_SEAS_ID   = I.GPMS_SEAS_ID
    AND STATION_ID     = I.B2B_STATION_ID;

    SELECT GET_DEAL_TERRITORY_CSV(I.GPMS_PROG_ID,I.GPMS_SEAS_ID,I.B2B_STATION_ID) INTO TERRITORY_VALUE_CSV_V FROM DUAL;
    SELECT GET_DEAL_TERRITORY_IDS(I.GPMS_PROG_ID,I.GPMS_SEAS_ID,I.B2B_STATION_ID) INTO TERRITORY_ID_CSV_V FROM DUAL;
    SELECT GET_DEAL_CONTRACTSTATUS_CSV(I.GPMS_PROG_ID,I.GPMS_SEAS_ID,I.B2B_STATION_ID) INTO CONTRACT_STATUS_VALUE_CSV_V FROM DUAL;
    SELECT GET_DEAL_CONTRACTTYPE_CSV(I.GPMS_PROG_ID,I.GPMS_SEAS_ID,I.B2B_STATION_ID) INTO CONTRACT_STATUS_TYPE_CSV_V FROM DUAL;
    SELECT GET_LICENSETYPE_IDS(I.GPMS_PROG_ID,I.GPMS_SEAS_ID,I.B2B_STATION_ID) INTO LICENSE_TYPE_ID_CSV_V FROM DUAL;
    SELECT GET_LICENSETYPE_VALUES(I.GPMS_PROG_ID,I.GPMS_SEAS_ID,I.B2B_STATION_ID) INTO LICENSE_TYPE_VALUE_CSV_V FROM DUAL;

    IF (I.GPMS_SEAS_ID IS NOT NULL) THEN
      SELECT MAX(RDP.EXHIBITION_END_DT)   AS EXHIBITION_END_DT,
        MIN(RDP.EXHIBITION_ST_DT)         AS EXHIBITION_ST_DT,
        (MIN(RDP.EXHIBITION_ST_DT) - 120) AS DELIVER_BY_DT
      INTO EXHIBITION_END_DT_V,
        EXHIBITION_ST_DT_V,
        DELIVER_BY_DT_V
      FROM RPM_DEAL_PRODUCT RDP,
        RPM_DEAL_PRODUCT_STATION RDPS
      WHERE RDP.GPMS_PROG_ID               = I.GPMS_PROG_ID
      AND RDP.GPMS_SEAS_ID                 = I.GPMS_SEAS_ID
      AND RDPS.B2B_STATION_ID              = I.B2B_STATION_ID
      AND RDPS.RPM_REQUEST_ID              = RDP.RPM_REQUEST_ID
      AND RDP.GPMS_PROG_ID                !=0
      AND RDP.RPM_STATION_ID              IS NOT NULL
      AND RDP.RPM_REQUEST_ID IN ('24417898', '24417899');
    END IF;
    /*
    -- Commenting this block as I.GPMS_SEAS_ID will never be null since default value is 0
    -- Keepingt this block commented for now, should be removed after a month if no issues are reported / observed
    -- updated date : 08/17/2021
    IF (I.GPMS_SEAS_ID IS NULL) THEN
      SELECT MAX(RDP.EXHIBITION_END_DT)   AS EXHIBITION_END_DT,
        MIN(RDP.EXHIBITION_ST_DT)         AS EXHIBITION_ST_DT,
        (MIN(RDP.EXHIBITION_ST_DT) - 120) AS DELIVER_BY_DT
      INTO EXHIBITION_END_DT_V,
        EXHIBITION_ST_DT_V,
        DELIVER_BY_DT_V
      FROM RPM_DEAL_PRODUCT RDP,
        RPM_DEAL_PRODUCT_STATION RDPS
      WHERE RDP.GPMS_PROG_ID               = I.GPMS_PROG_ID
      AND RDP.GPMS_SEAS_ID                IS NULL
      AND RDPS.B2B_STATION_ID              = I.B2B_STATION_ID
      AND RDPS.RPM_REQUEST_ID              = RDP.RPM_REQUEST_ID
      AND RDP.GPMS_PROG_ID                !=0
      AND RDP.RPM_STATION_ID              IS NOT NULL
      AND ((LOWER(TRIM(RDP.TITLE_STATUS)) IN ('final','final fees')
      AND RDP.CONTRACT_STATUS_LKP_ID      IN (11001,11003,11004,11006))
      OR (LOWER(TRIM(RDP.TITLE_STATUS))    ='reserved'
      AND RDP.ORDER_NO                    IS NOT NULL))
      AND RDP.RPM_STATION_ID              != '0'
      AND RDP.EXHIBITION_ST_DT            IS NOT NULL
      AND RDP.EXHIBITION_END_DT           IS NOT NULL
      AND RDP.ACTION_LKP_ID               != 12003;
    END IF;
    */
    IF ALREADY_STITCHED_V >= 1 THEN
      UPDATE RPM_DEAL_PRODUCT_STITCHED
      SET STATION_ID              = I.B2B_STATION_ID,
        STATION_NAME              = I.STATION_NAME,
        RPM_STATION_ID            = I.RPM_STATION_ID,
        PROG_ID                   = 0,
        SEAS_ID                   = 0,
        SALES_PERSON              = I.SALES_PERSON,
        TERRITORY_VALUE_CSV       = TERRITORY_VALUE_CSV_V,
        TERRITORY_ID_CSV          = TERRITORY_ID_CSV_V,
        CONTRACT_STATUS_VALUE_CSV = CONTRACT_STATUS_VALUE_CSV_V,
        CONTRACT_STATUS_TYPE_CSV  = CONTRACT_STATUS_TYPE_CSV_V,
        LICENSE_TYPE_ID_CSV       = LICENSE_TYPE_ID_CSV_V,
        LICENSE_TYPE_VALUE_CSV    = LICENSE_TYPE_VALUE_CSV_V,
        EXHIBITION_END_DT         = EXHIBITION_END_DT_V,
        EXHIBITION_ST_DT          = EXHIBITION_ST_DT_V,
        DELIVERY_LEAD_DAYS        = 120,
        DELIVER_BY_DT             = DELIVER_BY_DT_V,
        LAST_UPDATED_DT           = TO_TIMESTAMP(TO_CHAR(SYSDATE,'DD-MON-RR HH.MI.SSSSS AM'),'DD-MON-RR HH.MI.SSSSS AM'),
        LAST_UPDATED_BY           = 'INTL_LICENSE_STITCH_PROC',
        SEASON_NUM                = I.SEASON_NUM,
        PROG_NAME                 = I.PROG_NAME,
        PROG_TYPE                 = I.PROG_TYPE
      WHERE GPMS_PROG_ID          = I.GPMS_PROG_ID
      AND GPMS_SEAS_ID            = I.GPMS_SEAS_ID
      AND STATION_ID              = I.B2B_STATION_ID;
    ELSE
      INSERT
      INTO RPM_DEAL_PRODUCT_STITCHED
        (
          RPM_STITCHED_ID,
          RPM_STATION_ID,
          STATION_ID,
          STATION_NAME,
          GPMS_PROG_ID,
          GPMS_SEAS_ID,
          PROG_ID,
          SEAS_ID,
          TERRITORY_VALUE_CSV,
          TERRITORY_ID_CSV,
          CONTRACT_STATUS_VALUE_CSV,
          CONTRACT_STATUS_TYPE_CSV,
          LICENSE_TYPE_ID_CSV,
          LICENSE_TYPE_VALUE_CSV,
          EXHIBITION_END_DT,
          EXHIBITION_ST_DT,
          DELIVERY_LEAD_DAYS,
          DELIVER_BY_DT,
          CREATED_DT,
          CREATED_BY,
          LAST_UPDATED_DT,
          LAST_UPDATED_BY,
          SOURCE_SYSTEM,
          SEASON_NUM,
          PROG_NAME,
          SALES_PERSON,
          PROG_TYPE
        )
        VALUES
        (
          RPMDLPRODUCTSTITCHED_ID_SEQ.NEXTVAL,
          I.RPM_STATION_ID,
          I.B2B_STATION_ID,
          I.STATION_NAME,
          I.GPMS_PROG_ID,
          I.GPMS_SEAS_ID,
          0,
          0,
          TERRITORY_VALUE_CSV_V,
          TERRITORY_ID_CSV_V,
          CONTRACT_STATUS_VALUE_CSV_V,
          CONTRACT_STATUS_TYPE_CSV_V,
          LICENSE_TYPE_ID_CSV_V,
          LICENSE_TYPE_VALUE_CSV_V,
          EXHIBITION_END_DT_V,
          EXHIBITION_ST_DT_V,
          120,
          DELIVER_BY_DT_V,
          TO_TIMESTAMP(TO_CHAR(SYSDATE,'DD-MON-RR HH.MI.SSSSS AM'),'DD-MON-RR HH.MI.SSSSS AM') ,
          'INTL_LICENSE_STITCH_PROC',
          TO_TIMESTAMP(TO_CHAR(SYSDATE,'DD-MON-RR HH.MI.SSSSS AM'),'DD-MON-RR HH.MI.SSSSS AM'),
          'INTL_LICENSE_STITCH_PROC',
          'RPM',
          I.SEASON_NUM,
          I.PROG_NAME,
          I.SALES_PERSON,
          I.PROG_TYPE
        );
    END IF;

    /* The below delete will remove any records that are not matching the stitching conditions on the top most 
       query but were matching earlier and got inserted into stitching table. 
       Ex : Yesterday Action Lkp Id = 12001 and today it is 12003. */

    DELETE FROM RPM_DEAL_PRODUCT_STITCHED WHERE EXHIBITION_END_DT IS NULL OR EXHIBITION_ST_DT IS NULL;

    COMMIT;
  END LOOP;
end rpm_stitching_temp;
/


  CREATE OR REPLACE EDITIONABLE PROCEDURE "DART_B2B2"."RUNSTITCHINGMIGRATION" As
cursor deal is
	select distinct rdp.gpms_prog_id, rdp.gpms_seas_id, rs.b2b_station_id,rdp.sales_person,rdp.rpm_request_id, rdp.last_updated_Dt from RPM_DEAL_Product rdp  
	join RPM_DEAL_PRODUCT_STATION rs ON rdp.RPM_REQUEST_ID = rs.RPM_REQUEST_ID  
	where rdp.gpms_prog_id !=0 and rdp.rpm_station_id is not null 
  and rdp.TITLE_STATUS in ('Final','Final Fees') and rdp.CONTRACT_STATUS_LKP_ID IN (11001,11003,11004,11006)
  and rdp.rpm_station_id != '0' and to_char(rdp.last_updated_dt, 'YYYY-MM-DD') = to_char(sysdate-1, 'YYYY-MM-DD')
  and rdp.exhibition_st_dt is not null and rdp.exhibition_end_dt is not null order by rdp.last_updated_Dt asc;
  
rpm_station_id number(10) := 0;	 

begin
	for i in deal 
		loop  
       DBMS_OUTPUT.PUT_LINE('gmps_prog_id  = ' || i.gpms_prog_id);
			 select rpm_station_id into rpm_station_id from intl_station where station_id = i.b2b_station_id;    
			 Stitch_RPM_Contracts(i.gpms_prog_id,i.gpms_seas_id,rpm_station_id,i.b2b_station_id,i.sales_person);   
			 update rpm_json_log set db_process_date = sysdate where rpm_request_id = i.rpm_request_id;   
		end loop;  
end RunStitchingMigration;
/


  CREATE OR REPLACE EDITIONABLE PROCEDURE "DART_B2B2"."RUNSTITCHINGMIGRATIONFORSYND" 
AS
  CURSOR DEAL
  IS
    SELECT DISTINCT RDPS.CONTRACT_NO,RDPS.GPMS_PROG_ID,
      RDPS.GPMS_SEAS_ID,
	  RDPS.GPMS_EPS_ID, 
      RS.B2B_STATION_ID,
      RDPS.PROG_NAME,
      RDPS.SALES_PERSON,
      RDPS.RPM_REQUEST_ID,
      RDPS.LAST_UPDATED_DT,
	  RDPS.CONTRACT_STATUS, 
	  RDPS.PACKAGE_ID, 
	  RDPS.PROG_TYPE,rdps.AGREEMENT_TYPE,rdps.SYNDICATION_RUNS,rdps.TITLE_STATUS 
    FROM Rpm_Deal_Product_Synd RDPS
    JOIN Rpm_Deal_Product_Station_Synd RS
    ON RDPS.RPM_REQUEST_ID                          = RS.RPM_REQUEST_ID
    WHERE RDPS.GPMS_PROG_ID                        !=0
    AND RDPS.RPM_STATION_ID                        IS NOT NULL
   AND RDPS.RPM_STATION_ID                        != '0'
    AND RDPS.EXHIBITION_ST_DT                      IS NOT NULL
    AND RDPS.EXHIBITION_END_DT                     IS NOT NULL
--    AND RDPS.GPMS_PROG_ID                       = 11038016
--    AND RDPS.RPM_STATION_ID                        IS NOT NULL
--   AND RDPS.RPM_STATION_ID                       = 204730
    ORDER BY RDPS.CONTRACT_NO ASC;
  RPM_STATION_ID NUMBER(10) := 0;
BEGIN
  FOR I IN DEAL
  LOOP
    DBMS_OUTPUT.PUT_LINE('gmps_prog_id  = ' || I.GPMS_PROG_ID);
    SELECT RPM_STATION_ID
    INTO RPM_STATION_ID
    FROM SYNDICATION_STATION_MASTER
    WHERE STATION_ID = I.B2B_STATION_ID;
    STITCH_RPM_CONTRACTS_SYND(I.TITLE_STATUS,I.SYNDICATION_RUNS,I.AGREEMENT_TYPE,I.CONTRACT_NO,I.PACKAGE_ID,I.PROG_TYPE,I.GPMS_PROG_ID,I.GPMS_SEAS_ID,I.GPMS_EPS_ID,RPM_STATION_ID,I.B2B_STATION_ID,I.SALES_PERSON,I.PROG_NAME);
      END LOOP;
END RUNSTITCHINGMIGRATIONFORSYND;
/


  CREATE OR REPLACE EDITIONABLE PROCEDURE "DART_B2B2"."RUNSTITCHINGMIGRATION_1" As
cursor deal is
	select distinct rdp.gpms_prog_id, rdp.gpms_seas_id, rs.b2b_station_id,rdp.sales_person, rdp.rpm_request_id from RPM_DEAL_Product rdp  
	join RPM_DEAL_PRODUCT_STATION rs ON rdp.RPM_REQUEST_ID = rs.RPM_REQUEST_ID  
	where rdp.gpms_prog_id !=0 and rdp.rpm_station_id is not null 
  and rdp.TITLE_STATUS in ('Final','Final Fees') and rdp.CONTRACT_STATUS_LKP_ID IN (11001,11003,11004,11006)
  and rdp.rpm_station_id != '0'
  --and to_char(rdp.last_updated_dt, 'YYYY-MM-DD') = to_char(sysdate-1, 'YYYY-MM-DD')
  and rdp.exhibition_st_dt is not null and rdp.exhibition_end_dt is not null
  --and rdp.GPMS_PROG_ID in (2468095) and rdp.GPMS_SEAS_ID in(11012961);
  --and rdp.rpm_request_id in (9503320,9503319,9503318,9503367,9503371,9503370,9503369,9503368,9503372,9503366,9503365,9503364,9503363,9503317,9503321);
  --and rdp.rpm_request_id in (9503320);
  --(select rdp.rpm_Request_id from rpm_json_log where processing_error like 'Processed by Error message processor');
  and rdp.rpm_request_id in (select rpm_request_id from rpm_json_log where is_processed = 1 
  --and rpm_request_id = 14042892 
  and DB_PROCESS_DATE is not null
  and rpm_request_id in (select rpm_request_id from rpm_json_log_temp) );
  
rpm_station_id number(10) := 0;	 

begin
	for i in deal 
		loop  
			 select rpm_station_id into rpm_station_id from intl_station where station_id = i.b2b_station_id;    
			 Stitch_RPM_Contracts(i.gpms_prog_id,i.gpms_seas_id,rpm_station_id,i.b2b_station_id,i.sales_person);   
       update rpm_json_log set db_process_date = sysdate where rpm_request_id = i.rpm_request_id;
		end loop;  
end RunStitchingMigration_1;
/


  CREATE OR REPLACE EDITIONABLE PROCEDURE "DART_B2B2"."RUNSTITCHINGMIGRATION_UTIL" As
cursor deal is
--select distinct rdp.gpms_prog_id,rdp.gpms_seas_id, rs.b2b_station_id,rdp.sales_person from RPM_DEAL_Product rdp 
--join RPM_DEAL_PRODUCT_STATION RS ON rdp.RPM_REQUEST_ID = rs.RPM_REQUEST_ID
--where rdp.rpm_station_id in (select rpm_station_id from RPM_DEAL_Product  where station_name like '%;%')
--and rdp.TITLE_STATUS in ('Final','Final Fees') and rdp.CONTRACT_STATUS_LKP_ID IN (11001,11003,11004,11006) 
--and rdp.exhibition_st_dt is not null and rdp.exhibition_end_dt is not null and rdp.station_name is not null
--and rs.b2b_station_id is not null
--order by gpms_prog_id desc;
select distinct rdp.gpms_prog_id,rdp.gpms_seas_id, rs.b2b_station_id,rdp.sales_person  from RPM_DEAL_Product rdp 
join RPM_DEAL_PRODUCT_STATION RS ON rdp.RPM_REQUEST_ID = rs.RPM_REQUEST_ID where gpms_prog_id is not null and gpms_prog_id !=0
and rdp.TITLE_STATUS in ('Final','Final Fees') and rdp.CONTRACT_STATUS_LKP_ID IN (11001,11003,11004,11006) 
and rdp.exhibition_st_dt is not null and rdp.exhibition_end_dt is not null and rdp.station_name is not null
minus
select gpms_prog_id, gpms_Seas_id, station_id,sales_person from RPM_DEAL_PRODUCT_STITCHED where sales_person is not null;

  
alreadyStitched number(2) := 0;	 
rpm_station_id number(10) := 0;	 
b2b_station_id number(10) := 0;	 
begin
--DBMS_OUTPUT.PUT_LINE('executing  record');
	for i in deal 
		loop  
   -- DBMS_OUTPUT.put_line('GPMS' || i.gpms_prog_id||'<-->'||i.gpms_seas_id||'<-->'||i.b2b_station_id);
       select count(*) into alreadyStitched from RPM_DEAL_PRODUCT_STITCHED where gpms_prog_id = i.gpms_prog_id and gpms_seas_id = i.gpms_seas_id and station_id = i.b2b_station_id;
     -- DBMS_OUTPUT.put_line('alreadyStitched'||alreadyStitched);
      -- IF alreadyStitched <> 1 then 
       if i.b2b_station_id is not null then
       select rpm_station_id into rpm_station_id from intl_station where station_id = i.b2b_station_id;
        IF rpm_station_id <> 0 then 
            Stitch_RPM_Contracts_UTIL(i.gpms_prog_id,i.gpms_seas_id,rpm_station_id,i.b2b_station_id,i.sales_person);
        END IF;
        end if;
       --END IF;  
		end loop;  
end RunStitchingMigration_Util;
/


  CREATE OR REPLACE EDITIONABLE PROCEDURE "DART_B2B2"."RUN_INTL_LICENSE_STITCH" 
AS
  CURSOR DEALS
  IS
    SELECT DISTINCT RDP.GPMS_PROG_ID,
      RDP.GPMS_SEAS_ID,
      IST.STATION_ID AS B2B_STATION_ID,
      IST.STATION_NAME,
      IST.RPM_STATION_ID,
      RDP.PROG_NAME,
      RDP.SALES_PERSON,
      RDP.SEASON_NUM,
      RDP.PROG_TYPE
    FROM RPM_DEAL_PRODUCT RDP
    JOIN RPM_DEAL_PRODUCT_STATION RS
    ON RS.RPM_REQUEST_ID                          = RDP.RPM_REQUEST_ID
    JOIN INTL_STATION IST
    ON RS.B2B_STATION_ID                           = IST.STATION_ID
    WHERE RDP.GPMS_PROG_ID                         !=0
    AND RDP.RPM_STATION_ID                         IS NOT NULL
    AND ((LOWER(TRIM(RDP.TITLE_STATUS))            IN ('final','final fees')
    AND RDP.CONTRACT_STATUS_LKP_ID                 IN (11001,11003,11004,11006))
    OR (LOWER(TRIM(RDP.TITLE_STATUS))               ='reserved'
    AND RDP.ORDER_NO                               IS NOT NULL))
    AND RDP.RPM_STATION_ID                         != '0'
    AND TO_CHAR(RDP.LAST_UPDATED_DT, 'YYYY-MM-DD') >= TO_CHAR(SYSDATE-2, 'YYYY-MM-DD')
    AND RDP.EXHIBITION_ST_DT                       IS NOT NULL
    AND RDP.EXHIBITION_END_DT                      IS NOT NULL;
  ------------variables declartions starts--------------------------------------------
  EXHIBITION_END_DT_V         TIMESTAMP(6)   := NULL;
  EXHIBITION_ST_DT_V          TIMESTAMP(6)   := NULL;
  DELIVER_BY_DT_V             TIMESTAMP(6)   := NULL;
  ALREADY_STITCHED_V          NUMBER(10)     := 0;
  TERRITORY_VALUE_CSV_V       VARCHAR2(4000) :=NULL;
  TERRITORY_ID_CSV_V          VARCHAR2(4000) := NULL;
  CONTRACT_STATUS_VALUE_CSV_V VARCHAR2(4000) :=NULL;
  CONTRACT_STATUS_TYPE_CSV_V  VARCHAR2(4000) :=NULL;
  LICENSE_TYPE_ID_CSV_V       VARCHAR2(4000) := NULL;
  LICENSE_TYPE_VALUE_CSV_V    VARCHAR2(4000) :=NULL;
  ------------variables declartions ends--------------------------------------------
BEGIN
  FOR I IN DEALS
  LOOP
    SELECT COUNT(*) INTO ALREADY_STITCHED_V FROM RPM_DEAL_PRODUCT_STITCHED
    WHERE GPMS_PROG_ID = I.GPMS_PROG_ID
    AND GPMS_SEAS_ID   = I.GPMS_SEAS_ID
    AND STATION_ID     = I.B2B_STATION_ID;

    SELECT GET_DEAL_TERRITORY_CSV(I.GPMS_PROG_ID,I.GPMS_SEAS_ID,I.B2B_STATION_ID) INTO TERRITORY_VALUE_CSV_V FROM DUAL;
    SELECT GET_DEAL_TERRITORY_IDS(I.GPMS_PROG_ID,I.GPMS_SEAS_ID,I.B2B_STATION_ID) INTO TERRITORY_ID_CSV_V FROM DUAL;
    SELECT GET_DEAL_CONTRACTSTATUS_CSV(I.GPMS_PROG_ID,I.GPMS_SEAS_ID,I.B2B_STATION_ID) INTO CONTRACT_STATUS_VALUE_CSV_V FROM DUAL;
    SELECT GET_DEAL_CONTRACTTYPE_CSV(I.GPMS_PROG_ID,I.GPMS_SEAS_ID,I.B2B_STATION_ID) INTO CONTRACT_STATUS_TYPE_CSV_V FROM DUAL;
    SELECT GET_LICENSETYPE_IDS(I.GPMS_PROG_ID,I.GPMS_SEAS_ID,I.B2B_STATION_ID) INTO LICENSE_TYPE_ID_CSV_V FROM DUAL;
    SELECT GET_LICENSETYPE_VALUES(I.GPMS_PROG_ID,I.GPMS_SEAS_ID,I.B2B_STATION_ID) INTO LICENSE_TYPE_VALUE_CSV_V FROM DUAL;

    IF (I.GPMS_SEAS_ID IS NOT NULL) THEN
      SELECT MAX(RDP.EXHIBITION_END_DT)   AS EXHIBITION_END_DT,
        MIN(RDP.EXHIBITION_ST_DT)         AS EXHIBITION_ST_DT,
        (MIN(RDP.EXHIBITION_ST_DT) - 120) AS DELIVER_BY_DT
      INTO EXHIBITION_END_DT_V,
        EXHIBITION_ST_DT_V,
        DELIVER_BY_DT_V
      FROM RPM_DEAL_PRODUCT RDP,
        RPM_DEAL_PRODUCT_STATION RDPS
      WHERE RDP.GPMS_PROG_ID               = I.GPMS_PROG_ID
      AND RDP.GPMS_SEAS_ID                 = I.GPMS_SEAS_ID
      AND RDPS.B2B_STATION_ID              = I.B2B_STATION_ID
      AND RDPS.RPM_REQUEST_ID              = RDP.RPM_REQUEST_ID
      AND RDP.GPMS_PROG_ID                !=0
      AND RDP.RPM_STATION_ID              IS NOT NULL
      AND ((LOWER(TRIM(RDP.TITLE_STATUS)) IN ('final','final fees')
      AND RDP.CONTRACT_STATUS_LKP_ID      IN (11001,11003,11004,11006))
      OR (LOWER(TRIM(RDP.TITLE_STATUS))    ='reserved'
      AND RDP.ORDER_NO                    IS NOT NULL))
      AND RDP.RPM_STATION_ID              != '0'
      AND RDP.EXHIBITION_ST_DT            IS NOT NULL
      AND RDP.EXHIBITION_END_DT           IS NOT NULL
      AND RDP.ACTION_LKP_ID               != 12003;
    END IF;
    /*
    -- Commenting this block as I.GPMS_SEAS_ID will never be null since default value is 0
    -- Keepingt this block commented for now, should be removed after a month if no issues are reported / observed
    -- updated date : 08/17/2021
    IF (I.GPMS_SEAS_ID IS NULL) THEN
      SELECT MAX(RDP.EXHIBITION_END_DT)   AS EXHIBITION_END_DT,
        MIN(RDP.EXHIBITION_ST_DT)         AS EXHIBITION_ST_DT,
        (MIN(RDP.EXHIBITION_ST_DT) - 120) AS DELIVER_BY_DT
      INTO EXHIBITION_END_DT_V,
        EXHIBITION_ST_DT_V,
        DELIVER_BY_DT_V
      FROM RPM_DEAL_PRODUCT RDP,
        RPM_DEAL_PRODUCT_STATION RDPS
      WHERE RDP.GPMS_PROG_ID               = I.GPMS_PROG_ID
      AND RDP.GPMS_SEAS_ID                IS NULL
      AND RDPS.B2B_STATION_ID              = I.B2B_STATION_ID
      AND RDPS.RPM_REQUEST_ID              = RDP.RPM_REQUEST_ID
      AND RDP.GPMS_PROG_ID                !=0
      AND RDP.RPM_STATION_ID              IS NOT NULL
      AND ((LOWER(TRIM(RDP.TITLE_STATUS)) IN ('final','final fees')
      AND RDP.CONTRACT_STATUS_LKP_ID      IN (11001,11003,11004,11006))
      OR (LOWER(TRIM(RDP.TITLE_STATUS))    ='reserved'
      AND RDP.ORDER_NO                    IS NOT NULL))
      AND RDP.RPM_STATION_ID              != '0'
      AND RDP.EXHIBITION_ST_DT            IS NOT NULL
      AND RDP.EXHIBITION_END_DT           IS NOT NULL
      AND RDP.ACTION_LKP_ID               != 12003;
    END IF;
    */
    IF ALREADY_STITCHED_V >= 1 THEN
      UPDATE RPM_DEAL_PRODUCT_STITCHED
      SET STATION_ID              = I.B2B_STATION_ID,
        STATION_NAME              = I.STATION_NAME,
        RPM_STATION_ID            = I.RPM_STATION_ID,
        PROG_ID                   = 0,
        SEAS_ID                   = 0,
        SALES_PERSON              = I.SALES_PERSON,
        TERRITORY_VALUE_CSV       = TERRITORY_VALUE_CSV_V,
        TERRITORY_ID_CSV          = TERRITORY_ID_CSV_V,
        CONTRACT_STATUS_VALUE_CSV = CONTRACT_STATUS_VALUE_CSV_V,
        CONTRACT_STATUS_TYPE_CSV  = CONTRACT_STATUS_TYPE_CSV_V,
        LICENSE_TYPE_ID_CSV       = LICENSE_TYPE_ID_CSV_V,
        LICENSE_TYPE_VALUE_CSV    = LICENSE_TYPE_VALUE_CSV_V,
        EXHIBITION_END_DT         = EXHIBITION_END_DT_V,
        EXHIBITION_ST_DT          = EXHIBITION_ST_DT_V,
        DELIVERY_LEAD_DAYS        = 120,
        DELIVER_BY_DT             = DELIVER_BY_DT_V,
        LAST_UPDATED_DT           = TO_TIMESTAMP(TO_CHAR(SYSDATE,'DD-MON-RR HH.MI.SSSSS AM'),'DD-MON-RR HH.MI.SSSSS AM'),
        LAST_UPDATED_BY           = 'INTL_LICENSE_STITCH_PROC',
        SEASON_NUM                = I.SEASON_NUM,
        PROG_NAME                 = I.PROG_NAME,
        PROG_TYPE                 = I.PROG_TYPE
      WHERE GPMS_PROG_ID          = I.GPMS_PROG_ID
      AND GPMS_SEAS_ID            = I.GPMS_SEAS_ID
      AND STATION_ID              = I.B2B_STATION_ID;
    ELSE
      INSERT
      INTO RPM_DEAL_PRODUCT_STITCHED
        (
          RPM_STITCHED_ID,
          RPM_STATION_ID,
          STATION_ID,
          STATION_NAME,
          GPMS_PROG_ID,
          GPMS_SEAS_ID,
          PROG_ID,
          SEAS_ID,
          TERRITORY_VALUE_CSV,
          TERRITORY_ID_CSV,
          CONTRACT_STATUS_VALUE_CSV,
          CONTRACT_STATUS_TYPE_CSV,
          LICENSE_TYPE_ID_CSV,
          LICENSE_TYPE_VALUE_CSV,
          EXHIBITION_END_DT,
          EXHIBITION_ST_DT,
          DELIVERY_LEAD_DAYS,
          DELIVER_BY_DT,
          CREATED_DT,
          CREATED_BY,
          LAST_UPDATED_DT,
          LAST_UPDATED_BY,
          SOURCE_SYSTEM,
          SEASON_NUM,
          PROG_NAME,
          SALES_PERSON,
          PROG_TYPE
        )
        VALUES
        (
          RPMDLPRODUCTSTITCHED_ID_SEQ.NEXTVAL,
          I.RPM_STATION_ID,
          I.B2B_STATION_ID,
          I.STATION_NAME,
          I.GPMS_PROG_ID,
          I.GPMS_SEAS_ID,
          0,
          0,
          TERRITORY_VALUE_CSV_V,
          TERRITORY_ID_CSV_V,
          CONTRACT_STATUS_VALUE_CSV_V,
          CONTRACT_STATUS_TYPE_CSV_V,
          LICENSE_TYPE_ID_CSV_V,
          LICENSE_TYPE_VALUE_CSV_V,
          EXHIBITION_END_DT_V,
          EXHIBITION_ST_DT_V,
          120,
          DELIVER_BY_DT_V,
          TO_TIMESTAMP(TO_CHAR(SYSDATE,'DD-MON-RR HH.MI.SSSSS AM'),'DD-MON-RR HH.MI.SSSSS AM') ,
          'INTL_LICENSE_STITCH_PROC',
          TO_TIMESTAMP(TO_CHAR(SYSDATE,'DD-MON-RR HH.MI.SSSSS AM'),'DD-MON-RR HH.MI.SSSSS AM'),
          'INTL_LICENSE_STITCH_PROC',
          'RPM',
          I.SEASON_NUM,
          I.PROG_NAME,
          I.SALES_PERSON,
          I.PROG_TYPE
        );
    END IF;

    /* The below delete will remove any records that are not matching the stitching conditions on the top most 
       query but were matching earlier and got inserted into stitching table. 
       Ex : Yesterday Action Lkp Id = 12001 and today it is 12003. */

    DELETE FROM RPM_DEAL_PRODUCT_STITCHED WHERE EXHIBITION_END_DT IS NULL OR EXHIBITION_ST_DT IS NULL;

    COMMIT;
  END LOOP;
END RUN_INTL_LICENSE_STITCH;
/


  CREATE OR REPLACE EDITIONABLE PROCEDURE "DART_B2B2"."STITCHANDMIGRATE_RPMCONTRACTS" (gProgId in varchar2,gSeasId in varchar2,stationId in varchar2)
AS
RPM_Station_id number(19) :=null;
Station_Id number(19) :=null;
Station_Name varchar2(255) :=null;
Gpms_Prog_Id number(19) :=null;
Gpms_Seas_Id number(19) :=null;
Prog_Id number(19) :=null;
Seas_Id number(19) :=null;
SEASON_NUM varchar2(255) :=null;  
PROG_NAME varchar2(255) :=null;
SOURCE_SYSTEM varchar2(255) := 'RPM';
--RPM_DEAL_PRODUCT_ID_CSV varchar2(4000) :=null;      
TERRITORY_VALUE_CSV varchar2(4000) :=null; 			   
TERRITORY_ID_CSV varchar2(4000) := null;			   
CONTRACT_STATUS_VALUE_CSV varchar2(4000) :=null;	 
CONTRACT_STATUS_TYPE_CSV varchar2(4000) :=null;			   
LICENSE_TYPE_ID_CSV varchar2(4000) := null;			   
LICENSE_TYPE_VALUE_CSV varchar2(4000) :=null; 		  
EXHIBITION_END_DT timestamp(6) := null;
EXHIBITION_ST_DT  timestamp(6) := null;
DELIVERY_LEAD_DAYS number(9) := 120;
DELIVER_BY_DT timestamp(6) := null;
CREATED_BY varchar2(255) := 'Manual - Migration';
LAST_UPDATED_BY varchar2(255) := 'Manual - Migration';
alreadyStitched number(2) := 0;
PROG_NAME_V varchar2(4000) :=null;
		  
begin	 
	RPM_Station_id :=	stationId;  
	Gpms_Prog_Id := gProgId; 
	Gpms_Seas_Id := gSeasId; 
	 
	select count(*) into alreadyStitched from RPM_DEAL_PRODUCT_STITCHED where gpms_prog_id = gProgId and gpms_seas_id = gSeasId and rpm_station_id = stationId; 
	 
if(alreadyStitched = 0) then 
	 
	select station_id as Station_Id,station_name as Station_Name into Station_Id,Station_Name from intl_station where rpm_station_id = stationId; 
	select prog_id,seas_id,SEASON_NUM into Prog_Id,Seas_Id,SEASON_NUM from RPM_DEAL_Product where gpms_prog_id = gProgId and gpms_seas_id = gSeasId and rownum < 2; 
--	select Get_deal_product_Id_CSV(gProgId,gSeasId,stationId) into RPM_DEAL_PRODUCT_ID_CSV from dual; 
	select Get_deal_territory_CSV(gProgId,gSeasId,stationId) into TERRITORY_VALUE_CSV from dual; 
	select Get_deal_territory_Ids(gProgId,gSeasId,stationId) into TERRITORY_ID_CSV from dual; 
	select Get_deal_ContractStatus_CSV(gProgId,gSeasId,stationId) into CONTRACT_STATUS_VALUE_CSV from dual; 
	select Get_deal_ContractType_CSV(gProgId,gSeasId,stationId) into CONTRACT_STATUS_TYPE_CSV from dual; 
	select Get_LicenseType_Ids(gProgId,gSeasId,stationId) into LICENSE_TYPE_ID_CSV from dual; 
	select Get_LicenseType_Values(gProgId,gSeasId,stationId) into LICENSE_TYPE_VALUE_CSV from dual; 
	select DTV_B2B2.Get_Program_name(gProgId) into PROG_NAME_V from dual; 
	 
if (gSeasId is not null) then 

	select max(EXHIBITION_END_DT) as EXHIBITION_END_DT, min(EXHIBITION_ST_DT) as EXHIBITION_ST_DT, (min(EXHIBITION_ST_DT) - 120) as  DELIVER_BY_DT  
   into EXHIBITION_END_DT, EXHIBITION_ST_DT,DELIVER_BY_DT from RPM_DEAL_Product where gpms_prog_id = gProgId and gpms_seas_id = gSeasId and rpm_station_id = stationId;
	 
end if;
if (gSeasId is null) then
	select max(EXHIBITION_END_DT) as EXHIBITION_END_DT, min(EXHIBITION_ST_DT) as EXHIBITION_ST_DT,(min(EXHIBITION_ST_DT) - 120) as  DELIVER_BY_DT  
  into EXHIBITION_END_DT, EXHIBITION_ST_DT,DELIVER_BY_DT from RPM_DEAL_Product where gpms_prog_id = gProgId and gpms_seas_id is null and rpm_station_id = stationId;
	 
end if;
	 
	Insert into RPM_DEAL_PRODUCT_STITCHED (RPM_STITCHED_ID,RPM_STATION_ID,STATION_ID,STATION_NAME,GPMS_PROG_ID,GPMS_SEAS_ID,PROG_ID,SEAS_ID,TERRITORY_VALUE_CSV,TERRITORY_ID_CSV,CONTRACT_STATUS_VALUE_CSV,CONTRACT_STATUS_TYPE_CSV,LICENSE_TYPE_ID_CSV,LICENSE_TYPE_VALUE_CSV,EXHIBITION_END_DT,EXHIBITION_ST_DT,DELIVERY_LEAD_DAYS,DELIVER_BY_DT,CREATED_DT,CREATED_BY,LAST_UPDATED_DT,LAST_UPDATED_BY,SOURCE_SYSTEM,SEASON_NUM,PROG_NAME)  
	values  
	(RPM_DL_PRODUCT_STITCHED_ID_SEQ.nextval,RPM_STATION_ID,STATION_ID,STATION_NAME,GPMS_PROG_ID,GPMS_SEAS_ID,PROG_ID,SEAS_ID,TERRITORY_VALUE_CSV,TERRITORY_ID_CSV,CONTRACT_STATUS_VALUE_CSV,CONTRACT_STATUS_TYPE_CSV,LICENSE_TYPE_ID_CSV,LICENSE_TYPE_VALUE_CSV,EXHIBITION_END_DT,EXHIBITION_ST_DT,DELIVERY_LEAD_DAYS,DELIVER_BY_DT, 
  to_timestamp(sysdate,'DD-MON-RR HH.MI.SSXFF AM'),CREATED_BY,to_timestamp(sysdate,'DD-MON-RR HH.MI.SSXFF AM'),LAST_UPDATED_BY,SOURCE_SYSTEM,SEASON_NUM,PROG_NAME);
	 
	commit; 

	end if; 
end StitchAndMigrate_RPMContracts;
/


  CREATE OR REPLACE EDITIONABLE PROCEDURE "DART_B2B2"."STITCH_RPM_CONTRACTS" (gProgId in varchar2,gSeasId in varchar2,rpmStationId in varchar2, b2bStationId in varchar2,sales_person in varchar2)
AS
RPM_Station_id_V number(19) :=null;
B2B_Station_Id_V number(19) :=null;
Station_Name_V varchar2(4000) :=null;
Gpms_Prog_Id_V number(19) :=null;
Gpms_Seas_Id_V number(19) :=null;
Prog_Id_V number(19) :=null;
Seas_Id_V number(19) :=null;
SEASON_NUM_V varchar2(4000) :=null;
PROG_NAME_V varchar2(4000) :=null;
SOURCE_SYSTEM_V varchar2(4000) := 'RPM';
--RPM_DEAL_PRODUCT_ID_CSV varchar2(4000) :=null;
TERRITORY_VALUE_CSV_V varchar2(4000) :=null;
TERRITORY_ID_CSV_V varchar2(4000) := null;
CONTRACT_STATUS_VALUE_CSV_V varchar2(4000) :=null;
CONTRACT_STATUS_TYPE_CSV_V varchar2(4000) :=null;
LICENSE_TYPE_ID_CSV_V varchar2(4000) := null;
LICENSE_TYPE_VALUE_CSV_V varchar2(4000) :=null;
EXHIBITION_END_DT_V timestamp(6) := null;
EXHIBITION_ST_DT_V  timestamp(6) := null;
DELIVERY_LEAD_DAYS_V number(9) := 120;
DELIVER_BY_DT_V timestamp(6) := null;
CREATED_BY_V varchar2(4000) := 'Manual - Migration';
LAST_UPDATED_BY_V varchar2(4000) := 'Manual - Migration';
sales_person_V varchar2(4000) :=null;
alreadyStitched number(2) := 0;
PROG_TYPE_V varchar2(4000) :=null;
begin
	RPM_Station_id_V :=	rpmStationId;  
	Gpms_Prog_Id_V := gProgId; 
	Gpms_Seas_Id_V := gSeasId; 
	B2B_Station_Id_V :=b2bStationId; 
	sales_person_V :=sales_person; 


	select count(*) into alreadyStitched from RPM_DEAL_PRODUCT_STITCHED where gpms_prog_id = gProgId and gpms_seas_id = gSeasId and station_id = B2B_Station_Id_V; 

	select station_name as Station_Name into Station_Name_V from intl_station where station_id = B2B_Station_Id_V; 
	select prog_id,seas_id,SEASON_NUM into Prog_Id_V,Seas_Id_V,SEASON_NUM_V from RPM_DEAL_PRODUCT where gpms_prog_id = gProgId and gpms_seas_id = gSeasId and rownum < 2; 
	--select Get_deal_product_Id_CSV(gProgId,gSeasId,B2B_Station_Id_V) into RPM_DEAL_PRODUCT_ID_CSV from dual; 
	select Get_deal_territory_CSV(gProgId,gSeasId,B2B_Station_Id_V) into TERRITORY_VALUE_CSV_V from dual; 
	select Get_deal_territory_Ids(gProgId,gSeasId,B2B_Station_Id_V) into TERRITORY_ID_CSV_V from dual; 
	select Get_deal_ContractStatus_CSV(gProgId,gSeasId,B2B_Station_Id_V) into CONTRACT_STATUS_VALUE_CSV_V from dual; 
	select Get_deal_ContractType_CSV(gProgId,gSeasId,B2B_Station_Id_V) into CONTRACT_STATUS_TYPE_CSV_V from dual; 
	select Get_LicenseType_Ids(gProgId,gSeasId,B2B_Station_Id_V) into LICENSE_TYPE_ID_CSV_V from dual; 
	select Get_LicenseType_Values(gProgId,gSeasId,B2B_Station_Id_V) into LICENSE_TYPE_VALUE_CSV_V from dual; 
	select GET_PROGRAM_NAME(gProgId,Station_Name_V) into PROG_NAME_V from dual; 
  select get_program_type(gProgId,Station_Name_V) into PROG_TYPE_V from dual;

if (gSeasId is not null) then
	select max(rpd.EXHIBITION_END_DT) as EXHIBITION_END_DT, min(rpd.EXHIBITION_ST_DT) as EXHIBITION_ST_DT, (min(rpd.EXHIBITION_ST_DT) - 120) as  DELIVER_BY_DT 
   into EXHIBITION_END_DT_V, EXHIBITION_ST_DT_V,DELIVER_BY_DT_V from RPM_DEAL_PRODUCT rpd, rpm_deal_product_station rpds where rpd.gpms_prog_id = gProgId
   and rpd.gpms_seas_id = gSeasId and rpds.b2b_station_id = B2B_Station_Id_V and rpds.rpm_request_id = rpd.rpm_request_id
   and EXHIBITION_ST_DT is not null and EXHIBITION_END_DT is not null and rpd.ACTION_LKP_ID != 12003;
end if;
if (gSeasId is null) then
	select max(rpd.EXHIBITION_END_DT) as EXHIBITION_END_DT, min(rpd.EXHIBITION_ST_DT) as EXHIBITION_ST_DT,(min(rpd.EXHIBITION_ST_DT) - 120) as  DELIVER_BY_DT 
  into EXHIBITION_END_DT_V, EXHIBITION_ST_DT_V,DELIVER_BY_DT_V from RPM_DEAL_PRODUCT rpd, rpm_deal_product_station rpds where rpd.gpms_prog_id = gProgId
  and rpd.gpms_seas_id is null and rpds.b2b_station_id = B2B_Station_Id_V and rpds.rpm_request_id = rpd.rpm_request_id
  and EXHIBITION_ST_DT is not null and EXHIBITION_END_DT is not null and rpd.ACTION_LKP_ID != 12003;
end if;

  IF alreadyStitched >= 1 then
    UPDATE RPM_DEAL_PRODUCT_STITCHED SET STATION_ID = B2B_Station_Id_V, STATION_NAME = Station_Name_V, PROG_ID = Prog_Id_V, SEAS_ID = Seas_Id_V,sales_person=sales_person_V,
      TERRITORY_VALUE_CSV = TERRITORY_VALUE_CSV_V, TERRITORY_ID_CSV = TERRITORY_ID_CSV_V, CONTRACT_STATUS_VALUE_CSV = CONTRACT_STATUS_VALUE_CSV_V,
      CONTRACT_STATUS_TYPE_CSV = CONTRACT_STATUS_TYPE_CSV_V, LICENSE_TYPE_ID_CSV = LICENSE_TYPE_ID_CSV_V, LICENSE_TYPE_VALUE_CSV = LICENSE_TYPE_VALUE_CSV_V, EXHIBITION_END_DT = EXHIBITION_END_DT_V,
      EXHIBITION_ST_DT = EXHIBITION_ST_DT_V, DELIVERY_LEAD_DAYS = DELIVERY_LEAD_DAYS_V, DELIVER_BY_DT = DELIVER_BY_DT_V, LAST_UPDATED_DT = to_timestamp(to_char(sysdate,'DD-MON-RR HH.MI.SSSSS AM'),'DD-MON-RR HH.MI.SSSSS AM'),
      LAST_UPDATED_BY = LAST_UPDATED_BY_V, SEASON_NUM = SEASON_NUM_V, PROG_NAME = PROG_NAME_V, PROG_TYPE = PROG_TYPE_V
    WHERE gpms_prog_id = gProgId and gpms_seas_id = gSeasId and STATION_ID = B2B_Station_Id_V;
  else
    Insert into RPM_DEAL_PRODUCT_STITCHED (RPM_STITCHED_ID,RPM_STATION_ID,STATION_ID,STATION_NAME,GPMS_PROG_ID,GPMS_SEAS_ID,PROG_ID,SEAS_ID,TERRITORY_VALUE_CSV,TERRITORY_ID_CSV,CONTRACT_STATUS_VALUE_CSV,CONTRACT_STATUS_TYPE_CSV,LICENSE_TYPE_ID_CSV,LICENSE_TYPE_VALUE_CSV,EXHIBITION_END_DT,EXHIBITION_ST_DT,DELIVERY_LEAD_DAYS,DELIVER_BY_DT,CREATED_DT,CREATED_BY,LAST_UPDATED_DT,LAST_UPDATED_BY,SOURCE_SYSTEM,SEASON_NUM,PROG_NAME,sales_person,PROG_TYPE)
      values
      (RPM_DL_PRODUCT_STITCHED_ID_SEQ.nextval,RPM_STATION_ID_V,B2B_Station_Id_V,STATION_NAME_V,GPMS_PROG_ID_V,GPMS_SEAS_ID_V,PROG_ID_V,SEAS_ID_V,TERRITORY_VALUE_CSV_V,TERRITORY_ID_CSV_V,CONTRACT_STATUS_VALUE_CSV_V,CONTRACT_STATUS_TYPE_CSV_V,LICENSE_TYPE_ID_CSV_V,LICENSE_TYPE_VALUE_CSV_V,EXHIBITION_END_DT_V,EXHIBITION_ST_DT_V,DELIVERY_LEAD_DAYS_V,DELIVER_BY_DT_V,
      to_timestamp(to_char(sysdate,'DD-MON-RR HH.MI.SSSSS AM'),'DD-MON-RR HH.MI.SSSSS AM') ,CREATED_BY_V,to_timestamp(to_char(sysdate,'DD-MON-RR HH.MI.SSSSS AM'),'DD-MON-RR HH.MI.SSSSS AM'),LAST_UPDATED_BY_V,SOURCE_SYSTEM_V,SEASON_NUM_V,PROG_NAME_V,sales_person_V,PROG_TYPE_V);
  end if;


	commit; 

end Stitch_RPM_Contracts;
/


  CREATE OR REPLACE EDITIONABLE PROCEDURE "DART_B2B2"."STITCH_RPM_CONTRACTS_SYND" (
    TITLESTATUS IN VARCHAR2,
    SYNDICATIONRUNS IN VARCHAR2,
    agreementType   IN VARCHAR2,
    contractNo      IN VARCHAR2,
    packageId       IN VARCHAR2,
    progType        IN VARCHAR2,
    gProgId         IN VARCHAR2,
    gSeasId         IN VARCHAR2,
    gEpsId          IN VARCHAR2,
    rpmStationId    IN VARCHAR2,
    b2bStationId    IN VARCHAR2,
    sales_person    IN VARCHAR2,
    iProgName       IN VARCHAR2)
AS
  RPM_Station_id_V            NUMBER(19)     :=NULL;
  B2B_Station_Id_V            NUMBER(19)     :=NULL;
  Station_Name_V              VARCHAR2(4000) :=NULL;
  Contract_No_V               NUMBER(19)     :=NULL;
  PACKAGE_ID_V                NUMBER(19)     :=NULL;
  Gpms_Prog_Id_V              NUMBER(19)     :=NULL;
  Gpms_Seas_Id_V              NUMBER(19)     :=NULL;
  Gpms_Eps_Id_V               NUMBER(19)     :=NULL;
  CONTRACT_STATUS_VALUE_CSV_V VARCHAR2(4000) :=NULL;
  CONTRACT_STATUS_TYPE_CSV_V  VARCHAR2(4000) :=NULL;
  EXHIBITION_END_DT_V         TIMESTAMP(6)   := NULL;
  EXHIBITION_ST_DT_V          TIMESTAMP(6)   := NULL;
  CREATED_BY_V                VARCHAR2(4000) := 'Manual - Migration';
  LAST_UPDATED_BY_V           VARCHAR2(4000) := 'Manual - Migration';
  sales_person_V              VARCHAR2(4000) :=NULL;
  alreadyStitched             NUMBER(25)     := 0;
  PROG_TYPE_V                 VARCHAR2(4000) :=NULL;
  agreement_type              VARCHAR2(4000) :=NULL;
  SYNDICATION_RUNS            VARCHAR2(4000)     :=NULL;
  TITLE_STATUS_V VARCHAR2(4000) :=NULL;
BEGIN
  RPM_Station_id_V := rpmStationId;
  Gpms_Prog_Id_V   := gProgId;
  Gpms_Seas_Id_V   := gSeasId;
  Gpms_Eps_Id_V    := gEpsId;
  B2B_Station_Id_V :=b2bStationId;
  sales_person_V   :=sales_person;
  PROG_TYPE_V      :=progType;
  Contract_No_V    :=contractNo;
  PACKAGE_ID_V     :=packageId;
  agreement_type   :=agreementType;
  SYNDICATION_RUNS :=SYNDICATIONRUNS;
  TITLE_STATUS_V :=TITLESTATUS;
  SELECT station_name AS Station_Name
  INTO Station_Name_V
  FROM SYNDICATION_STATION_MASTER
  WHERE station_id = B2B_Station_Id_V;
  IF(gEpsId       IS NOT NULL AND gEpsId!=0) THEN
    SELECT COUNT(*)
    INTO alreadyStitched
    FROM DTV_B2B2.Rpm_Deal_Stitch_Syndication
    WHERE PROG_GPMS_ID = gProgId
    AND SEAS_GPMS_ID   = gSeasId
    AND EPS_GPMS_ID    =gEpsId
    AND STATION_NAME   = Station_Name_V;
  END IF;
  IF (gEpsId IS NULL OR gEpsId=0) THEN
    SELECT COUNT(*)
    INTO alreadyStitched
    FROM DTV_B2B2.Rpm_Deal_Stitch_Syndication
    WHERE PROG_GPMS_ID = gProgId
    AND STATION_NAME   = Station_Name_V;
  END IF;
  SELECT Get_deal_ContractStatus_CSV_SYND(TITLE_STATUS_V)
  INTO CONTRACT_STATUS_VALUE_CSV_V
  FROM dual;
  IF(gEpsId IS NOT NULL AND gEpsId!=0) THEN
    SELECT MAX(rpd.EXHIBITION_END_DT) AS EXHIBITION_END_DT,
      MIN(rpd.EXHIBITION_ST_DT)       AS EXHIBITION_ST_DT
    INTO EXHIBITION_END_DT_V,
      EXHIBITION_ST_DT_V
    FROM Rpm_Deal_Product_Synd rpd,
      Rpm_Deal_Product_Station_Synd rpds
    WHERE rpd.gpms_prog_id  = gProgId
    AND rpd.gpms_seas_id    = gSeasId
    AND rpd.gpms_eps_id     =gEpsId
    AND rpds.b2b_station_id = B2B_Station_Id_V
    AND rpds.rpm_request_id = rpd.rpm_request_id
    AND EXHIBITION_ST_DT   IS NOT NULL
    AND EXHIBITION_END_DT  IS NOT NULL;
  END IF;
  IF (gEpsId IS NULL OR gEpsId=0) THEN
    SELECT MAX(rpd.EXHIBITION_END_DT) AS EXHIBITION_END_DT,
      MIN(rpd.EXHIBITION_ST_DT)       AS EXHIBITION_ST_DT
    INTO EXHIBITION_END_DT_V,
      EXHIBITION_ST_DT_V
    FROM Rpm_Deal_Product_Synd rpd,
      Rpm_Deal_Product_Station_Synd rpds
    WHERE rpd.gpms_prog_id  = gProgId
    AND rpds.b2b_station_id = B2B_Station_Id_V
    AND rpds.rpm_request_id = rpd.rpm_request_id
    AND EXHIBITION_ST_DT   IS NOT NULL
    AND EXHIBITION_END_DT  IS NOT NULL;
  END IF;
  IF alreadyStitched >= 1 THEN
    UPDATE DTV_B2B2.Rpm_Deal_Stitch_Syndication
    SET CONTRACT_ID    =contractNo,
      STATION_NAME     = TRIM(Station_Name_V),
      PROG_GPMS_ID     = GPMS_PROG_ID_V,
      SEAS_GPMS_ID     = GPMS_SEAS_ID_V,
      EPS_GPMS_ID      =Gpms_Eps_Id_V,
      CONTRACT_STATUS  = CONTRACT_STATUS_VALUE_CSV_V,
      PRODUCT_GRP_ID   =PACKAGE_ID_V,
      LKP_DIST_TYPE_ID =
      (SELECT connect_value FROM syndication_deal_map WHERE rpm_value=TRIM(agreementType) and lkp_type_id=14000
      ),
      ACC_END_DT       = EXHIBITION_END_DT_V,
      ACC_START_DT     = EXHIBITION_ST_DT_V,
      LAST_UPDATED_DT  = to_timestamp(TO_CHAR(sysdate,'DD-MON-RR HH.MI.SSSSS AM'),'DD-MON-RR HH.MI.SSSSS AM'),
      LAST_UPDATED_BY  = LAST_UPDATED_BY_V,
      PROG_TYPE        = TRIM(PROG_TYPE_V)
    WHERE PROG_GPMS_ID = gProgId
    AND SEAS_GPMS_ID   = gSeasId
    AND EPS_GPMS_ID    =gEpsId
    AND STATION_NAME   = TRIM(Station_Name_V);
   --PROG_MANAGE_RUNNO_SYND_PROC(GPMS_PROG_ID_V,SYNDICATION_RUNS, TRIM(Station_Name_V));
  ELSE
    INSERT
    INTO DTV_B2B2.Rpm_Deal_Stitch_Syndication
      (
        SYND_DEAL_ID,
        CONTRACT_ID,
        PROG_GPMS_ID,
        SEAS_GPMS_ID,
        EPS_GPMS_ID,
        STATION_NAME,
        LKP_DIST_TYPE_ID,
        CONTRACT_STATUS,
        CREDIT_LOCKOUT,
        SCHD_ID,
        ACC_START_DT,
        ACC_END_DT,
        PRODUCT_GRP_ID,
        SYS_SYNCED_DT,
        PROG_TYPE,
        CREATED_DT,
        CREATED_BY,
        LAST_UPDATED_DT,
        LAST_UPDATED_BY
      )
      VALUES
      (
        DTV_B2B2.RPM_DEAL_STITCH_SYNDICATION_SEQ.nextval,
        contractNo,
        GPMS_PROG_ID_V,
        GPMS_SEAS_ID_V,
        Gpms_Eps_Id_V,
        TRIM(Station_Name_V),
        (SELECT connect_value FROM syndication_deal_map WHERE rpm_value=TRIM(agreementType) and lkp_type_id=14000
        ),
        TRIM(CONTRACT_STATUS_VALUE_CSV_V),
        NULL,
        NULL,
        EXHIBITION_ST_DT_V,
        EXHIBITION_END_DT_V,
        PACKAGE_ID_V,
        to_timestamp(TO_CHAR(sysdate,'DD-MON-RR HH.MI.SSSSS AM'),'DD-MON-RR HH.MI.SSSSS AM'),
        TRIM(PROG_TYPE_V),
        to_timestamp(TO_CHAR(sysdate,'DD-MON-RR HH.MI.SSSSS AM'),'DD-MON-RR HH.MI.SSSSS AM') ,
        CREATED_BY_V,
        to_timestamp(TO_CHAR(sysdate,'DD-MON-RR HH.MI.SSSSS AM'),'DD-MON-RR HH.MI.SSSSS AM'),
        LAST_UPDATED_BY_V
      );
      --PROG_MANAGE_RUNNO_SYND_PROC(GPMS_PROG_ID_V,SYNDICATION_RUNS, TRIM(Station_Name_V));
  END IF;
  COMMIT;
END STITCH_RPM_CONTRACTS_SYND;
/


  CREATE OR REPLACE EDITIONABLE PROCEDURE "DART_B2B2"."STITCH_RPM_CONTRACTS_UTIL" (gProgId in varchar2,gSeasId in varchar2,rpmStationId in varchar2, b2bStationId in varchar2,sales_person in varchar2)
AS
RPM_Station_id_V number(19) :=null;
B2B_Station_Id_V number(19) :=null;
Station_Name_V varchar2(4000) :=null;
Gpms_Prog_Id_V number(19) :=null;
Gpms_Seas_Id_V number(19) :=null;
Prog_Id_V number(19) :=null;
Seas_Id_V number(19) :=null;
SEASON_NUM_V varchar2(4000) :=null;  
PROG_NAME_V varchar2(4000) :=null;
SOURCE_SYSTEM_V varchar2(4000) := 'RPM';
--RPM_DEAL_PRODUCT_ID_CSV varchar2(4000) :=null;      
TERRITORY_VALUE_CSV_V varchar2(4000) :=null; 			   
TERRITORY_ID_CSV_V varchar2(4000) := null;			   
CONTRACT_STATUS_VALUE_CSV_V varchar2(4000) :=null;	 
CONTRACT_STATUS_TYPE_CSV_V varchar2(4000) :=null;			   
LICENSE_TYPE_ID_CSV_V varchar2(4000) := null;			   
LICENSE_TYPE_VALUE_CSV_V varchar2(4000) :=null; 		  
EXHIBITION_END_DT_V timestamp(6) := null;
EXHIBITION_ST_DT_V  timestamp(6) := null;
DELIVERY_LEAD_DAYS_V number(9) := 120;
DELIVER_BY_DT_V timestamp(6) := null;
CREATED_BY_V varchar2(4000) := 'Manual - Migration';
LAST_UPDATED_BY_V varchar2(4000) := 'Manual - Migration';
sales_person_V varchar2(4000) :=null;
alreadyStitched number(2) := 0;	 
begin	 
	RPM_Station_id_V :=	rpmStationId;  
	Gpms_Prog_Id_V := gProgId; 
	Gpms_Seas_Id_V := gSeasId; 
	B2B_Station_Id_V :=b2bStationId; 
	sales_person_V :=sales_person; 
	 
	select count(*) into alreadyStitched from RPM_DEAL_PRODUCT_STITCHED where gpms_prog_id = gProgId and gpms_seas_id = gSeasId and station_id = B2B_Station_Id_V; 
	 
	select station_name as Station_Name into Station_Name_V from intl_station where station_id = B2B_Station_Id_V; 
	select prog_id,seas_id,SEASON_NUM into Prog_Id_V,Seas_Id_V,SEASON_NUM_V from RPM_DEAL_PRODUCT where gpms_prog_id = gProgId and gpms_seas_id = gSeasId and rownum < 2; 
	--select Get_deal_product_Id_CSV(gProgId,gSeasId,B2B_Station_Id_V) into RPM_DEAL_PRODUCT_ID_CSV from dual; 
	select Get_deal_territory_CSV(gProgId,gSeasId,B2B_Station_Id_V) into TERRITORY_VALUE_CSV_V from dual; 
	select Get_deal_territory_Ids(gProgId,gSeasId,B2B_Station_Id_V) into TERRITORY_ID_CSV_V from dual; 
	select Get_deal_ContractStatus_CSV(gProgId,gSeasId,B2B_Station_Id_V) into CONTRACT_STATUS_VALUE_CSV_V from dual; 
	select Get_deal_ContractType_CSV(gProgId,gSeasId,B2B_Station_Id_V) into CONTRACT_STATUS_TYPE_CSV_V from dual; 
	select Get_LicenseType_Ids(gProgId,gSeasId,B2B_Station_Id_V) into LICENSE_TYPE_ID_CSV_V from dual; 
	select Get_LicenseType_Values(gProgId,gSeasId,B2B_Station_Id_V) into LICENSE_TYPE_VALUE_CSV_V from dual; 
	--select DTV_B2B2.Get_Program_name(gProgId) into PROG_NAME_V from dual; 
	 
if (gSeasId is not null) then 

	select max(rpd.EXHIBITION_END_DT) as EXHIBITION_END_DT, min(rpd.EXHIBITION_ST_DT) as EXHIBITION_ST_DT, (min(rpd.EXHIBITION_ST_DT) - 120) as  DELIVER_BY_DT  
   into EXHIBITION_END_DT_V, EXHIBITION_ST_DT_V,DELIVER_BY_DT_V from RPM_DEAL_PRODUCT rpd, rpm_deal_product_station rpds where rpd.gpms_prog_id = gProgId 
   and rpd.gpms_seas_id = gSeasId and rpds.b2b_station_id = B2B_Station_Id_V and rpds.rpm_request_id = rpd.rpm_request_id
   and EXHIBITION_ST_DT is not null and EXHIBITION_END_DT is not null;
	 
end if;
if (gSeasId is null) then
	select max(rpd.EXHIBITION_END_DT) as EXHIBITION_END_DT, min(rpd.EXHIBITION_ST_DT) as EXHIBITION_ST_DT,(min(rpd.EXHIBITION_ST_DT) - 120) as  DELIVER_BY_DT  
  into EXHIBITION_END_DT_V, EXHIBITION_ST_DT_V,DELIVER_BY_DT_V from RPM_DEAL_PRODUCT rpd, rpm_deal_product_station rpds where rpd.gpms_prog_id = gProgId 
  and rpd.gpms_seas_id is null and rpds.b2b_station_id = B2B_Station_Id_V and rpds.rpm_request_id = rpd.rpm_request_id
  and EXHIBITION_ST_DT is not null and EXHIBITION_END_DT is not null;
	 
end if;
	 
  IF alreadyStitched = 1 then 
    UPDATE RPM_DEAL_PRODUCT_STITCHED SET STATION_ID = B2B_Station_Id_V, STATION_NAME = Station_Name_V, PROG_ID = Prog_Id_V, SEAS_ID = Seas_Id_V,sales_person=sales_person_V,
      TERRITORY_VALUE_CSV = TERRITORY_VALUE_CSV_V, TERRITORY_ID_CSV = TERRITORY_ID_CSV_V, CONTRACT_STATUS_VALUE_CSV = CONTRACT_STATUS_VALUE_CSV_V,
      CONTRACT_STATUS_TYPE_CSV = CONTRACT_STATUS_TYPE_CSV_V, LICENSE_TYPE_ID_CSV = LICENSE_TYPE_ID_CSV_V, LICENSE_TYPE_VALUE_CSV = LICENSE_TYPE_VALUE_CSV_V, EXHIBITION_END_DT = EXHIBITION_END_DT_V,
      EXHIBITION_ST_DT = EXHIBITION_ST_DT_V, DELIVERY_LEAD_DAYS = DELIVERY_LEAD_DAYS_V, DELIVER_BY_DT = DELIVER_BY_DT_V, LAST_UPDATED_DT = to_timestamp(to_char(sysdate,'DD-MON-RR HH.MI.SSSSS AM'),'DD-MON-RR HH.MI.SSSSS AM'),
      LAST_UPDATED_BY = LAST_UPDATED_BY_V, SEASON_NUM = SEASON_NUM_V, PROG_NAME = PROG_NAME_V 
    WHERE gpms_prog_id = gProgId and gpms_seas_id = gSeasId and STATION_ID = B2B_Station_Id_V;
  else
    Insert into RPM_DEAL_PRODUCT_STITCHED (RPM_STITCHED_ID,RPM_STATION_ID,STATION_ID,STATION_NAME,GPMS_PROG_ID,GPMS_SEAS_ID,PROG_ID,SEAS_ID,TERRITORY_VALUE_CSV,TERRITORY_ID_CSV,CONTRACT_STATUS_VALUE_CSV,CONTRACT_STATUS_TYPE_CSV,LICENSE_TYPE_ID_CSV,LICENSE_TYPE_VALUE_CSV,EXHIBITION_END_DT,EXHIBITION_ST_DT,DELIVERY_LEAD_DAYS,DELIVER_BY_DT,CREATED_DT,CREATED_BY,LAST_UPDATED_DT,LAST_UPDATED_BY,SOURCE_SYSTEM,SEASON_NUM,PROG_NAME,sales_person) 
      values 
      (RPM_DL_PRODUCT_STITCHED_ID_SEQ.nextval,RPM_STATION_ID_V,B2B_Station_Id_V,STATION_NAME_V,GPMS_PROG_ID_V,GPMS_SEAS_ID_V,PROG_ID_V,SEAS_ID_V,TERRITORY_VALUE_CSV_V,TERRITORY_ID_CSV_V,CONTRACT_STATUS_VALUE_CSV_V,CONTRACT_STATUS_TYPE_CSV_V,LICENSE_TYPE_ID_CSV_V,LICENSE_TYPE_VALUE_CSV_V,EXHIBITION_END_DT_V,EXHIBITION_ST_DT_V,DELIVERY_LEAD_DAYS_V,DELIVER_BY_DT_V,
      to_timestamp(to_char(sysdate,'DD-MON-RR HH.MI.SSSSS AM'),'DD-MON-RR HH.MI.SSSSS AM') ,CREATED_BY_V,to_timestamp(to_char(sysdate,'DD-MON-RR HH.MI.SSSSS AM'),'DD-MON-RR HH.MI.SSSSS AM'),LAST_UPDATED_BY_V,SOURCE_SYSTEM_V,SEASON_NUM_V,PROG_NAME_V,sales_person_V);
  end if;
	 
	 
	commit; 

end Stitch_RPM_Contracts_UTIL;
/


  CREATE OR REPLACE EDITIONABLE PROCEDURE "DART_B2B2"."SYNDICATIONS_RUN_PROC" 
IS
  CURSOR syndication_run_info
    IS
      select dealproductid, runlookupid from DTV_B2B2.TEMP_RPM_RUNNUM_EXCEL;
   v_syndication_runs VARCHAR2 (255);
   v_syndication_runs_concat1 VARCHAR2 (255);
   v_syndication_runs_concat2 VARCHAR2 (255);
BEGIN
  
  FOR i IN syndication_run_info
     LOOP
      select SYNDICATION_RUNS into v_syndication_runs from DTV_B2B2.TEMP_RPM_SYNDICATION_DATA2 where dealproductid = i.dealproductid;
      IF v_syndication_runs IS NOT NULL
        THEN
            v_syndication_runs_concat1 :=concat(v_syndication_runs,';');
            v_syndication_runs_concat2 := concat(v_syndication_runs_concat1,i.runlookupid);
            update DTV_B2B2.TEMP_RPM_SYNDICATION_DATA2 set SYNDICATION_RUNS = v_syndication_runs_concat2  where dealproductid = i.dealproductid;
        commit;
      END IF;
      IF v_syndication_runs IS NULL 
        THEN
          update DTV_B2B2.TEMP_RPM_SYNDICATION_DATA2 set SYNDICATION_RUNS = i.runlookupid  where dealproductid = i.dealproductid;
        commit;
      END IF;
   END LOOP;
  
END SYNDICATIONS_RUN_PROC;
/


  CREATE OR REPLACE EDITIONABLE PROCEDURE "DART_B2B2"."SYNDICATION_CUSTOMER_PROC" 
IS
  CURSOR cur_customer_info
    IS
      select  DISTINCT CUSTOMERNUMBER,CUSTOMERNAME from DTV_B2B2.TEMP_RPM_SYNDICATION_DATA2;
   v_cust_id              NUMBER;
   v_cust_name VARCHAR2 (255);
BEGIN
  
  FOR i IN cur_customer_info
     LOOP
      IF i.CUSTOMERNUMBER IS NOT NULL
        THEN
          v_cust_id := i.CUSTOMERNUMBER;
          v_cust_name := TRIM (i.CUSTOMERNAME);
  
  Insert into DART_B2B2.syndication_customer (CUST_ID,CUSTOMER_NAME,CUSTOMER_NUMBER,CREATED_DT,LAST_UPDATED_DT,COUNTRY) 
  values (DART_B2B2.SYNDICATION_CUSTOMER_ID_SEQ.nextval,v_cust_name,v_cust_id,SYSDATE,SYSDATE,null);
  
	commit; 
  
      ELSE
        DBMS_OUTPUT.put_line (' No Record Found ' );
      END IF;
   END LOOP;
  
END SYNDICATION_CUSTOMER_PROC;
/


  CREATE OR REPLACE EDITIONABLE PROCEDURE "DART_B2B2"."SYNDICATION_STATION_MASTER_PROC" 
IS
  CURSOR cur_station_info
    IS
      select  DISTINCT STATIONID,STATIONNAME,CUSTOMERNUMBER from DTV_B2B2.TEMP_RPM_SYNDICATION_DATA2;
   v_station_id             NUMBER;
   v_station_name       VARCHAR2(255);
   v_station_name_source       VARCHAR2(800);
   v_cust_id              NUMBER;
   v_cust_no              NUMBER;
BEGIN
  
  FOR i IN cur_station_info
     LOOP
          v_cust_id := i.CUSTOMERNUMBER;
          v_station_id := i.STATIONID;
          v_station_name_source := TRIM(i.STATIONNAME);
          v_station_name := TRIM (SUBSTR(v_station_name_source, 1, INSTR(v_station_name_source, '(') -1));
             
          select CUST_ID into v_cust_no from DART_B2B2.syndication_customer where CUSTOMER_NUMBER = v_cust_id;
           
  Insert into DART_B2B2.SYNDICATION_STATION_MASTER (STATION_ID,STATION_NAME,SOURCE,CREATED_DT,CREATED_BY,IS_DELETED,IS_ACTIVE,LICENSE_INDICATOR,CUSTOMER_ID,LAST_UPDATED_BY,
	SYND_STATION_ID,LAST_UPDATED_DT, STATION_NAME_SOURCE) values (DART_B2B2.SYNDICATION_STATION_ID_SEQ.nextval,v_station_name,'RPM',SYSDATE, 
	'RPM JMS',0,1,null,TO_NUMBER(v_cust_no),'RPM JMS',TO_NUMBER(v_station_id),SYSDATE, v_station_name_source); 
  
	commit; 
  
   END LOOP;
  
END SYNDICATION_STATION_MASTER_PROC;
/


  CREATE OR REPLACE EDITIONABLE PROCEDURE "DART_B2B2"."TERRITORY_CORRECTION_UTIL" 
--(GPROGID IN VARCHAR2,GSEASID IN VARCHAR2, B2BSTATIONID IN VARCHAR2)
AS
CURSOR DEAL  IS
    SELECT DISTINCT RS.GPMS_PROG_ID,
      RS.GPMS_SEAS_ID,
      RS.STATION_ID,
      RS.TERRITORY_VALUE_CSV,
	  RS.TERRITORY_ID_CSV 
    FROM RPM_DEAL_PRODUCT_STITCHED RS 
      WHERE 
      --  RS.GPMS_PROG_ID = GPROGID AND
      --  RS.GPMS_SEAS_ID = GSEASID AND
      --  RS.STATION_ID = B2BSTATIONID AND
     RS.LAST_UPDATED_BY != 'Manual - Migration (Territory Correction)';
TERRITORY_VALUE_CSV_V VARCHAR2(4000) :=NULL;
TERRITORY_ID_CSV_V VARCHAR2(4000) := NULL;
BEGIN
  FOR I IN DEAL
  LOOP
    TERRITORY_VALUE_CSV_V := NULL;
    TERRITORY_ID_CSV_V := NULL;
	 
      SELECT GET_DEAL_TERRITORY_CSV(I.GPMS_PROG_ID,I.GPMS_SEAS_ID,I.STATION_ID) INTO TERRITORY_VALUE_CSV_V FROM DUAL;
      SELECT GET_DEAL_TERRITORY_IDS(I.GPMS_PROG_ID,I.GPMS_SEAS_ID,I.STATION_ID) INTO TERRITORY_ID_CSV_V FROM DUAL;
      
      IF((I.TERRITORY_VALUE_CSV IS NULL AND TERRITORY_VALUE_CSV_V IS NOT NULL) OR
          (TERRITORY_VALUE_CSV_V IS NULL AND I.TERRITORY_VALUE_CSV IS NOT NULL) OR
          (I.TERRITORY_VALUE_CSV <> TERRITORY_VALUE_CSV_V)) 
          THEN
              UPDATE RPM_DEAL_PRODUCT_STITCHED SET TERRITORY_VALUE_CSV = TERRITORY_VALUE_CSV_V, TERRITORY_ID_CSV = TERRITORY_ID_CSV_V, LAST_UPDATED_BY = 'Manual - Migration (Territory Correction)',
               LAST_UPDATED_DT = TO_TIMESTAMP(TO_CHAR(SYSDATE,'DD-MON-RR HH.MI.SSSSS AM'),'DD-MON-RR HH.MI.SSSSS AM')
                WHERE GPMS_PROG_ID = I.GPMS_PROG_ID AND GPMS_SEAS_ID = I.GPMS_SEAS_ID AND STATION_ID = I.STATION_ID;
              COMMIT;
      END IF;
  END LOOP;

END TERRITORY_CORRECTION_UTIL;
/


  CREATE OR REPLACE EDITIONABLE PROCEDURE "DART_B2B2"."TERRITORY_CORRECTION_UTIL_NEW" 
--(GPROGID IN VARCHAR2,GSEASID IN VARCHAR2, B2BSTATIONID IN VARCHAR2)
AS
CURSOR DEAL  IS
    SELECT DISTINCT RS.GPMS_PROG_ID,
      RS.GPMS_SEAS_ID,
      RS.STATION_ID,
      RS.TERRITORY_VALUE_CSV,
	  RS.TERRITORY_ID_CSV 
    FROM RPM_DEAL_PRODUCT_STITCHED_bkp_Dec22_2020 RS 
      WHERE 
      --  RS.GPMS_PROG_ID = GPROGID AND
      --  RS.GPMS_SEAS_ID = GSEASID AND
      --  RS.STATION_ID = B2BSTATIONID AND
     RS.TERR_MIG_COMPLETED =0 and rownum <1001;
TERRITORY_VALUE_CSV_V VARCHAR2(4000) :=NULL;
TERRITORY_ID_CSV_V VARCHAR2(4000) := NULL;
BEGIN
  FOR I IN DEAL
  LOOP
    TERRITORY_VALUE_CSV_V := NULL;
    TERRITORY_ID_CSV_V := NULL;
	 
      SELECT GET_DEAL_TERRITORY_CSV(I.GPMS_PROG_ID,I.GPMS_SEAS_ID,I.STATION_ID) INTO TERRITORY_VALUE_CSV_V FROM DUAL;
      SELECT GET_DEAL_TERRITORY_IDS(I.GPMS_PROG_ID,I.GPMS_SEAS_ID,I.STATION_ID) INTO TERRITORY_ID_CSV_V FROM DUAL;
      
      IF((I.TERRITORY_VALUE_CSV IS NULL AND TERRITORY_VALUE_CSV_V IS NOT NULL) OR
          (TERRITORY_VALUE_CSV_V IS NULL AND I.TERRITORY_VALUE_CSV IS NOT NULL) OR
          (I.TERRITORY_VALUE_CSV <> TERRITORY_VALUE_CSV_V)) 
          THEN
              UPDATE RPM_DEAL_PRODUCT_STITCHED_bkp_Dec22_2020 SET TERRITORY_VALUE_CSV = TERRITORY_VALUE_CSV_V, TERRITORY_ID_CSV = TERRITORY_ID_CSV_V, LAST_UPDATED_BY = 'Manual - Migration (Territory Correction)',
               LAST_UPDATED_DT = TO_TIMESTAMP(TO_CHAR(SYSDATE,'DD-MON-RR HH.MI.SSSSS AM'),'DD-MON-RR HH.MI.SSSSS AM'),
			   TERR_MIG_COMPLETED =1			         
                WHERE GPMS_PROG_ID = I.GPMS_PROG_ID AND GPMS_SEAS_ID = I.GPMS_SEAS_ID AND STATION_ID = I.STATION_ID;
              COMMIT;
		ELSE 	   
			UPDATE RPM_DEAL_PRODUCT_STITCHED_bkp_Dec22_2020 SET TERR_MIG_COMPLETED =1			         
                WHERE GPMS_PROG_ID = I.GPMS_PROG_ID AND GPMS_SEAS_ID = I.GPMS_SEAS_ID AND STATION_ID = I.STATION_ID;
			COMMIT;   
      END IF;
  END LOOP;

END TERRITORY_CORRECTION_UTIL_NEW;
/


  CREATE OR REPLACE EDITIONABLE PROCEDURE "DART_B2B2"."UPDATEDATESHAVING99" As
iEXHIBITION_END_DT timestamp(6) := null;
iEXHIBITION_ST_DT  timestamp(6) := null;
iDELIVER_BY_DT timestamp(6) := null;
cursor deal is
	select distinct gpms_prog_id,gpms_seas_id,rpm_station_id from RPM_DEAL_PRODUCT_STITCHED where (EXHIBITION_END_DT  like '%-99%' or  
	EXHIBITION_ST_DT  like '%-99%' or DELIVER_BY_DT  like '%-99%'); 
begin
	for i in deal 
		loop  
			iEXHIBITION_END_DT :=null;   
			iEXHIBITION_ST_DT:=null;   
			iDELIVER_BY_DT:=null;   
			   
			select max(EXHIBITION_END_DT) as EXHIBITION_END_DT, min(EXHIBITION_ST_DT) as EXHIBITION_ST_DT, (min(EXHIBITION_ST_DT) - 120) as  DELIVER_BY_DT    
			into iEXHIBITION_END_DT, iEXHIBITION_ST_DT,iDELIVER_BY_DT from RPM_DEAL_Product where gpms_prog_id = i.gpms_prog_id and gpms_seas_id = i.gpms_seas_id    
      and rpm_station_id = i.rpm_station_id;
		  
			update RPM_DEAL_Product_stitched set EXHIBITION_END_DT = iEXHIBITION_END_DT,EXHIBITION_ST_DT=iEXHIBITION_ST_DT,DELIVER_BY_DT=iDELIVER_BY_DT,last_updated_dt = sysdate   
			where gpms_prog_id = i.gpms_prog_id and gpms_seas_id = i.gpms_seas_id and rpm_station_id = i.rpm_station_id;   
			   
			commit;   
			   
		end loop;   
end UpdateDatesHaving99;
/


  CREATE OR REPLACE EDITIONABLE PROCEDURE "DART_B2B2"."UPDATE_GPMSDATA_PROC" (pgpmsId IN VARCHAR2)
As
g_prog_id varchar2(255) :=null;
g_seas_id varchar2(255) :=null;
gpId Number(19) :=null;
gsId Number(19) :=null;
valueString varchar2(255) :=null;

cursor gpmsIds IS
	select distinct gpms_product_id as gpmsId from RPM_DEAL_PRODUCT; 
Begin
For i in gpmsIds
loop
g_prog_id  :=null;
g_seas_id :=null;
gpId  :=null;
gsId :=null;
valueString  :=null;

	select B2B2_GPMS.GET_GPMS_PROG_SEAS_ID(i.gpmsId) into valueString from dual;   
  select regexp_substr(valueString, '[^,]+',1,1) into g_prog_id from dual;
  select regexp_substr(valueString, '[^,]+',1,2) into g_seas_id from dual ;
  
  if (g_prog_id is not null) then
		gpId := LTRIM(RTRIM(g_prog_id));  
		end if;  
  if(g_seas_id is not null) then
		gsId := LTRIM(RTRIM(g_seas_id));  
		end if;  
	update RPM_DEAL_PRODUCT set GPMS_PROG_ID = Decode(gpId,null,0,gpId), GPMS_SEAS_ID = Decode(gsId,null,0,gsId) where  gpms_product_id = i.gpmsId; 
  commit;
end loop;
end Update_GPMSData_Proc;
/


  CREATE OR REPLACE EDITIONABLE PROCEDURE "DART_B2B2"."UPDATE_TITLE_DATA_TO_DEAL_PRODUCT_SYND" 
IS
BEGIN
  UPDATE dart_b2b2.rpm_deal_product_synd rdp
  SET
    (
      gpms_prog_id ,
      gpms_Seas_id ,
      gpms_eps_id,
      prog_type,
      prog_name
    )
    =
    (SELECT DECODE(prog_gpms_id, NULL, 0, prog_gpms_id) prog_gpms_id,
      DECODE(seas_gpms_id, NULL, 0, seas_gpms_id),
      eps_gpms_id,
      'TV Series',
      title_name
    FROM DTV_B2B2.CONNECT_GPMS_TITLES_FOR_MIGRATION
    WHERE eps_gpms_id = gpms_product_id
    AND is_tvseries   = 1
    )
  WHERE EXISTS
    (SELECT 1
    FROM DTV_B2B2.CONNECT_GPMS_TITLES_FOR_MIGRATION cgt
    WHERE rdp.GPMS_PRODUCT_ID = cgt.eps_gpms_id
    AND rdp.gpms_product_id  IN
      ( SELECT DISTINCT eps_gpms_id
      FROM DTV_B2B2.CONNECT_GPMS_TITLES_FOR_MIGRATION
      WHERE is_tvseries = 1
      AND eps_gpms_id  IN
        ( SELECT DISTINCT gpms_product_id
        FROM rpm_deal_product_synd
        WHERE gpms_eps_id =0
        )
      )
    );
  
  UPDATE dart_b2b2.rpm_deal_product_synd
  SET prog_type       ='Feature'
  WHERE gpms_product_id IN
    (SELECT DECODE(prog_gpms_id, NULL, 0, prog_gpms_id) prog_gpms_id
    FROM DTV_B2B2.CONNECT_GPMS_TITLES_FOR_MIGRATION
    WHERE is_tvseries = 0
    AND prog_gpms_id IN
      ( SELECT DISTINCT gpms_product_id FROM dart_b2b2.rpm_deal_product_synd
      )
    )
  AND prog_type IS NULL;
 
 
  UPDATE dart_b2b2.rpm_deal_product_synd rdp
  SET rdp.prog_name =
    (SELECT DISTINCT title_name
    FROM DTV_B2B2.CONNECT_GPMS_TITLES_FOR_MIGRATION mig
    WHERE mig.prog_gpms_id = rdp.gpms_prog_id
    AND mig.is_tvseries    =0
    )
  WHERE rdp.prog_type='Feature'
  AND rdp.prog_name IS NULL;
  
  COMMIT;

END UPDATE_TITLE_DATA_TO_DEAL_PRODUCT_SYND;
/


  
BEGIN 
dbms_scheduler.create_job('"RPMSTITCHINGFORDELTA_TEMP"',
job_type=>'STORED_PROCEDURE', job_action=>
'DART_B2B2.RunStitchingMigration'
, number_of_arguments=>0,
start_date=>TO_TIMESTAMP_TZ('29-JAN-2018 12.30.00.000000000 AM AMERICA/LOS_ANGELES','DD-MON-RRRR HH.MI.SSXFF AM TZR','NLS_DATE_LANGUAGE=english'), repeat_interval=> 
'FREQ=DAILY;BYDAY=MON,TUE,WED,THU,FRI,SAT,SUN'
, end_date=>NULL,
job_class=>'"DEFAULT_JOB_CLASS"', enabled=>FALSE, auto_drop=>FALSE,comments=>
'Final job to stitch rpm records'
);
sys.dbms_scheduler.set_attribute('"RPMSTITCHINGFORDELTA_TEMP"','NLS_ENV','NLS_LANGUAGE=''AMERICAN'' NLS_TERRITORY=''AMERICA'' NLS_CURRENCY=''$'' NLS_ISO_CURRENCY=''AMERICA'' NLS_NUMERIC_CHARACTERS=''.,'' NLS_CALENDAR=''GREGORIAN'' NLS_DATE_FORMAT=''DD-MON-RR'' NLS_DATE_LANGUAGE=''AMERICAN'' NLS_SORT=''BINARY'' NLS_TIME_FORMAT=''HH.MI.SSXFF AM'' NLS_TIMESTAMP_FORMAT=''DD-MON-RR HH.MI.SSXFF AM'' NLS_TIME_TZ_FORMAT=''HH.MI.SSXFF AM TZR'' NLS_TIMESTAMP_TZ_FORMAT=''DD-MON-RR HH.MI.SSXFF AM TZR'' NLS_DUAL_CURRENCY=''$'' NLS_COMP=''BINARY'' NLS_LENGTH_SEMANTICS=''BYTE'' NLS_NCHAR_CONV_EXCP=''FALSE''');
COMMIT; 
END; 
/ 


  
BEGIN 
dbms_scheduler.create_job('"RPMStitchingThread1"',
job_type=>'STORED_PROCEDURE', job_action=>
'DART_B2B2.RUNSTITCHINGMIGRATION1'
, number_of_arguments=>0,
start_date=>TO_TIMESTAMP_TZ('05-SEP-2016 11.00.15.000000000 PM AMERICA/LOS_ANGELES','DD-MON-RRRR HH.MI.SSXFF AM TZR','NLS_DATE_LANGUAGE=english'), repeat_interval=> 
NULL
, end_date=>NULL,
job_class=>'"DEFAULT_JOB_CLASS"', enabled=>FALSE, auto_drop=>FALSE,comments=>
'Stitching for station having station id less than 1800'
);
sys.dbms_scheduler.set_attribute('"RPMStitchingThread1"','NLS_ENV','NLS_LANGUAGE=''AMERICAN'' NLS_TERRITORY=''AMERICA'' NLS_CURRENCY=''$'' NLS_ISO_CURRENCY=''AMERICA'' NLS_NUMERIC_CHARACTERS=''.,'' NLS_CALENDAR=''GREGORIAN'' NLS_DATE_FORMAT=''DD-MON-RR'' NLS_DATE_LANGUAGE=''AMERICAN'' NLS_SORT=''BINARY'' NLS_TIME_FORMAT=''HH.MI.SSXFF AM'' NLS_TIMESTAMP_FORMAT=''DD-MON-RR HH.MI.SSXFF AM'' NLS_TIME_TZ_FORMAT=''HH.MI.SSXFF AM TZR'' NLS_TIMESTAMP_TZ_FORMAT=''DD-MON-RR HH.MI.SSXFF AM TZR'' NLS_DUAL_CURRENCY=''$'' NLS_COMP=''BINARY'' NLS_LENGTH_SEMANTICS=''BYTE'' NLS_NCHAR_CONV_EXCP=''FALSE''');
COMMIT; 
END; 
/ 


  
BEGIN 
dbms_scheduler.create_job('"RPMStitchingThread2"',
job_type=>'STORED_PROCEDURE', job_action=>
'DART_B2B2.RUNSTITCHINGMIGRATION2'
, number_of_arguments=>0,
start_date=>TO_TIMESTAMP_TZ('05-SEP-2016 11.01.00.000000000 PM AMERICA/LOS_ANGELES','DD-MON-RRRR HH.MI.SSXFF AM TZR','NLS_DATE_LANGUAGE=english'), repeat_interval=> 
NULL
, end_date=>NULL,
job_class=>'"DEFAULT_JOB_CLASS"', enabled=>FALSE, auto_drop=>FALSE,comments=>
'Stitching logic for the station having station id greater than 18000'
);
sys.dbms_scheduler.set_attribute('"RPMStitchingThread2"','NLS_ENV','NLS_LANGUAGE=''AMERICAN'' NLS_TERRITORY=''AMERICA'' NLS_CURRENCY=''$'' NLS_ISO_CURRENCY=''AMERICA'' NLS_NUMERIC_CHARACTERS=''.,'' NLS_CALENDAR=''GREGORIAN'' NLS_DATE_FORMAT=''DD-MON-RR'' NLS_DATE_LANGUAGE=''AMERICAN'' NLS_SORT=''BINARY'' NLS_TIME_FORMAT=''HH.MI.SSXFF AM'' NLS_TIMESTAMP_FORMAT=''DD-MON-RR HH.MI.SSXFF AM'' NLS_TIME_TZ_FORMAT=''HH.MI.SSXFF AM TZR'' NLS_TIMESTAMP_TZ_FORMAT=''DD-MON-RR HH.MI.SSXFF AM TZR'' NLS_DUAL_CURRENCY=''$'' NLS_COMP=''BINARY'' NLS_LENGTH_SEMANTICS=''BYTE'' NLS_NCHAR_CONV_EXCP=''FALSE''');
COMMIT; 
END; 
/ 


  
BEGIN 
dbms_scheduler.create_job('"RPM_DEAL_STITCHING_JOB"',
job_type=>'STORED_PROCEDURE', job_action=>
'DART_B2B2.RUN_INTL_LICENSE_STITCH'
, number_of_arguments=>0,
start_date=>TO_TIMESTAMP_TZ('22-JUN-2018 12.05.00.000000000 AM US/PACIFIC','DD-MON-RRRR HH.MI.SSXFF AM TZR','NLS_DATE_LANGUAGE=english'), repeat_interval=> 
'FREQ=DAILY'
, end_date=>NULL,
job_class=>'"DEFAULT_JOB_CLASS"', enabled=>FALSE, auto_drop=>TRUE,comments=>
'Job scheduled to stitch RPM Contracts on daily basis'
);
sys.dbms_scheduler.set_attribute('"RPM_DEAL_STITCHING_JOB"','NLS_ENV','NLS_LANGUAGE=''AMERICAN'' NLS_TERRITORY=''AMERICA'' NLS_CURRENCY=''$'' NLS_ISO_CURRENCY=''AMERICA'' NLS_NUMERIC_CHARACTERS=''.,'' NLS_CALENDAR=''GREGORIAN'' NLS_DATE_FORMAT=''DD-MON-RR'' NLS_DATE_LANGUAGE=''AMERICAN'' NLS_SORT=''BINARY'' NLS_TIME_FORMAT=''HH.MI.SSXFF AM'' NLS_TIMESTAMP_FORMAT=''DD-MON-RR HH.MI.SSXFF AM'' NLS_TIME_TZ_FORMAT=''HH.MI.SSXFF AM TZR'' NLS_TIMESTAMP_TZ_FORMAT=''DD-MON-RR HH.MI.SSXFF AM TZR'' NLS_DUAL_CURRENCY=''$'' NLS_COMP=''BINARY'' NLS_LENGTH_SEMANTICS=''BYTE'' NLS_NCHAR_CONV_EXCP=''FALSE''');
dbms_scheduler.enable('"RPM_DEAL_STITCHING_JOB"');
COMMIT; 
END; 
/ 


   CREATE SEQUENCE  "DART_B2B2"."INTL_CUSTOMER_ID_SEQ"  MINVALUE 1 MAXVALUE 999999999999999999999999999 INCREMENT BY 1 START WITH 61544 CACHE 20 NOORDER  NOCYCLE  NOKEEP  NOSCALE  GLOBAL ;


   CREATE SEQUENCE  "DART_B2B2"."INTL_STATION_ID_SEQ"  MINVALUE 1 MAXVALUE 999999999999999999999999999 INCREMENT BY 1 START WITH 385210 CACHE 20 NOORDER  NOCYCLE  NOKEEP  NOSCALE  GLOBAL ;


   CREATE SEQUENCE  "DART_B2B2"."PROG_MANAGE_RUNNO_SYND_SEQ"  MINVALUE 0 MAXVALUE 9999999999999999999999999999 INCREMENT BY 1 START WITH 1 CACHE 20 NOORDER  NOCYCLE  NOKEEP  NOSCALE  GLOBAL ;


   CREATE SEQUENCE  "DART_B2B2"."RPMDLPRODUCTSTITCHED_ID_SEQ"  MINVALUE 125000 MAXVALUE 999999999999999999999999999 INCREMENT BY 1 START WITH 546314 CACHE 20 NOORDER  NOCYCLE  NOKEEP  NOSCALE  GLOBAL ;


   CREATE SEQUENCE  "DART_B2B2"."RPMDPH_ID_SEQ"  MINVALUE 1 MAXVALUE 999999999999999999999999999 INCREMENT BY 1 START WITH 2688841 CACHE 20 NOORDER  NOCYCLE  NOKEEP  NOSCALE  GLOBAL ;


   CREATE SEQUENCE  "DART_B2B2"."RPM_DL_PRODUCT_STITCHED_ID_SEQ"  MINVALUE 1 MAXVALUE 999999999999999999999999999 INCREMENT BY 1 START WITH 544913 CACHE 20 NOORDER  NOCYCLE  NOKEEP  NOSCALE  GLOBAL ;


   CREATE SEQUENCE  "DART_B2B2"."RPM_DP_HISTORICAL_SEQ"  MINVALUE 1 MAXVALUE 9999999999999999999999999999 INCREMENT BY 1 START WITH 1 CACHE 20 NOORDER  NOCYCLE  NOKEEP  NOSCALE  GLOBAL ;


   CREATE SEQUENCE  "DART_B2B2"."RPM_JSON_LOG_SEQ"  MINVALUE 1 MAXVALUE 999999999999999999999999999 INCREMENT BY 1 START WITH 8333839 CACHE 20 NOORDER  NOCYCLE  NOKEEP  NOSCALE  GLOBAL ;


   CREATE SEQUENCE  "DART_B2B2"."RPM_STICHED_ID_SEQ"  MINVALUE 1 MAXVALUE 999999999999999999999999999 INCREMENT BY 1 START WITH 161861 CACHE 20 NOORDER  NOCYCLE  NOKEEP  NOSCALE  GLOBAL ;


   CREATE SEQUENCE  "DART_B2B2"."RPM_TER_MEDIA_ID_SEQ"  MINVALUE 1 MAXVALUE 999999999999999999999999999 INCREMENT BY 1 START WITH 72535643 CACHE 20 NOORDER  NOCYCLE  NOKEEP  NOSCALE  GLOBAL ;


   CREATE SEQUENCE  "DART_B2B2"."RPM_TER_MEDIA_ID_SYND_SEQ"  MINVALUE 1 MAXVALUE 999999999999999999999999999 INCREMENT BY 1 START WITH 72716283 CACHE 20 NOORDER  NOCYCLE  NOKEEP  NOSCALE  GLOBAL ;


   CREATE SEQUENCE  "DART_B2B2"."RPM_TER_MEDIA_LANG_ID_SEQ"  MINVALUE 1 MAXVALUE 999999999999999999999999999 INCREMENT BY 1 START WITH 93075859 CACHE 20 NOORDER  NOCYCLE  NOKEEP  NOSCALE  GLOBAL ;


   CREATE SEQUENCE  "DART_B2B2"."RPM_TER_MEDIA_LANG_ID_SYND_SEQ"  MINVALUE 1 MAXVALUE 999999999999999999999999999 INCREMENT BY 1 START WITH 93155819 CACHE 20 NOORDER  NOCYCLE  NOKEEP  NOSCALE  GLOBAL ;


   CREATE SEQUENCE  "DART_B2B2"."RPM__AUDIT_EMAIL_ID_SEQ"  MINVALUE 1 MAXVALUE 999999999999999999999999999 INCREMENT BY 1 START WITH 868812 CACHE 20 NOORDER  NOCYCLE  NOKEEP  NOSCALE  GLOBAL ;


   CREATE SEQUENCE  "DART_B2B2"."STG_RPM_DEAL_PRODUCT_ID_SEQ"  MINVALUE 1 MAXVALUE 999999999999999999999999999 INCREMENT BY 1 START WITH 137670 CACHE 20 NOORDER  NOCYCLE  NOKEEP  NOSCALE  GLOBAL ;


   CREATE SEQUENCE  "DART_B2B2"."STG_RPM_TER_MEDIA_ID_SEQ"  MINVALUE 1 MAXVALUE 999999999999999999999999999 INCREMENT BY 1 START WITH 1018926 CACHE 20 NOORDER  NOCYCLE  NOKEEP  NOSCALE  GLOBAL ;


   CREATE SEQUENCE  "DART_B2B2"."STG_RPM_TER_MEDIA_LANG_ID_SEQ"  MINVALUE 1 MAXVALUE 999999999999999999999999999 INCREMENT BY 1 START WITH 1391913 CACHE 20 NOORDER  NOCYCLE  NOKEEP  NOSCALE  GLOBAL ;


   CREATE SEQUENCE  "DART_B2B2"."SYNDICATION_CUSTOMER_ID_SEQ"  MINVALUE 0 MAXVALUE 9999999999999999999999999999 INCREMENT BY 1 START WITH 34160 CACHE 20 NOORDER  NOCYCLE  NOKEEP  NOSCALE  GLOBAL ;


   CREATE SEQUENCE  "DART_B2B2"."SYNDICATION_STATION_ID_SEQ"  MINVALUE 0 MAXVALUE 9999999999999999999999999999 INCREMENT BY 1 START WITH 50690 CACHE 20 NOORDER  NOCYCLE  NOKEEP  NOSCALE  GLOBAL ;


   CREATE SEQUENCE  "DART_B2B2"."SYND_TER_MEDIA_ID_SEQ"  MINVALUE 1 MAXVALUE 999999999999999999999999999 INCREMENT BY 1 START WITH 72378723 CACHE 20 NOORDER  NOCYCLE  NOKEEP  NOSCALE  GLOBAL ;


  CREATE OR REPLACE EDITIONABLE SYNONYM "DART_B2B2"."B2BPROPERTIES" FOR "DTV_B2B2"."B2BPROPERTIES";


  CREATE OR REPLACE EDITIONABLE SYNONYM "DART_B2B2"."PROG_MANAGE_ACCESS" FOR "DTV_B2B2"."PROG_MANAGE_ACCESS";


  CREATE OR REPLACE EDITIONABLE SYNONYM "DART_B2B2"."RPM_B2B_QUERY_DATA" FOR "DTV_B2B2"."RPM_B2B_QUERY_DATA";


  CREATE OR REPLACE EDITIONABLE SYNONYM "DART_B2B2"."RPM_DEAL_STITCH_SYNDICATION" FOR "DTV_B2B2"."RPM_DEAL_STITCH_SYNDICATION";


  CREATE TABLE "DART_B2B2"."IC_JUNE28_2019" 
   (	"CUST_ID" NUMBER(10,0) NOT NULL ENABLE,  
	"CUSTOMER_NAME" VARCHAR2(255) NOT NULL ENABLE,  
	"CUSTOMER_NUMBER" NUMBER(10,0),  
	"CREATED_DT" TIMESTAMP (6),  
	"LAST_UPDATED_DT" TIMESTAMP (6),  
	"COUNTRY" VARCHAR2(255) 
   ) SEGMENT CREATION IMMEDIATE 
  PCTFREE 10 PCTUSED 40 INITRANS 1 MAXTRANS 255 
 NOCOMPRESS LOGGING
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SPT_DATA1" ;


  CREATE TABLE "DART_B2B2"."INTL_CUSTOMER" 
   (	"CUST_ID" NUMBER(10,0) NOT NULL ENABLE,  
	"CUSTOMER_NAME" VARCHAR2(255) NOT NULL ENABLE,  
	"CUSTOMER_NUMBER" NUMBER(10,0),  
	"CREATED_DT" TIMESTAMP (6) DEFAULT CURRENT_TIMESTAMP,  
	"LAST_UPDATED_DT" TIMESTAMP (6) DEFAULT CURRENT_TIMESTAMP,  
	"COUNTRY" VARCHAR2(255),  
	 PRIMARY KEY ("CUST_ID") 
  USING INDEX PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SPT_DATA1"  ENABLE
   ) SEGMENT CREATION IMMEDIATE 
  PCTFREE 10 PCTUSED 40 INITRANS 1 MAXTRANS 255 
 NOCOMPRESS LOGGING
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SPT_DATA1" ;


  CREATE TABLE "DART_B2B2"."INTL_CUSTOMER_HISTORICAL" 
   (	"CUST_ID" NUMBER(10,0) NOT NULL ENABLE,  
	"CUSTOMER_NAME" VARCHAR2(255) NOT NULL ENABLE,  
	"CUSTOMER_NUMBER" NUMBER(10,0),  
	"CREATED_DT" TIMESTAMP (6) DEFAULT CURRENT_TIMESTAMP,  
	"LAST_UPDATED_DT" TIMESTAMP (6) DEFAULT CURRENT_TIMESTAMP,  
	"COUNTRY" VARCHAR2(255),  
	 PRIMARY KEY ("CUST_ID") 
  USING INDEX PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SPT_DATA1"  ENABLE
   ) SEGMENT CREATION IMMEDIATE 
  PCTFREE 10 PCTUSED 40 INITRANS 1 MAXTRANS 255 
 NOCOMPRESS LOGGING
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SPT_DATA1" ;


  CREATE TABLE "DART_B2B2"."INTL_STATION" 
   (	"STATION_ID" NUMBER(10,0) NOT NULL ENABLE,  
	"STATION_NAME" VARCHAR2(4000) NOT NULL ENABLE,  
	"CUST_ID" NUMBER(10,0),  
	"STATION_TYPE" VARCHAR2(255),  
	"RPM_STATION_ID" NUMBER(10,0),  
	"CREATED_DT" TIMESTAMP (6) DEFAULT CURRENT_TIMESTAMP,  
	"LAST_UPDATED_DT" TIMESTAMP (6) DEFAULT CURRENT_TIMESTAMP,  
	"IS_DELETED" NUMBER(1,0) DEFAULT 0,  
	"IS_ACTIVE" NUMBER DEFAULT (0),  
	"LICENSE_INDICATOR" NUMBER DEFAULT 0,  
	 PRIMARY KEY ("STATION_ID") 
  USING INDEX PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SPT_DATA1"  ENABLE, 
	 CONSTRAINT "FK_INTL_CUST_ID" FOREIGN KEY ("CUST_ID") 
	  REFERENCES "DART_B2B2"."INTL_CUSTOMER" ("CUST_ID") ENABLE 
   ) SEGMENT CREATION IMMEDIATE 
  PCTFREE 10 PCTUSED 40 INITRANS 1 MAXTRANS 255 
 NOCOMPRESS LOGGING
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SPT_DATA1" ;


  CREATE TABLE "DART_B2B2"."INTL_STATION_HISTORICAL" 
   (	"STATION_ID" NUMBER(10,0) NOT NULL ENABLE,  
	"STATION_NAME" VARCHAR2(4000) NOT NULL ENABLE,  
	"CUST_ID" NUMBER(10,0),  
	"STATION_TYPE" VARCHAR2(255),  
	"RPM_STATION_ID" NUMBER(10,0),  
	"CREATED_DT" TIMESTAMP (6) DEFAULT CURRENT_TIMESTAMP,  
	"LAST_UPDATED_DT" TIMESTAMP (6) DEFAULT CURRENT_TIMESTAMP,  
	"IS_DELETED" NUMBER(1,0) DEFAULT 0,  
	"IS_ACTIVE" NUMBER DEFAULT (0),  
	"LICENSE_INDICATOR" NUMBER DEFAULT 0,  
	 PRIMARY KEY ("STATION_ID") 
  USING INDEX PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SPT_DATA1"  ENABLE
   ) SEGMENT CREATION IMMEDIATE 
  PCTFREE 10 PCTUSED 40 INITRANS 1 MAXTRANS 255 
 NOCOMPRESS LOGGING
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SPT_DATA1" ;


  CREATE TABLE "DART_B2B2"."IS_14_AUG_2019" 
   (	"STATION_ID" NUMBER(10,0) NOT NULL ENABLE,  
	"STATION_NAME" VARCHAR2(4000) NOT NULL ENABLE,  
	"CUST_ID" NUMBER(10,0),  
	"STATION_TYPE" VARCHAR2(255),  
	"RPM_STATION_ID" NUMBER(10,0),  
	"CREATED_DT" TIMESTAMP (6),  
	"LAST_UPDATED_DT" TIMESTAMP (6),  
	"IS_DELETED" NUMBER(1,0),  
	"IS_ACTIVE" NUMBER,  
	"LICENSE_INDICATOR" NUMBER 
   ) SEGMENT CREATION IMMEDIATE 
  PCTFREE 10 PCTUSED 40 INITRANS 1 MAXTRANS 255 
 NOCOMPRESS LOGGING
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SPT_DATA1" ;


  CREATE TABLE "DART_B2B2"."IS_JUNE28_2019" 
   (	"STATION_ID" NUMBER(10,0) NOT NULL ENABLE,  
	"STATION_NAME" VARCHAR2(4000) NOT NULL ENABLE,  
	"CUST_ID" NUMBER(10,0),  
	"STATION_TYPE" VARCHAR2(255),  
	"RPM_STATION_ID" NUMBER(10,0),  
	"CREATED_DT" TIMESTAMP (6),  
	"LAST_UPDATED_DT" TIMESTAMP (6),  
	"IS_DELETED" NUMBER(1,0),  
	"IS_ACTIVE" NUMBER,  
	"LICENSE_INDICATOR" NUMBER 
   ) SEGMENT CREATION IMMEDIATE 
  PCTFREE 10 PCTUSED 40 INITRANS 1 MAXTRANS 255 
 NOCOMPRESS LOGGING
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SPT_DATA1" ;


  CREATE TABLE "DART_B2B2"."LOOKUP_TYPE" 
   (	"LKP_TYPE_ID" NUMBER(10,0) NOT NULL ENABLE,  
	"COMMENTS" VARCHAR2(255 CHAR),  
	"ENUM_CODE" VARCHAR2(255 CHAR),  
	"TYPE_NAME" VARCHAR2(255 CHAR),  
	 CONSTRAINT "LOOKUP_TYPE_PK" PRIMARY KEY ("LKP_TYPE_ID") 
  USING INDEX PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SPT_DATA1"  ENABLE
   ) SEGMENT CREATION IMMEDIATE 
  PCTFREE 10 PCTUSED 40 INITRANS 1 MAXTRANS 255 
 NOCOMPRESS LOGGING
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SPT_DATA1" ;


  CREATE TABLE "DART_B2B2"."LOOKUP_VALUE" 
   (	"LKP_ID" NUMBER(10,0) NOT NULL ENABLE,  
	"COMMENTS" VARCHAR2(255 CHAR),  
	"DISP_ORDER" NUMBER(10,0),  
	"ENUM_CODE" VARCHAR2(255 CHAR),  
	"VALUE" VARCHAR2(255 CHAR),  
	"LKP_TYPE_ID" NUMBER(10,0),  
	 CONSTRAINT "LOOKUP_VALUE_PK" PRIMARY KEY ("LKP_ID") 
  USING INDEX PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SPT_DATA1"  ENABLE
   ) SEGMENT CREATION IMMEDIATE 
  PCTFREE 10 PCTUSED 40 INITRANS 1 MAXTRANS 255 
 NOCOMPRESS LOGGING
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SPT_DATA1" ;


  CREATE TABLE "DART_B2B2"."LOOKUP_VALUE_LANGUAGE" 
   (	"LKP_ID" NUMBER(10,0) NOT NULL ENABLE,  
	"LANGUAGE_ID" NUMBER(10,0) NOT NULL ENABLE,  
	"COMMENTS" VARCHAR2(255 CHAR),  
	"DISP_ORDER" NUMBER(10,0),  
	"ENUM_CODE" VARCHAR2(255 CHAR),  
	"VALUE" VARCHAR2(255 CHAR),  
	"LKP_TYPE_ID" NUMBER(10,0) 
   ) SEGMENT CREATION IMMEDIATE 
  PCTFREE 10 PCTUSED 40 INITRANS 1 MAXTRANS 255 
 NOCOMPRESS LOGGING
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SPT_DATA1" ;


  CREATE TABLE "DART_B2B2"."MANUAL_LEADDAYS_FOR_INTL" 
   (	"PROG_ID" NUMBER(10,0) NOT NULL ENABLE,  
	"RPM_REQUEST_ID" NUMBER(10,0),  
	"STATION_NAME" VARCHAR2(200),  
	"DIST_TYPE_ID" NUMBER(10,0),  
	"ACCESS_LEAD_DAYS" NUMBER(10,0),  
	"TERRITORY_ID" NUMBER(10,0) 
   ) SEGMENT CREATION IMMEDIATE 
  PCTFREE 10 PCTUSED 40 INITRANS 1 MAXTRANS 255 
 NOCOMPRESS LOGGING
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SPT_DATA1" ;


  CREATE TABLE "DART_B2B2"."PMAI_14_AUG_2019" 
   (	"ACCESS_ID" NUMBER(10,0),  
	"STATION" VARCHAR2(255 CHAR),  
	"TERRITORY_CSV" VARCHAR2(4000),  
	"OVR_START_DT" DATE,  
	"OVR_END_DT" DATE,  
	"RPM_LICENSE_START_DATE" DATE,  
	"RPM_LICENSE_END_DATE" DATE,  
	"RPM_REQUEST_ID" VARCHAR2(10),  
	"SOURCE_TYPE" VARCHAR2(255 CHAR),  
	"LEAD_TIME" NUMBER,  
	"LKP_CUST_TYPE" NUMBER(10,0),  
	"LKP_DIST_TYPE_ID" NUMBER(10,0),  
	"PROG_ID" NUMBER(10,0),  
	"IS_DELETED" NUMBER(1,0),  
	"IS_OVERRIDDEN" NUMBER(1,0),  
	"PROG_SEAS_ID" NUMBER,  
	"TERRITORY_ID" NUMBER(10,0),  
	"LANGUAGE_ID" NUMBER(10,0),  
	"CREATED_BY" VARCHAR2(255) NOT NULL ENABLE,  
	"CREATED_DT" TIMESTAMP (6) NOT NULL ENABLE,  
	"LAST_UPDATED_BY" VARCHAR2(255) NOT NULL ENABLE,  
	"LAST_UPDATED_DT" TIMESTAMP (6) NOT NULL ENABLE,  
	"VERSION" NUMBER(10,0),  
	"CONTRACT_STATUS" VARCHAR2(255),  
	"STATUS_TYPE" VARCHAR2(255),  
	"STATION_ID" NUMBER(10,0),  
	"CUSTOMER_ID" NUMBER(10,0),  
	"PROG_SEAS_NUM" VARCHAR2(20),  
	"RPM_STITCHED_ID" NUMBER(20,0),  
	"LICENSE_TYPE_CSV" VARCHAR2(1000),  
	"SYS_SYNCED_DT" TIMESTAMP (6) 
   ) SEGMENT CREATION IMMEDIATE 
  PCTFREE 10 PCTUSED 40 INITRANS 1 MAXTRANS 255 
 NOCOMPRESS LOGGING
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SPT_DATA1" ;


  CREATE TABLE "DART_B2B2"."PROG_ACCESS_LANGUAGE" 
   (	"ACCESS_ID" NUMBER(19,0),  
	"LANGUAGE_ID" NUMBER(19,0),  
	 CONSTRAINT "FK_ACCESS_ID_LANG" FOREIGN KEY ("ACCESS_ID") 
	  REFERENCES "DART_B2B2"."PROG_MANAGE_ACCESS_INTL" ("ACCESS_ID") ENABLE,  
	 CONSTRAINT "FK_TERRITORY_ID_LANG" FOREIGN KEY ("LANGUAGE_ID") 
	  REFERENCES "DART_B2B2"."RPM_LANGUAGE" ("LANGUAGE_ID") ENABLE 
   ) SEGMENT CREATION IMMEDIATE 
  PCTFREE 10 PCTUSED 40 INITRANS 1 MAXTRANS 255 
 NOCOMPRESS LOGGING
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SPT_DATA1" ;


  CREATE TABLE "DART_B2B2"."PROG_ACCESS_MEDIA" 
   (	"ACCESS_ID" NUMBER(19,0),  
	"MEDIA_ID" NUMBER(19,0),  
	 CONSTRAINT "FK_TERRITORY_ID_MED" FOREIGN KEY ("MEDIA_ID") 
	  REFERENCES "DART_B2B2"."RPM_MEDIA" ("MEDIA_ID") ENABLE,  
	 CONSTRAINT "FK_ACCESS_ID_MED" FOREIGN KEY ("ACCESS_ID") 
	  REFERENCES "DART_B2B2"."PROG_MANAGE_ACCESS_INTL" ("ACCESS_ID") ENABLE 
   ) SEGMENT CREATION IMMEDIATE 
  PCTFREE 10 PCTUSED 40 INITRANS 1 MAXTRANS 255 
 NOCOMPRESS LOGGING
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SPT_DATA1" ;


  CREATE TABLE "DART_B2B2"."PROG_ACCESS_TERRITORY" 
   (	"ACCESS_ID" NUMBER(19,0),  
	"TERRITORY_ID" NUMBER(19,0),  
	 CONSTRAINT "FK_TERRITORY_ID_TER" FOREIGN KEY ("TERRITORY_ID") 
	  REFERENCES "DART_B2B2"."RPM_TERRITORY" ("TERRITORY_ID") ENABLE,  
	 CONSTRAINT "FK_ACCESS_ID_TER" FOREIGN KEY ("ACCESS_ID") 
	  REFERENCES "DART_B2B2"."PROG_MANAGE_ACCESS_INTL" ("ACCESS_ID") ENABLE 
   ) SEGMENT CREATION IMMEDIATE 
  PCTFREE 10 PCTUSED 40 INITRANS 1 MAXTRANS 255 
 NOCOMPRESS LOGGING
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SPT_DATA1" ;


  CREATE TABLE "DART_B2B2"."PROG_MANAGE_ACCESS_INTL" 
   (	"ACCESS_ID" NUMBER(10,0),  
	"STATION" VARCHAR2(255 CHAR),  
	"TERRITORY_CSV" VARCHAR2(4000),  
	"OVR_START_DT" DATE,  
	"OVR_END_DT" DATE,  
	"RPM_LICENSE_START_DATE" DATE,  
	"RPM_LICENSE_END_DATE" DATE,  
	"RPM_REQUEST_ID" VARCHAR2(10),  
	"SOURCE_TYPE" VARCHAR2(255 CHAR),  
	"LEAD_TIME" NUMBER,  
	"LKP_CUST_TYPE" NUMBER(10,0),  
	"LKP_DIST_TYPE_ID" NUMBER(10,0),  
	"PROG_ID" NUMBER(10,0),  
	"IS_DELETED" NUMBER(1,0) DEFAULT 0,  
	"IS_OVERRIDDEN" NUMBER(1,0) DEFAULT 0,  
	"PROG_SEAS_ID" NUMBER,  
	"TERRITORY_ID" NUMBER(10,0),  
	"LANGUAGE_ID" NUMBER(10,0),  
	"CREATED_BY" VARCHAR2(255) NOT NULL ENABLE,  
	"CREATED_DT" TIMESTAMP (6) NOT NULL ENABLE,  
	"LAST_UPDATED_BY" VARCHAR2(255) NOT NULL ENABLE,  
	"LAST_UPDATED_DT" TIMESTAMP (6) NOT NULL ENABLE,  
	"VERSION" NUMBER(10,0),  
	"CONTRACT_STATUS" VARCHAR2(255),  
	"STATUS_TYPE" VARCHAR2(255),  
	"STATION_ID" NUMBER(10,0),  
	"CUSTOMER_ID" NUMBER(10,0),  
	"PROG_SEAS_NUM" VARCHAR2(255),  
	"RPM_STITCHED_ID" NUMBER(20,0),  
	"LICENSE_TYPE_CSV" VARCHAR2(1000),  
	"SYS_SYNCED_DT" TIMESTAMP (6),  
	"GPMS_ID" NUMBER(10,0),  
	"SEAS_GPMS_ID" NUMBER(10,0),  
	"PROG_TYPE" VARCHAR2(20),  
	"PROG_NAME" VARCHAR2(200),  
	"GPMS_PROG_ID" NUMBER(19,0),  
	"GPMS_SEAS_ID" NUMBER(10,0),  
	 PRIMARY KEY ("ACCESS_ID") 
  USING INDEX PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SPT_DATA1"  ENABLE, 
	 CONSTRAINT "FK_PROG_INTL_ID" FOREIGN KEY ("PROG_ID") 
	  REFERENCES "DTV_B2B2"."PROGRAM_BACKUP" ("PROG_ID") DISABLE 
   ) SEGMENT CREATION IMMEDIATE 
  PCTFREE 10 PCTUSED 40 INITRANS 1 MAXTRANS 255 
 NOCOMPRESS LOGGING
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SPT_DATA1" ;


  CREATE TABLE "DART_B2B2"."RDPH_TEMP" 
   (	"RPM_REQUEST_ID" NUMBER(10,0),  
	"CONTRACT_STATUS_LKP_ID" NUMBER(10,0),  
	 PRIMARY KEY ("RPM_REQUEST_ID", "CONTRACT_STATUS_LKP_ID") 
  USING INDEX PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SPT_DATA1"  ENABLE
   ) SEGMENT CREATION IMMEDIATE 
  PCTFREE 10 PCTUSED 40 INITRANS 1 MAXTRANS 255 
 NOCOMPRESS LOGGING
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SPT_DATA1" ;


  CREATE TABLE "DART_B2B2"."RDPSTATION_14_AUG_2019" 
   (	"RPM_REQUEST_ID" NUMBER(19,0),  
	"B2B_STATION_ID" NUMBER(10,0) 
   ) SEGMENT CREATION IMMEDIATE 
  PCTFREE 10 PCTUSED 40 INITRANS 1 MAXTRANS 255 
 NOCOMPRESS LOGGING
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SPT_DATA1" ;


  CREATE TABLE "DART_B2B2"."RDPSTATION_JUNE28_2019" 
   (	"RPM_REQUEST_ID" NUMBER(19,0),  
	"B2B_STATION_ID" NUMBER(10,0) 
   ) SEGMENT CREATION IMMEDIATE 
  PCTFREE 10 PCTUSED 40 INITRANS 1 MAXTRANS 255 
 NOCOMPRESS LOGGING
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SPT_DATA1" ;


  CREATE TABLE "DART_B2B2"."RDPSTITCHED_14_AUG_2019" 
   (	"RPM_STITCHED_ID" NUMBER(19,0) NOT NULL ENABLE,  
	"RPM_STATION_ID" NUMBER(10,0) NOT NULL ENABLE,  
	"STATION_ID" NUMBER(10,0) NOT NULL ENABLE,  
	"STATION_NAME" VARCHAR2(255 CHAR),  
	"GPMS_PROG_ID" NUMBER(19,0) NOT NULL ENABLE,  
	"GPMS_SEAS_ID" NUMBER(19,0) NOT NULL ENABLE,  
	"PROG_ID" NUMBER(10,0) NOT NULL ENABLE,  
	"SEAS_ID" NUMBER(10,0) NOT NULL ENABLE,  
	"PROG_NAME" VARCHAR2(255 CHAR),  
	"SEASON_NUM" VARCHAR2(255 CHAR),  
	"TERRITORY_VALUE_CSV" VARCHAR2(4000 CHAR),  
	"TERRITORY_ID_CSV" VARCHAR2(4000 CHAR),  
	"CONTRACT_STATUS_VALUE_CSV" VARCHAR2(4000 CHAR),  
	"CONTRACT_STATUS_TYPE_CSV" VARCHAR2(4000 CHAR),  
	"LICENSE_TYPE_ID_CSV" VARCHAR2(4000 CHAR),  
	"LICENSE_TYPE_VALUE_CSV" VARCHAR2(4000 CHAR),  
	"EXHIBITION_END_DT" TIMESTAMP (6),  
	"EXHIBITION_ST_DT" TIMESTAMP (6),  
	"DELIVERY_LEAD_DAYS" NUMBER(9,0) NOT NULL ENABLE,  
	"SOURCE_SYSTEM" VARCHAR2(255 CHAR),  
	"DELIVER_BY_DT" TIMESTAMP (6),  
	"CREATED_DT" TIMESTAMP (6),  
	"CREATED_BY" VARCHAR2(255 CHAR),  
	"LAST_UPDATED_DT" TIMESTAMP (6),  
	"LAST_UPDATED_BY" VARCHAR2(255 CHAR),  
	"CREDIT_LOCKOUT" NUMBER(1,0),  
	"SALES_PERSON" VARCHAR2(255 CHAR) 
   ) SEGMENT CREATION IMMEDIATE 
  PCTFREE 10 PCTUSED 40 INITRANS 1 MAXTRANS 255 
 NOCOMPRESS LOGGING
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SPT_DATA1" ;


  CREATE TABLE "DART_B2B2"."RDPS_JUNE28_2019" 
   (	"RPM_STITCHED_ID" NUMBER(19,0) NOT NULL ENABLE,  
	"RPM_STATION_ID" NUMBER(10,0) NOT NULL ENABLE,  
	"STATION_ID" NUMBER(10,0) NOT NULL ENABLE,  
	"STATION_NAME" VARCHAR2(255 CHAR),  
	"GPMS_PROG_ID" NUMBER(19,0) NOT NULL ENABLE,  
	"GPMS_SEAS_ID" NUMBER(19,0) NOT NULL ENABLE,  
	"PROG_ID" NUMBER(10,0) NOT NULL ENABLE,  
	"SEAS_ID" NUMBER(10,0) NOT NULL ENABLE,  
	"PROG_NAME" VARCHAR2(255 CHAR),  
	"SEASON_NUM" VARCHAR2(255 CHAR),  
	"TERRITORY_VALUE_CSV" VARCHAR2(4000 CHAR),  
	"TERRITORY_ID_CSV" VARCHAR2(4000 CHAR),  
	"CONTRACT_STATUS_VALUE_CSV" VARCHAR2(4000 CHAR),  
	"CONTRACT_STATUS_TYPE_CSV" VARCHAR2(4000 CHAR),  
	"LICENSE_TYPE_ID_CSV" VARCHAR2(4000 CHAR),  
	"LICENSE_TYPE_VALUE_CSV" VARCHAR2(4000 CHAR),  
	"EXHIBITION_END_DT" TIMESTAMP (6),  
	"EXHIBITION_ST_DT" TIMESTAMP (6),  
	"DELIVERY_LEAD_DAYS" NUMBER(9,0) NOT NULL ENABLE,  
	"SOURCE_SYSTEM" VARCHAR2(255 CHAR),  
	"DELIVER_BY_DT" TIMESTAMP (6),  
	"CREATED_DT" TIMESTAMP (6),  
	"CREATED_BY" VARCHAR2(255 CHAR),  
	"LAST_UPDATED_DT" TIMESTAMP (6),  
	"LAST_UPDATED_BY" VARCHAR2(255 CHAR),  
	"CREDIT_LOCKOUT" NUMBER(1,0),  
	"SALES_PERSON" VARCHAR2(255 CHAR) 
   ) SEGMENT CREATION IMMEDIATE 
  PCTFREE 10 PCTUSED 40 INITRANS 1 MAXTRANS 255 
 NOCOMPRESS LOGGING
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SPT_DATA1" ;


  CREATE TABLE "DART_B2B2"."RDPS_MIGRATIONDATA_FINAL" 
   (	"RPM_STITCHED_ID" NUMBER(19,0) NOT NULL ENABLE,  
	"RPM_STATION_ID" NUMBER(10,0) NOT NULL ENABLE,  
	"STATION_ID" NUMBER(10,0) NOT NULL ENABLE,  
	"STATION_NAME" VARCHAR2(255 CHAR),  
	"GPMS_PROG_ID" NUMBER(19,0) NOT NULL ENABLE,  
	"GPMS_SEAS_ID" NUMBER(19,0) NOT NULL ENABLE,  
	"PROG_ID" NUMBER(10,0) NOT NULL ENABLE,  
	"SEAS_ID" NUMBER(10,0) NOT NULL ENABLE,  
	"PROG_NAME" VARCHAR2(255 CHAR),  
	"SEASON_NUM" VARCHAR2(255 CHAR),  
	"TERRITORY_VALUE_CSV" VARCHAR2(4000 CHAR),  
	"TERRITORY_ID_CSV" VARCHAR2(4000 CHAR),  
	"CONTRACT_STATUS_VALUE_CSV" VARCHAR2(4000 CHAR),  
	"CONTRACT_STATUS_TYPE_CSV" VARCHAR2(4000 CHAR),  
	"LICENSE_TYPE_ID_CSV" VARCHAR2(4000 CHAR),  
	"LICENSE_TYPE_VALUE_CSV" VARCHAR2(4000 CHAR),  
	"EXHIBITION_END_DT" TIMESTAMP (6),  
	"EXHIBITION_ST_DT" TIMESTAMP (6),  
	"DELIVERY_LEAD_DAYS" NUMBER(9,0) NOT NULL ENABLE,  
	"SOURCE_SYSTEM" VARCHAR2(255 CHAR),  
	"DELIVER_BY_DT" TIMESTAMP (6),  
	"CREATED_DT" TIMESTAMP (6),  
	"CREATED_BY" VARCHAR2(255 CHAR),  
	"LAST_UPDATED_DT" TIMESTAMP (6),  
	"LAST_UPDATED_BY" VARCHAR2(255 CHAR),  
	"CREDIT_LOCKOUT" NUMBER(1,0),  
	"SALES_PERSON" VARCHAR2(255 CHAR) 
   ) SEGMENT CREATION IMMEDIATE 
  PCTFREE 10 PCTUSED 40 INITRANS 1 MAXTRANS 255 
 NOCOMPRESS LOGGING
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SPT_DATA1" ;


  CREATE TABLE "DART_B2B2"."RDP_TCL" 
   (	"GPMS_PROG_ID" NUMBER(19,0),  
	"GPMS_SEAS_ID" NUMBER(19,0),  
	"B2B_STATION_ID" NUMBER(19,0),  
	"TERRITORY_VALUE_CSV" VARCHAR2(4000),  
	"TERRITORY_ID_CSV" VARCHAR2(4000),  
	"CONTRACT_STATUS_VALUE_CSV" VARCHAR2(4000),  
	"CONTRACT_STATUS_TYPE_CSV" VARCHAR2(4000),  
	"LICENSE_TYPE_ID_CSV" VARCHAR2(4000),  
	"LICENSE_TYPE_VALUE_CSV" VARCHAR2(4000),  
	"CREATED_DT" TIMESTAMP (6),  
	 PRIMARY KEY ("GPMS_PROG_ID", "GPMS_SEAS_ID", "B2B_STATION_ID") 
  USING INDEX PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SPT_DATA1"  ENABLE
   ) SEGMENT CREATION IMMEDIATE 
  PCTFREE 10 PCTUSED 40 INITRANS 1 MAXTRANS 255 
 NOCOMPRESS LOGGING
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SPT_DATA1" ;


  CREATE TABLE "DART_B2B2"."RMAL_JUNE28_2019" 
   (	"ACCESS_ID" NUMBER(10,0),  
	"STATION" VARCHAR2(255 CHAR),  
	"TERRITORY_CSV" VARCHAR2(4000),  
	"OVR_START_DT" DATE,  
	"OVR_END_DT" DATE,  
	"RPM_LICENSE_START_DATE" DATE,  
	"RPM_LICENSE_END_DATE" DATE,  
	"RPM_REQUEST_ID" VARCHAR2(10),  
	"SOURCE_TYPE" VARCHAR2(255 CHAR),  
	"LEAD_TIME" NUMBER,  
	"LKP_CUST_TYPE" NUMBER(10,0),  
	"LKP_DIST_TYPE_ID" NUMBER(10,0),  
	"PROG_ID" NUMBER(10,0),  
	"IS_DELETED" NUMBER(1,0),  
	"IS_OVERRIDDEN" NUMBER(1,0),  
	"PROG_SEAS_ID" NUMBER,  
	"TERRITORY_ID" NUMBER(10,0),  
	"LANGUAGE_ID" NUMBER(10,0),  
	"CREATED_BY" VARCHAR2(255) NOT NULL ENABLE,  
	"CREATED_DT" TIMESTAMP (6) NOT NULL ENABLE,  
	"LAST_UPDATED_BY" VARCHAR2(255) NOT NULL ENABLE,  
	"LAST_UPDATED_DT" TIMESTAMP (6) NOT NULL ENABLE,  
	"VERSION" NUMBER(10,0),  
	"CONTRACT_STATUS" VARCHAR2(255),  
	"STATUS_TYPE" VARCHAR2(255),  
	"STATION_ID" NUMBER(10,0),  
	"CUSTOMER_ID" NUMBER(10,0),  
	"PROG_SEAS_NUM" VARCHAR2(20),  
	"RPM_STITCHED_ID" NUMBER(20,0),  
	"LICENSE_TYPE_CSV" VARCHAR2(1000),  
	"SYS_SYNCED_DT" TIMESTAMP (6) 
   ) SEGMENT CREATION IMMEDIATE 
  PCTFREE 10 PCTUSED 40 INITRANS 1 MAXTRANS 255 
 NOCOMPRESS LOGGING
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SPT_DATA1" ;


  CREATE TABLE "DART_B2B2"."RPM_AUDIT_EMAIL" 
   (	"AUDIT_ID" NUMBER(19,0) NOT NULL ENABLE,  
	"OLD_STATION_NAME" VARCHAR2(255 CHAR),  
	"NEW_STATION_NAME" VARCHAR2(255 CHAR),  
	"OLD_CUSTOMER_NAME" VARCHAR2(255 CHAR),  
	"NEW_CUSTOMER_NAME" VARCHAR2(255 CHAR),  
	"RPM_REQUEST_ID" NUMBER(19,0) NOT NULL ENABLE,  
	"CREATED_DT" TIMESTAMP (6),  
	"EMAIL_TYPE" NUMBER(10,0),  
	"STATION_ID" VARCHAR2(255),  
	"NEW_CUSTOMER_ID" NUMBER(19,0),  
	"OLD_CUSTOMER_ID" NUMBER(19,0),  
	"SALES_PERSON_NAME" VARCHAR2(255),  
	"PROCESSING_ERROR" CLOB,  
	"PACKAGE_ID" NUMBER(10,0),  
	"PACKAGE_NAME" VARCHAR2(255),  
	"IS_SYNDICATION" NUMBER(1,0) DEFAULT 0,  
	 PRIMARY KEY ("AUDIT_ID") 
  USING INDEX PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SPT_DATA1"  ENABLE
   ) SEGMENT CREATION IMMEDIATE 
  PCTFREE 10 PCTUSED 40 INITRANS 1 MAXTRANS 255 
 NOCOMPRESS LOGGING
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SPT_DATA1" 
 LOB ("PROCESSING_ERROR") STORE AS BASICFILE (
  TABLESPACE "SPT_DATA1" ENABLE STORAGE IN ROW CHUNK 8192 RETENTION 
  NOCACHE LOGGING 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) ;


  CREATE TABLE "DART_B2B2"."RPM_DEAL_ID" 
   (	"DEAL_ID" NUMBER(10,0) 
   ) SEGMENT CREATION IMMEDIATE 
  PCTFREE 10 PCTUSED 40 INITRANS 1 MAXTRANS 255 
 NOCOMPRESS LOGGING
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SPT_DATA1" ;


  CREATE TABLE "DART_B2B2"."RPM_DEAL_PRODUCT" 
   (	"ACTION_LKP_ID" NUMBER(19,0),  
	"COMMENTS" VARCHAR2(4000 CHAR),  
	"CONTRACT_NO" VARCHAR2(255 CHAR),  
	"CONTRACT_STATUS_LKP_ID" NUMBER(19,0),  
	"CUSTOMER_NAME" VARCHAR2(255 CHAR),  
	"DEAL_PRODUCT_ID" VARCHAR2(255 CHAR),  
	"DELIVER_BY_DT" TIMESTAMP (6),  
	"DELIVERY_LEAD_DAYS" VARCHAR2(255 CHAR),  
	"EIDR_ID" VARCHAR2(255 CHAR),  
	"EXHIBITION_END_DT" TIMESTAMP (6),  
	"EXHIBITION_ST_DT" TIMESTAMP (6),  
	"GPMS_PRODUCT_ID" NUMBER(19,0) NOT NULL ENABLE,  
	"MPM_NO" VARCHAR2(255 CHAR),  
	"ORDER_DESC" VARCHAR2(255 CHAR),  
	"ORDER_NO" VARCHAR2(255 CHAR),  
	"PRIMARY_LANGUAGE_LKP_ID" VARCHAR2(255 CHAR),  
	"PRIMARY_MEDIA_LKP_ID" VARCHAR2(255 CHAR),  
	"PRIMARY_TERRITORY_LKP_ID" VARCHAR2(255 CHAR),  
	"RPM_REQUEST_ID" NUMBER(19,0) NOT NULL ENABLE,  
	"SALES_PERSON" VARCHAR2(255 CHAR),  
	"SOURCE_SYSTEM" VARCHAR2(255 CHAR),  
	"STATION_NAME" VARCHAR2(4000),  
	"SUB_DUB_LKP_ID" NUMBER(19,0),  
	"TERM_YEAR_DESC" VARCHAR2(255 CHAR),  
	"TERM_YEAR_NO" VARCHAR2(255 CHAR),  
	"TERM_YEAR_STATUS" VARCHAR2(255 CHAR),  
	"TITLE_STATUS" VARCHAR2(255 CHAR),  
	"CREATED_DT" TIMESTAMP (6),  
	"LAST_UPDATED_DT" TIMESTAMP (6),  
	"CREATED_BY" VARCHAR2(255 CHAR),  
	"LAST_UPDATED_BY" VARCHAR2(255 CHAR),  
	"PROG_ID" NUMBER(10,0) DEFAULT 0 NOT NULL ENABLE,  
	"SEAS_ID" NUMBER(10,0) DEFAULT 0 NOT NULL ENABLE,  
	"EPS_ID" NUMBER(10,0) DEFAULT 0 NOT NULL ENABLE,  
	"SEASON_NUM" VARCHAR2(255 CHAR),  
	"RPM_STATION_ID" VARCHAR2(255) DEFAULT 0,  
	"CUSTOMER_NO" NUMBER(19,0) DEFAULT 0,  
	"GPMS_PROG_ID" NUMBER(19,0) DEFAULT (0) NOT NULL ENABLE,  
	"GPMS_SEAS_ID" NUMBER(19,0) DEFAULT (0) NOT NULL ENABLE,  
	"AGREEMENT_ID" VARCHAR2(20),  
	"PROG_NAME" VARCHAR2(400),  
	"PROG_TYPE" VARCHAR2(400),  
	"GPMS_EPS_ID" NUMBER(19,0) 
   ) SEGMENT CREATION IMMEDIATE 
  PCTFREE 10 PCTUSED 40 INITRANS 1 MAXTRANS 255 
 NOCOMPRESS LOGGING
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SPT_DATA1" ;


  CREATE TABLE "DART_B2B2"."RPM_DEAL_PRODUCT_HISTORICAL" 
   (	"ACTION_LKP_ID" NUMBER(19,0),  
	"COMMENTS" VARCHAR2(4000 CHAR),  
	"CONTRACT_NO" VARCHAR2(255 CHAR),  
	"CONTRACT_STATUS_LKP_ID" NUMBER(19,0),  
	"CUSTOMER_NAME" VARCHAR2(255 CHAR),  
	"DEAL_PRODUCT_ID" VARCHAR2(255 CHAR),  
	"DELIVER_BY_DT" TIMESTAMP (6),  
	"DELIVERY_LEAD_DAYS" VARCHAR2(255 CHAR),  
	"EIDR_ID" VARCHAR2(255 CHAR),  
	"EXHIBITION_END_DT" TIMESTAMP (6),  
	"EXHIBITION_ST_DT" TIMESTAMP (6),  
	"GPMS_PRODUCT_ID" NUMBER(19,0) NOT NULL ENABLE,  
	"MPM_NO" VARCHAR2(255 CHAR),  
	"ORDER_DESC" VARCHAR2(255 CHAR),  
	"ORDER_NO" VARCHAR2(255 CHAR),  
	"PRIMARY_LANGUAGE_LKP_ID" VARCHAR2(255 CHAR),  
	"PRIMARY_MEDIA_LKP_ID" VARCHAR2(255 CHAR),  
	"PRIMARY_TERRITORY_LKP_ID" VARCHAR2(255 CHAR),  
	"RPM_REQUEST_ID" NUMBER(19,0) NOT NULL ENABLE,  
	"SALES_PERSON" VARCHAR2(255 CHAR),  
	"SOURCE_SYSTEM" VARCHAR2(255 CHAR),  
	"STATION_NAME" VARCHAR2(4000),  
	"SUB_DUB_LKP_ID" NUMBER(19,0),  
	"TERM_YEAR_DESC" VARCHAR2(255 CHAR),  
	"TERM_YEAR_NO" VARCHAR2(255 CHAR),  
	"TERM_YEAR_STATUS" VARCHAR2(255 CHAR),  
	"TITLE_STATUS" VARCHAR2(255 CHAR),  
	"CREATED_DT" TIMESTAMP (6),  
	"LAST_UPDATED_DT" TIMESTAMP (6),  
	"CREATED_BY" VARCHAR2(255 CHAR),  
	"LAST_UPDATED_BY" VARCHAR2(255 CHAR),  
	"PROG_ID" NUMBER(10,0) DEFAULT 0 NOT NULL ENABLE,  
	"SEAS_ID" NUMBER(10,0) DEFAULT 0 NOT NULL ENABLE,  
	"EPS_ID" NUMBER(10,0) DEFAULT 0 NOT NULL ENABLE,  
	"SEASON_NUM" VARCHAR2(255 CHAR),  
	"RPM_STATION_ID" VARCHAR2(255) DEFAULT 0,  
	"CUSTOMER_NO" NUMBER(19,0) DEFAULT 0,  
	"GPMS_PROG_ID" NUMBER(19,0) DEFAULT (0) NOT NULL ENABLE,  
	"GPMS_SEAS_ID" NUMBER(19,0) DEFAULT (0) NOT NULL ENABLE,  
	"ID" NUMBER(10,0),  
	"IS_PROCESSED" NUMBER(1,0) DEFAULT 0,  
	"IS_INITIAL_DATA" NUMBER(1,0) DEFAULT 0 NOT NULL ENABLE 
   ) SEGMENT CREATION IMMEDIATE 
  PCTFREE 10 PCTUSED 40 INITRANS 1 MAXTRANS 255 
 NOCOMPRESS LOGGING
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SPT_DATA1" ;


  CREATE TABLE "DART_B2B2"."RPM_DEAL_PRODUCT_HIST_INVALID" 
   (	"ACTION_LKP_ID" NUMBER(19,0),  
	"COMMENTS" VARCHAR2(4000 CHAR),  
	"CONTRACT_NO" VARCHAR2(255 CHAR),  
	"CONTRACT_STATUS_LKP_ID" NUMBER(19,0),  
	"CUSTOMER_NAME" VARCHAR2(255 CHAR),  
	"DEAL_PRODUCT_ID" VARCHAR2(255 CHAR),  
	"DELIVER_BY_DT" TIMESTAMP (6),  
	"DELIVERY_LEAD_DAYS" VARCHAR2(255 CHAR),  
	"EIDR_ID" VARCHAR2(255 CHAR),  
	"EXHIBITION_END_DT" TIMESTAMP (6),  
	"EXHIBITION_ST_DT" TIMESTAMP (6),  
	"GPMS_PRODUCT_ID" NUMBER(19,0) NOT NULL ENABLE,  
	"MPM_NO" VARCHAR2(255 CHAR),  
	"ORDER_DESC" VARCHAR2(255 CHAR),  
	"ORDER_NO" VARCHAR2(255 CHAR),  
	"PRIMARY_LANGUAGE_LKP_ID" VARCHAR2(255 CHAR),  
	"PRIMARY_MEDIA_LKP_ID" VARCHAR2(255 CHAR),  
	"PRIMARY_TERRITORY_LKP_ID" VARCHAR2(255 CHAR),  
	"RPM_REQUEST_ID" NUMBER(19,0) NOT NULL ENABLE,  
	"SALES_PERSON" VARCHAR2(255 CHAR),  
	"SOURCE_SYSTEM" VARCHAR2(255 CHAR),  
	"STATION_NAME" VARCHAR2(4000),  
	"SUB_DUB_LKP_ID" NUMBER(19,0),  
	"TERM_YEAR_DESC" VARCHAR2(255 CHAR),  
	"TERM_YEAR_NO" VARCHAR2(255 CHAR),  
	"TERM_YEAR_STATUS" VARCHAR2(255 CHAR),  
	"TITLE_STATUS" VARCHAR2(255 CHAR),  
	"CREATED_DT" TIMESTAMP (6),  
	"LAST_UPDATED_DT" TIMESTAMP (6),  
	"CREATED_BY" VARCHAR2(255 CHAR),  
	"LAST_UPDATED_BY" VARCHAR2(255 CHAR),  
	"PROG_ID" NUMBER(10,0) NOT NULL ENABLE,  
	"SEAS_ID" NUMBER(10,0) NOT NULL ENABLE,  
	"EPS_ID" NUMBER(10,0) NOT NULL ENABLE,  
	"SEASON_NUM" VARCHAR2(255 CHAR),  
	"RPM_STATION_ID" VARCHAR2(255),  
	"CUSTOMER_NO" NUMBER(19,0),  
	"GPMS_PROG_ID" NUMBER(19,0) NOT NULL ENABLE,  
	"GPMS_SEAS_ID" NUMBER(19,0) NOT NULL ENABLE,  
	"ID" NUMBER(10,0),  
	"IS_PROCESSED" NUMBER(1,0),  
	"IS_INITIAL_DATA" NUMBER(1,0) NOT NULL ENABLE 
   ) SEGMENT CREATION IMMEDIATE 
  PCTFREE 10 PCTUSED 40 INITRANS 1 MAXTRANS 255 
 NOCOMPRESS LOGGING
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SPT_DATA1" ;


  CREATE TABLE "DART_B2B2"."RPM_DEAL_PRODUCT_STATION" 
   (	"RPM_REQUEST_ID" NUMBER(19,0),  
	"B2B_STATION_ID" NUMBER(10,0) 
   ) SEGMENT CREATION IMMEDIATE 
  PCTFREE 10 PCTUSED 40 INITRANS 1 MAXTRANS 255 
 NOCOMPRESS LOGGING
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SPT_DATA1" ;


  CREATE TABLE "DART_B2B2"."RPM_DEAL_PRODUCT_STATION_HIST" 
   (	"RPM_REQUEST_ID" NUMBER(19,0),  
	"B2B_STATION_ID" NUMBER(10,0) 
   ) SEGMENT CREATION IMMEDIATE 
  PCTFREE 10 PCTUSED 40 INITRANS 1 MAXTRANS 255 
 NOCOMPRESS LOGGING
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SPT_DATA1" ;


  CREATE TABLE "DART_B2B2"."RPM_DEAL_PRODUCT_STATION_SYND" 
   (	"RPM_REQUEST_ID" NUMBER(19,0),  
	"B2B_STATION_ID" NUMBER(10,0) 
   ) SEGMENT CREATION IMMEDIATE 
  PCTFREE 10 PCTUSED 40 INITRANS 1 MAXTRANS 255 
 NOCOMPRESS LOGGING
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SPT_DATA1" ;


  CREATE TABLE "DART_B2B2"."RPM_DEAL_PRODUCT_STATION_SYND_1" 
   (	"RPM_REQUEST_ID" NUMBER(19,0),  
	"B2B_STATION_ID" NUMBER(10,0) 
   ) SEGMENT CREATION IMMEDIATE 
  PCTFREE 10 PCTUSED 40 INITRANS 1 MAXTRANS 255 
 NOCOMPRESS LOGGING
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SPT_DATA1" ;


  CREATE TABLE "DART_B2B2"."RPM_DEAL_PRODUCT_STG" 
   (	"STG_ID" NUMBER(19,0) NOT NULL ENABLE,  
	"ACTION_LKP_ID" NUMBER(19,0),  
	"COMMENTS" VARCHAR2(255 CHAR),  
	"CONTRACT_NO" VARCHAR2(255 CHAR),  
	"CONTRACT_STATUS_LKP_ID" NUMBER(19,0),  
	"CUSTOMER_NAME" VARCHAR2(255 CHAR),  
	"DEAL_PRODUCT_ID" VARCHAR2(255 CHAR),  
	"DELIVER_BY_DT" TIMESTAMP (6),  
	"DELIVERY_LEAD_DAYS" VARCHAR2(255 CHAR),  
	"EIDR_ID" VARCHAR2(255 CHAR),  
	"EXHIBITION_END_DT" TIMESTAMP (6),  
	"EXHIBITION_ST_DT" TIMESTAMP (6),  
	"GPMS_PRODUCT_ID" NUMBER(19,0) NOT NULL ENABLE,  
	"MPM_NO" VARCHAR2(255 CHAR),  
	"ORDER_DESC" VARCHAR2(255 CHAR),  
	"ORDER_NO" VARCHAR2(255 CHAR),  
	"PRIMARY_LANGUAGE_LKP_ID" VARCHAR2(255 CHAR),  
	"PRIMARY_MEDIA_LKP_ID" VARCHAR2(255 CHAR),  
	"PRIMARY_TERRITORY_LKP_ID" VARCHAR2(255 CHAR),  
	"RPM_REQUEST_ID" NUMBER(19,0) NOT NULL ENABLE,  
	"SALES_PERSON" VARCHAR2(255 CHAR),  
	"SOURCE_SYSTEM" VARCHAR2(255 CHAR),  
	"STATION_NAME" VARCHAR2(255 CHAR),  
	"SUB_DUB_LKP_ID" NUMBER(19,0),  
	"TERM_YEAR_DESC" VARCHAR2(255 CHAR),  
	"TERM_YEAR_NO" VARCHAR2(255 CHAR),  
	"TERM_YEAR_STATUS" VARCHAR2(255 CHAR),  
	"TITLE_STATUS" VARCHAR2(255 CHAR),  
	"CREATED_DT" TIMESTAMP (6),  
	"LAST_UPDATED_DT" TIMESTAMP (6),  
	"CREATED_BY" VARCHAR2(255 CHAR),  
	"LAST_UPDATED_BY" VARCHAR2(255 CHAR),  
	"RPM_STATION_ID" VARCHAR2(255) DEFAULT 0,  
	"CUSTOMER_NO" NUMBER(19,0) DEFAULT 0,  
	"IS_DELETED" NUMBER(1,0) DEFAULT 0,  
	"AGREEMENT_ID" VARCHAR2(20),  
	 PRIMARY KEY ("STG_ID") 
  USING INDEX PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SPT_DATA1"  ENABLE
   ) SEGMENT CREATION IMMEDIATE 
  PCTFREE 10 PCTUSED 40 INITRANS 1 MAXTRANS 255 
 NOCOMPRESS LOGGING
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SPT_DATA1" ;


  CREATE TABLE "DART_B2B2"."RPM_DEAL_PRODUCT_STITCHED" 
   (	"RPM_STITCHED_ID" NUMBER(19,0) NOT NULL ENABLE,  
	"RPM_STATION_ID" NUMBER(10,0) NOT NULL ENABLE,  
	"STATION_ID" NUMBER(10,0) DEFAULT (0) NOT NULL ENABLE,  
	"STATION_NAME" VARCHAR2(255 CHAR),  
	"GPMS_PROG_ID" NUMBER(19,0) NOT NULL ENABLE,  
	"GPMS_SEAS_ID" NUMBER(19,0) DEFAULT (0) NOT NULL ENABLE,  
	"PROG_ID" NUMBER(10,0) DEFAULT (0) NOT NULL ENABLE,  
	"SEAS_ID" NUMBER(10,0) DEFAULT (0) NOT NULL ENABLE,  
	"PROG_NAME" VARCHAR2(255 CHAR),  
	"SEASON_NUM" VARCHAR2(255 CHAR),  
	"TERRITORY_VALUE_CSV" VARCHAR2(4000 CHAR),  
	"TERRITORY_ID_CSV" VARCHAR2(4000 CHAR),  
	"CONTRACT_STATUS_VALUE_CSV" VARCHAR2(4000 CHAR),  
	"CONTRACT_STATUS_TYPE_CSV" VARCHAR2(4000 CHAR),  
	"LICENSE_TYPE_ID_CSV" VARCHAR2(4000 CHAR),  
	"LICENSE_TYPE_VALUE_CSV" VARCHAR2(4000 CHAR),  
	"EXHIBITION_END_DT" TIMESTAMP (6),  
	"EXHIBITION_ST_DT" TIMESTAMP (6),  
	"DELIVERY_LEAD_DAYS" NUMBER(9,0) DEFAULT (0) NOT NULL ENABLE,  
	"SOURCE_SYSTEM" VARCHAR2(255 CHAR) DEFAULT 'RPM',  
	"DELIVER_BY_DT" TIMESTAMP (6),  
	"CREATED_DT" TIMESTAMP (6),  
	"CREATED_BY" VARCHAR2(255 CHAR),  
	"LAST_UPDATED_DT" TIMESTAMP (6),  
	"LAST_UPDATED_BY" VARCHAR2(255 CHAR),  
	"CREDIT_LOCKOUT" NUMBER(1,0),  
	"SALES_PERSON" VARCHAR2(255 CHAR),  
	"PROG_TYPE" VARCHAR2(255),  
	 PRIMARY KEY ("RPM_STITCHED_ID") 
  USING INDEX PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SPT_DATA1"  ENABLE
   ) SEGMENT CREATION IMMEDIATE 
  PCTFREE 10 PCTUSED 40 INITRANS 1 MAXTRANS 255 
 NOCOMPRESS LOGGING
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SPT_DATA1" ;


  CREATE TABLE "DART_B2B2"."RPM_DEAL_PRODUCT_STITCHED1" 
   (	"RPM_STITCHED_ID" NUMBER(19,0) NOT NULL ENABLE,  
	"RPM_STATION_ID" NUMBER(10,0) NOT NULL ENABLE,  
	"STATION_ID" NUMBER(10,0) NOT NULL ENABLE,  
	"STATION_NAME" VARCHAR2(255 CHAR),  
	"GPMS_PROG_ID" NUMBER(19,0) NOT NULL ENABLE,  
	"GPMS_SEAS_ID" NUMBER(19,0) NOT NULL ENABLE,  
	"PROG_ID" NUMBER(10,0) NOT NULL ENABLE,  
	"SEAS_ID" NUMBER(10,0) NOT NULL ENABLE,  
	"PROG_NAME" VARCHAR2(255 CHAR),  
	"SEASON_NUM" VARCHAR2(255 CHAR),  
	"TERRITORY_VALUE_CSV" VARCHAR2(4000 CHAR),  
	"TERRITORY_ID_CSV" VARCHAR2(4000 CHAR),  
	"CONTRACT_STATUS_VALUE_CSV" VARCHAR2(4000 CHAR),  
	"CONTRACT_STATUS_TYPE_CSV" VARCHAR2(4000 CHAR),  
	"LICENSE_TYPE_ID_CSV" VARCHAR2(4000 CHAR),  
	"LICENSE_TYPE_VALUE_CSV" VARCHAR2(4000 CHAR),  
	"EXHIBITION_END_DT" TIMESTAMP (6),  
	"EXHIBITION_ST_DT" TIMESTAMP (6),  
	"DELIVERY_LEAD_DAYS" NUMBER(9,0) NOT NULL ENABLE,  
	"SOURCE_SYSTEM" VARCHAR2(255 CHAR),  
	"DELIVER_BY_DT" TIMESTAMP (6),  
	"CREATED_DT" TIMESTAMP (6),  
	"CREATED_BY" VARCHAR2(255 CHAR),  
	"LAST_UPDATED_DT" TIMESTAMP (6),  
	"LAST_UPDATED_BY" VARCHAR2(255 CHAR),  
	"CREDIT_LOCKOUT" NUMBER(1,0),  
	"SALES_PERSON" VARCHAR2(255 CHAR),  
	"PROG_TYPE" VARCHAR2(255) 
   ) SEGMENT CREATION IMMEDIATE 
  PCTFREE 10 PCTUSED 40 INITRANS 1 MAXTRANS 255 
 NOCOMPRESS LOGGING
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SPT_DATA1" ;


  CREATE TABLE "DART_B2B2"."RPM_DEAL_PRODUCT_STITCHED_BKP_DEC22_2020" 
   (	"RPM_STITCHED_ID" NUMBER(19,0) NOT NULL ENABLE,  
	"RPM_STATION_ID" NUMBER(10,0) NOT NULL ENABLE,  
	"STATION_ID" NUMBER(10,0) NOT NULL ENABLE,  
	"STATION_NAME" VARCHAR2(255 CHAR),  
	"GPMS_PROG_ID" NUMBER(19,0) NOT NULL ENABLE,  
	"GPMS_SEAS_ID" NUMBER(19,0) NOT NULL ENABLE,  
	"PROG_ID" NUMBER(10,0) NOT NULL ENABLE,  
	"SEAS_ID" NUMBER(10,0) NOT NULL ENABLE,  
	"PROG_NAME" VARCHAR2(255 CHAR),  
	"SEASON_NUM" VARCHAR2(255 CHAR),  
	"TERRITORY_VALUE_CSV" VARCHAR2(4000 CHAR),  
	"TERRITORY_ID_CSV" VARCHAR2(4000 CHAR),  
	"CONTRACT_STATUS_VALUE_CSV" VARCHAR2(4000 CHAR),  
	"CONTRACT_STATUS_TYPE_CSV" VARCHAR2(4000 CHAR),  
	"LICENSE_TYPE_ID_CSV" VARCHAR2(4000 CHAR),  
	"LICENSE_TYPE_VALUE_CSV" VARCHAR2(4000 CHAR),  
	"EXHIBITION_END_DT" TIMESTAMP (6),  
	"EXHIBITION_ST_DT" TIMESTAMP (6),  
	"DELIVERY_LEAD_DAYS" NUMBER(9,0) NOT NULL ENABLE,  
	"SOURCE_SYSTEM" VARCHAR2(255 CHAR),  
	"DELIVER_BY_DT" TIMESTAMP (6),  
	"CREATED_DT" TIMESTAMP (6),  
	"CREATED_BY" VARCHAR2(255 CHAR),  
	"LAST_UPDATED_DT" TIMESTAMP (6),  
	"LAST_UPDATED_BY" VARCHAR2(255 CHAR),  
	"CREDIT_LOCKOUT" NUMBER(1,0),  
	"SALES_PERSON" VARCHAR2(255 CHAR),  
	"PROG_TYPE" VARCHAR2(255),  
	"TERR_MIG_COMPLETED" NUMBER(1,0) DEFAULT 0 
   ) SEGMENT CREATION IMMEDIATE 
  PCTFREE 10 PCTUSED 40 INITRANS 1 MAXTRANS 255 
 NOCOMPRESS LOGGING
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SPT_DATA1" ;


  CREATE TABLE "DART_B2B2"."RPM_DEAL_PRODUCT_STITCHED_BKP_DEC23_2020" 
   (	"RPM_STITCHED_ID" NUMBER(19,0) NOT NULL ENABLE,  
	"RPM_STATION_ID" NUMBER(10,0) NOT NULL ENABLE,  
	"STATION_ID" NUMBER(10,0) NOT NULL ENABLE,  
	"STATION_NAME" VARCHAR2(255 CHAR),  
	"GPMS_PROG_ID" NUMBER(19,0) NOT NULL ENABLE,  
	"GPMS_SEAS_ID" NUMBER(19,0) NOT NULL ENABLE,  
	"PROG_ID" NUMBER(10,0) NOT NULL ENABLE,  
	"SEAS_ID" NUMBER(10,0) NOT NULL ENABLE,  
	"PROG_NAME" VARCHAR2(255 CHAR),  
	"SEASON_NUM" VARCHAR2(255 CHAR),  
	"TERRITORY_VALUE_CSV" VARCHAR2(4000 CHAR),  
	"TERRITORY_ID_CSV" VARCHAR2(4000 CHAR),  
	"CONTRACT_STATUS_VALUE_CSV" VARCHAR2(4000 CHAR),  
	"CONTRACT_STATUS_TYPE_CSV" VARCHAR2(4000 CHAR),  
	"LICENSE_TYPE_ID_CSV" VARCHAR2(4000 CHAR),  
	"LICENSE_TYPE_VALUE_CSV" VARCHAR2(4000 CHAR),  
	"EXHIBITION_END_DT" TIMESTAMP (6),  
	"EXHIBITION_ST_DT" TIMESTAMP (6),  
	"DELIVERY_LEAD_DAYS" NUMBER(9,0) NOT NULL ENABLE,  
	"SOURCE_SYSTEM" VARCHAR2(255 CHAR),  
	"DELIVER_BY_DT" TIMESTAMP (6),  
	"CREATED_DT" TIMESTAMP (6),  
	"CREATED_BY" VARCHAR2(255 CHAR),  
	"LAST_UPDATED_DT" TIMESTAMP (6),  
	"LAST_UPDATED_BY" VARCHAR2(255 CHAR),  
	"CREDIT_LOCKOUT" NUMBER(1,0),  
	"SALES_PERSON" VARCHAR2(255 CHAR),  
	"PROG_TYPE" VARCHAR2(255) 
   ) SEGMENT CREATION IMMEDIATE 
  PCTFREE 10 PCTUSED 40 INITRANS 1 MAXTRANS 255 
 NOCOMPRESS LOGGING
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SPT_DATA1" ;


  CREATE TABLE "DART_B2B2"."RPM_DEAL_PRODUCT_STITCHED_HIST" 
   (	"RPM_STITCHED_ID" NUMBER(19,0) NOT NULL ENABLE,  
	"RPM_STATION_ID" NUMBER(10,0) NOT NULL ENABLE,  
	"STATION_ID" NUMBER(10,0) DEFAULT (0) NOT NULL ENABLE,  
	"STATION_NAME" VARCHAR2(255 CHAR),  
	"GPMS_PROG_ID" NUMBER(19,0) NOT NULL ENABLE,  
	"GPMS_SEAS_ID" NUMBER(19,0) DEFAULT (0) NOT NULL ENABLE,  
	"PROG_ID" NUMBER(10,0) DEFAULT (0) NOT NULL ENABLE,  
	"SEAS_ID" NUMBER(10,0) DEFAULT (0) NOT NULL ENABLE,  
	"PROG_NAME" VARCHAR2(255 CHAR),  
	"SEASON_NUM" VARCHAR2(255 CHAR),  
	"TERRITORY_VALUE_CSV" VARCHAR2(4000 CHAR),  
	"TERRITORY_ID_CSV" VARCHAR2(4000 CHAR),  
	"CONTRACT_STATUS_VALUE_CSV" VARCHAR2(4000 CHAR),  
	"CONTRACT_STATUS_TYPE_CSV" VARCHAR2(4000 CHAR),  
	"LICENSE_TYPE_ID_CSV" VARCHAR2(4000 CHAR),  
	"LICENSE_TYPE_VALUE_CSV" VARCHAR2(4000 CHAR),  
	"EXHIBITION_END_DT" TIMESTAMP (6),  
	"EXHIBITION_ST_DT" TIMESTAMP (6),  
	"DELIVERY_LEAD_DAYS" NUMBER(9,0) DEFAULT (0) NOT NULL ENABLE,  
	"SOURCE_SYSTEM" VARCHAR2(255 CHAR) DEFAULT 'RPM',  
	"DELIVER_BY_DT" TIMESTAMP (6),  
	"CREATED_DT" TIMESTAMP (6),  
	"CREATED_BY" VARCHAR2(255 CHAR),  
	"LAST_UPDATED_DT" TIMESTAMP (6),  
	"LAST_UPDATED_BY" VARCHAR2(255 CHAR),  
	"CREDIT_LOCKOUT" NUMBER(1,0),  
	"SALES_PERSON" VARCHAR2(255 CHAR),  
	 PRIMARY KEY ("RPM_STITCHED_ID") 
  USING INDEX PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SPT_DATA1"  ENABLE
   ) SEGMENT CREATION IMMEDIATE 
  PCTFREE 10 PCTUSED 40 INITRANS 1 MAXTRANS 255 
 NOCOMPRESS LOGGING
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SPT_DATA1" ;


  CREATE TABLE "DART_B2B2"."RPM_DEAL_PRODUCT_SYND" 
   (	"ACTION_LKP_ID" NUMBER(19,0),  
	"COMMENTS" VARCHAR2(4000 CHAR),  
	"CONTRACT_NO" VARCHAR2(255 CHAR),  
	"CONTRACT_STATUS_LKP_ID" NUMBER(19,0),  
	"CUSTOMER_NAME" VARCHAR2(255 CHAR),  
	"DEAL_PRODUCT_ID" VARCHAR2(255 CHAR),  
	"DELIVER_BY_DT" TIMESTAMP (6),  
	"DELIVERY_LEAD_DAYS" VARCHAR2(255 CHAR),  
	"EIDR_ID" VARCHAR2(255 CHAR),  
	"EXHIBITION_END_DT" TIMESTAMP (6),  
	"EXHIBITION_ST_DT" TIMESTAMP (6),  
	"GPMS_PRODUCT_ID" NUMBER(19,0) NOT NULL ENABLE,  
	"MPM_NO" VARCHAR2(255 CHAR),  
	"ORDER_DESC" VARCHAR2(255 CHAR),  
	"ORDER_NO" VARCHAR2(255 CHAR),  
	"PRIMARY_LANGUAGE_LKP_ID" VARCHAR2(255 CHAR),  
	"PRIMARY_MEDIA_LKP_ID" VARCHAR2(255 CHAR),  
	"PRIMARY_TERRITORY_LKP_ID" VARCHAR2(255 CHAR),  
	"RPM_REQUEST_ID" NUMBER(19,0) NOT NULL ENABLE,  
	"SALES_PERSON" VARCHAR2(255 CHAR),  
	"SOURCE_SYSTEM" VARCHAR2(255 CHAR),  
	"STATION_NAME" VARCHAR2(4000),  
	"SUB_DUB_LKP_ID" NUMBER(19,0),  
	"TERM_YEAR_DESC" VARCHAR2(255 CHAR),  
	"TERM_YEAR_NO" VARCHAR2(255 CHAR),  
	"TERM_YEAR_STATUS" VARCHAR2(255 CHAR),  
	"TITLE_STATUS" VARCHAR2(255 CHAR),  
	"CREATED_DT" TIMESTAMP (6),  
	"LAST_UPDATED_DT" TIMESTAMP (6),  
	"CREATED_BY" VARCHAR2(255 CHAR),  
	"LAST_UPDATED_BY" VARCHAR2(255 CHAR),  
	"SEASON_NUM" VARCHAR2(255 CHAR),  
	"RPM_STATION_ID" VARCHAR2(255),  
	"CUSTOMER_NO" NUMBER(19,0),  
	"GPMS_PROG_ID" NUMBER(19,0) NOT NULL ENABLE,  
	"GPMS_SEAS_ID" NUMBER(19,0) NOT NULL ENABLE,  
	"AGREEMENT_ID" VARCHAR2(20),  
	"PROG_NAME" VARCHAR2(400),  
	"PROG_TYPE" VARCHAR2(400),  
	"GPMS_EPS_ID" NUMBER(19,0),  
	"LICENSE_FEE" VARCHAR2(255),  
	"LICENSE_FEE_CURRENCY" VARCHAR2(255),  
	"SUB_DUB_REQUESTED" VARCHAR2(255),  
	"KEY_CATEGORY" VARCHAR2(255),  
	"PRICE_CATEGORY" VARCHAR2(255),  
	"PACKAGE_NAME" VARCHAR2(255),  
	"PACKAGE_ID" VARCHAR2(255),  
	"MARKET" VARCHAR2(255),  
	"AGREEMENT_TYPE" VARCHAR2(255),  
	"DEAL_TYPE" VARCHAR2(255),  
	"SYNDICATION_RUNS" VARCHAR2(255),  
	"CONTRACT_STATUS" VARCHAR2(255),  
	"SOURCE_STATION_NAME" VARCHAR2(4000),  
	"INITIAL_BROADCAST_FLAG" NUMBER(1,0) DEFAULT 0,  
	"INITIAL_BROADCAST_PARENT_ID" NUMBER(19,0),  
	"INITIAL_BROADCAST_NAME" VARCHAR2(255),  
	"INITIAL_BROADCAST" VARCHAR2(255) 
   ) SEGMENT CREATION IMMEDIATE 
  PCTFREE 10 PCTUSED 40 INITRANS 1 MAXTRANS 255 
 NOCOMPRESS LOGGING
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SPT_DATA1" ;


  CREATE TABLE "DART_B2B2"."RPM_DEAL_PRODUCT_SYND_1" 
   (	"ACTION_LKP_ID" NUMBER(19,0),  
	"COMMENTS" VARCHAR2(4000 CHAR),  
	"CONTRACT_NO" VARCHAR2(255 CHAR),  
	"CONTRACT_STATUS_LKP_ID" NUMBER(19,0),  
	"CUSTOMER_NAME" VARCHAR2(255 CHAR),  
	"DEAL_PRODUCT_ID" VARCHAR2(255 CHAR),  
	"DELIVER_BY_DT" TIMESTAMP (6),  
	"DELIVERY_LEAD_DAYS" VARCHAR2(255 CHAR),  
	"EIDR_ID" VARCHAR2(255 CHAR),  
	"EXHIBITION_END_DT" TIMESTAMP (6),  
	"EXHIBITION_ST_DT" TIMESTAMP (6),  
	"GPMS_PRODUCT_ID" NUMBER(19,0) NOT NULL ENABLE,  
	"MPM_NO" VARCHAR2(255 CHAR),  
	"ORDER_DESC" VARCHAR2(255 CHAR),  
	"ORDER_NO" VARCHAR2(255 CHAR),  
	"PRIMARY_LANGUAGE_LKP_ID" VARCHAR2(255 CHAR),  
	"PRIMARY_MEDIA_LKP_ID" VARCHAR2(255 CHAR),  
	"PRIMARY_TERRITORY_LKP_ID" VARCHAR2(255 CHAR),  
	"RPM_REQUEST_ID" NUMBER(19,0) NOT NULL ENABLE,  
	"SALES_PERSON" VARCHAR2(255 CHAR),  
	"SOURCE_SYSTEM" VARCHAR2(255 CHAR),  
	"STATION_NAME" VARCHAR2(4000),  
	"SUB_DUB_LKP_ID" NUMBER(19,0),  
	"TERM_YEAR_DESC" VARCHAR2(255 CHAR),  
	"TERM_YEAR_NO" VARCHAR2(255 CHAR),  
	"TERM_YEAR_STATUS" VARCHAR2(255 CHAR),  
	"TITLE_STATUS" VARCHAR2(255 CHAR),  
	"CREATED_DT" TIMESTAMP (6),  
	"LAST_UPDATED_DT" TIMESTAMP (6),  
	"CREATED_BY" VARCHAR2(255 CHAR),  
	"LAST_UPDATED_BY" VARCHAR2(255 CHAR),  
	"SEASON_NUM" VARCHAR2(255 CHAR),  
	"RPM_STATION_ID" VARCHAR2(255),  
	"CUSTOMER_NO" NUMBER(19,0),  
	"GPMS_PROG_ID" NUMBER(19,0) NOT NULL ENABLE,  
	"GPMS_SEAS_ID" NUMBER(19,0) NOT NULL ENABLE,  
	"AGREEMENT_ID" VARCHAR2(20),  
	"PROG_NAME" VARCHAR2(400),  
	"PROG_TYPE" VARCHAR2(400),  
	"GPMS_EPS_ID" NUMBER(19,0),  
	"LICENSE_FEE" VARCHAR2(255),  
	"LICENSE_FEE_CURRENCY" VARCHAR2(255),  
	"SUB_DUB_REQUESTED" VARCHAR2(255),  
	"KEY_CATEGORY" VARCHAR2(255),  
	"PRICE_CATEGORY" VARCHAR2(255),  
	"PACKAGE_NAME" VARCHAR2(255),  
	"PACKAGE_ID" VARCHAR2(255),  
	"MARKET" VARCHAR2(255),  
	"AGREEMENT_TYPE" VARCHAR2(255),  
	"DEAL_TYPE" VARCHAR2(255),  
	"SYNDICATION_RUNS" VARCHAR2(255),  
	"CONTRACT_STATUS" VARCHAR2(255) 
   ) SEGMENT CREATION IMMEDIATE 
  PCTFREE 10 PCTUSED 40 INITRANS 1 MAXTRANS 255 
 NOCOMPRESS LOGGING
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SPT_DATA1" ;


  CREATE TABLE "DART_B2B2"."RPM_DEAL_PRODUCT_SYND_BK" 
   (	"ACTION_LKP_ID" NUMBER(19,0),  
	"COMMENTS" VARCHAR2(4000 CHAR),  
	"CONTRACT_NO" VARCHAR2(255 CHAR),  
	"CONTRACT_STATUS_LKP_ID" NUMBER(19,0),  
	"CUSTOMER_NAME" VARCHAR2(255 CHAR),  
	"DEAL_PRODUCT_ID" VARCHAR2(255 CHAR),  
	"DELIVER_BY_DT" TIMESTAMP (6),  
	"DELIVERY_LEAD_DAYS" VARCHAR2(255 CHAR),  
	"EIDR_ID" VARCHAR2(255 CHAR),  
	"EXHIBITION_END_DT" TIMESTAMP (6),  
	"EXHIBITION_ST_DT" TIMESTAMP (6),  
	"GPMS_PRODUCT_ID" NUMBER(19,0) NOT NULL ENABLE,  
	"MPM_NO" VARCHAR2(255 CHAR),  
	"ORDER_DESC" VARCHAR2(255 CHAR),  
	"ORDER_NO" VARCHAR2(255 CHAR),  
	"PRIMARY_LANGUAGE_LKP_ID" VARCHAR2(255 CHAR),  
	"PRIMARY_MEDIA_LKP_ID" VARCHAR2(255 CHAR),  
	"PRIMARY_TERRITORY_LKP_ID" VARCHAR2(255 CHAR),  
	"RPM_REQUEST_ID" NUMBER(19,0) NOT NULL ENABLE,  
	"SALES_PERSON" VARCHAR2(255 CHAR),  
	"SOURCE_SYSTEM" VARCHAR2(255 CHAR),  
	"STATION_NAME" VARCHAR2(4000),  
	"SUB_DUB_LKP_ID" NUMBER(19,0),  
	"TERM_YEAR_DESC" VARCHAR2(255 CHAR),  
	"TERM_YEAR_NO" VARCHAR2(255 CHAR),  
	"TERM_YEAR_STATUS" VARCHAR2(255 CHAR),  
	"TITLE_STATUS" VARCHAR2(255 CHAR),  
	"CREATED_DT" TIMESTAMP (6),  
	"LAST_UPDATED_DT" TIMESTAMP (6),  
	"CREATED_BY" VARCHAR2(255 CHAR),  
	"LAST_UPDATED_BY" VARCHAR2(255 CHAR),  
	"SEASON_NUM" VARCHAR2(255 CHAR),  
	"RPM_STATION_ID" VARCHAR2(255),  
	"CUSTOMER_NO" NUMBER(19,0),  
	"GPMS_PROG_ID" NUMBER(19,0) NOT NULL ENABLE,  
	"GPMS_SEAS_ID" NUMBER(19,0) NOT NULL ENABLE,  
	"AGREEMENT_ID" VARCHAR2(20),  
	"PROG_NAME" VARCHAR2(400),  
	"PROG_TYPE" VARCHAR2(400),  
	"GPMS_EPS_ID" NUMBER(19,0),  
	"LICENSE_FEE" VARCHAR2(255),  
	"LICENSE_FEE_CURRENCY" VARCHAR2(255),  
	"SUB_DUB_REQUESTED" VARCHAR2(255),  
	"KEY_CATEGORY" VARCHAR2(255),  
	"PRICE_CATEGORY" VARCHAR2(255),  
	"PACKAGE_NAME" VARCHAR2(255),  
	"PACKAGE_ID" VARCHAR2(255),  
	"MARKET" VARCHAR2(255),  
	"AGREEMENT_TYPE" VARCHAR2(255),  
	"DEAL_TYPE" VARCHAR2(255),  
	"SYNDICATION_RUNS" VARCHAR2(255),  
	"CONTRACT_STATUS" VARCHAR2(255),  
	"SOURCE_STATION_NAME" VARCHAR2(4000) 
   ) SEGMENT CREATION IMMEDIATE 
  PCTFREE 10 PCTUSED 40 INITRANS 1 MAXTRANS 255 
 NOCOMPRESS LOGGING
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SPT_DATA1" ;


  CREATE TABLE "DART_B2B2"."RPM_DEAL_STITCH_SYNDICATION_BK" 
   (	"SYND_DEAL_ID" NUMBER(10,0) NOT NULL ENABLE,  
	"CONTRACT_ID" CHAR(8),  
	"PROG_GPMS_ID" NUMBER(10,0),  
	"SEAS_GPMS_ID" NUMBER(10,0),  
	"EPS_GPMS_ID" NUMBER(10,0),  
	"STATION_NAME" VARCHAR2(255),  
	"LKP_DIST_TYPE_ID" NUMBER,  
	"CONTRACT_STATUS" CHAR(1),  
	"CREDIT_LOCKOUT" CHAR(1),  
	"SCHD_ID" CHAR(4),  
	"ACC_START_DT" DATE,  
	"ACC_END_DT" DATE,  
	"PRODUCT_GRP_ID" CHAR(8),  
	"SYS_SYNCED_DT" DATE,  
	"PROG_TYPE" VARCHAR2(15),  
	"CREATED_BY" VARCHAR2(255) NOT NULL ENABLE,  
	"CREATED_DT" TIMESTAMP (6) NOT NULL ENABLE,  
	"LAST_UPDATED_BY" VARCHAR2(255) NOT NULL ENABLE,  
	"LAST_UPDATED_DT" TIMESTAMP (6) NOT NULL ENABLE 
   ) SEGMENT CREATION IMMEDIATE 
  PCTFREE 10 PCTUSED 40 INITRANS 1 MAXTRANS 255 
 NOCOMPRESS LOGGING
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SPT_DATA1" ;


  CREATE TABLE "DART_B2B2"."RPM_DEAL_TERRITORY_MEDIA" 
   (	"RPM_TER_MEDIA_ID" NUMBER(19,0) NOT NULL ENABLE,  
	"RPM_REQUEST_ID" NUMBER(19,0),  
	"MEDIA_ID" NUMBER(19,0),  
	"TERRITORY_ID" NUMBER(19,0),  
	"LICENSE_LKP_ID" NUMBER(10,0),  
	 PRIMARY KEY ("RPM_TER_MEDIA_ID") 
  USING INDEX PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SPT_DATA1"  ENABLE
   ) SEGMENT CREATION IMMEDIATE 
  PCTFREE 10 PCTUSED 40 INITRANS 1 MAXTRANS 255 
 NOCOMPRESS LOGGING
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SPT_DATA1" ;


  CREATE TABLE "DART_B2B2"."RPM_DEAL_TERRITORY_MEDIA_HIST" 
   (	"RPM_TER_MEDIA_ID" NUMBER(19,0) NOT NULL ENABLE,  
	"RPM_REQUEST_ID" NUMBER(19,0),  
	"MEDIA_ID" NUMBER(19,0),  
	"TERRITORY_ID" NUMBER(19,0),  
	"LICENSE_LKP_ID" NUMBER(10,0) 
   ) SEGMENT CREATION IMMEDIATE 
  PCTFREE 10 PCTUSED 40 INITRANS 1 MAXTRANS 255 
 NOCOMPRESS LOGGING
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SPT_DATA1" ;


  CREATE TABLE "DART_B2B2"."RPM_DEAL_TERRITORY_MEDIA_LANG" 
   (	"RPM_TER_MEDIA_LANG_ID" NUMBER(19,0) NOT NULL ENABLE,  
	"RPM_TER_MEDIA_ID" NUMBER(19,0),  
	"LANGUAGE_ID" NUMBER(19,0),  
	 PRIMARY KEY ("RPM_TER_MEDIA_LANG_ID") 
  USING INDEX PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SPT_DATA1"  ENABLE
   ) SEGMENT CREATION IMMEDIATE 
  PCTFREE 10 PCTUSED 40 INITRANS 1 MAXTRANS 255 
 NOCOMPRESS LOGGING
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SPT_DATA1" ;


  CREATE TABLE "DART_B2B2"."RPM_DEAL_TERRITORY_MEDIA_LANG_SYND" 
   (	"RPM_TER_MEDIA_LANG_ID" NUMBER(19,0) NOT NULL ENABLE,  
	"RPM_TER_MEDIA_ID" NUMBER(19,0),  
	"LANGUAGE_ID" NUMBER(19,0) 
   ) SEGMENT CREATION IMMEDIATE 
  PCTFREE 10 PCTUSED 40 INITRANS 1 MAXTRANS 255 
 NOCOMPRESS LOGGING
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SPT_DATA1" ;


  CREATE TABLE "DART_B2B2"."RPM_DEAL_TERRITORY_MEDIA_LA_HI" 
   (	"RPM_TER_MEDIA_LANG_ID" NUMBER(19,0) NOT NULL ENABLE,  
	"RPM_TER_MEDIA_ID" NUMBER(19,0),  
	"LANGUAGE_ID" NUMBER(19,0) 
   ) SEGMENT CREATION IMMEDIATE 
  PCTFREE 10 PCTUSED 40 INITRANS 1 MAXTRANS 255 
 NOCOMPRESS LOGGING
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SPT_DATA1" ;


  CREATE TABLE "DART_B2B2"."RPM_DEAL_TERRITORY_MEDIA_STG" 
   (	"RPM_TER_MEDIA_ID" NUMBER(19,0) NOT NULL ENABLE,  
	"STG_ID" NUMBER(19,0),  
	"MEDIA_ID" NUMBER(19,0),  
	"TERRITORY_ID" NUMBER(19,0),  
	"LICENSE_LKP_ID" NUMBER(10,0),  
	 PRIMARY KEY ("RPM_TER_MEDIA_ID") 
  USING INDEX PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SPT_DATA1"  ENABLE
   ) SEGMENT CREATION IMMEDIATE 
  PCTFREE 10 PCTUSED 40 INITRANS 1 MAXTRANS 255 
 NOCOMPRESS LOGGING
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SPT_DATA1" ;


  CREATE TABLE "DART_B2B2"."RPM_DEAL_TERRITORY_MEDIA_SYND" 
   (	"RPM_TER_MEDIA_ID" NUMBER(19,0) NOT NULL ENABLE,  
	"RPM_REQUEST_ID" NUMBER(19,0),  
	"MEDIA_ID" NUMBER(19,0),  
	"TERRITORY_ID" NUMBER(19,0),  
	"LICENSE_LKP_ID" NUMBER(10,0) 
   ) SEGMENT CREATION IMMEDIATE 
  PCTFREE 10 PCTUSED 40 INITRANS 1 MAXTRANS 255 
 NOCOMPRESS LOGGING
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SPT_DATA1" ;


  CREATE TABLE "DART_B2B2"."RPM_DEAL_TER_MEDIA_LANG_STG" 
   (	"RPM_TER_MEDIA_LANG_ID" NUMBER(19,0) NOT NULL ENABLE,  
	"RPM_TER_MEDIA_ID" NUMBER(19,0),  
	"LANGUAGE_ID" NUMBER(19,0) 
   ) SEGMENT CREATION IMMEDIATE 
  PCTFREE 10 PCTUSED 40 INITRANS 1 MAXTRANS 255 
 NOCOMPRESS LOGGING
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SPT_DATA1" ;


  CREATE TABLE "DART_B2B2"."RPM_HISTORICAL_DATA_DUMP" 
   (	"ID" VARCHAR2(4000),  
	"DEAL_VERSION_ID" VARCHAR2(4000),  
	"RPM_DEAL_ID" VARCHAR2(4000),  
	"DEAL_PRODUCT_ID" VARCHAR2(4000),  
	"SOURCE_SYSTEM" VARCHAR2(4000),  
	"ORDER_NUMBER" VARCHAR2(4000),  
	"CUSTOMER_NUMBER" VARCHAR2(4000),  
	"CUSTOMER_NAME" VARCHAR2(4000),  
	"CUSTOMER_STATUS" VARCHAR2(4000),  
	"PRIMARY_MEDIA_ID" VARCHAR2(4000),  
	"PRIMARY_TERRITORYID" VARCHAR2(4000),  
	"PRIMARY_LANGUAGEID" VARCHAR2(4000),  
	"GPMS_PRODUCTID" VARCHAR2(4000),  
	"MPM_NUMBER" VARCHAR2(4000),  
	"EXHIBITION_START_DATE" VARCHAR2(4000),  
	"EXHIBITION_END_DATE" VARCHAR2(4000),  
	"DELIVERY_LEAD_DAYS" VARCHAR2(4000),  
	"DELIVERY_BY_DATE" VARCHAR2(4000),  
	"STATION_NAME" VARCHAR2(4000),  
	"AGREEMENT_STATUS" VARCHAR2(4000),  
	"TITLE_STATUS" VARCHAR2(4000),  
	"START_ORDER_NUMBER" VARCHAR2(4000),  
	"START_ORDER_DESC" VARCHAR2(4000),  
	"SHIP_STATUS" VARCHAR2(4000),  
	"ALPHA_ID" VARCHAR2(4000),  
	"ACTION" VARCHAR2(4000),  
	"SPEND_LIMIT" VARCHAR2(4000),  
	"COMMENTS" VARCHAR2(4000),  
	"TERM_YEAR_NUMBER" VARCHAR2(4000),  
	"TERM_YEAR_DESC" VARCHAR2(4000),  
	"FORMATS_REQUESTED" VARCHAR2(4000),  
	"LICENSED_LTM_SMRY" VARCHAR2(4000),  
	"CREATED_DATE" VARCHAR2(4000),  
	"DUBBING_APPROVED" VARCHAR2(4000),  
	"RPM_REQ_ID" VARCHAR2(4000),  
	"EIDR_ID" VARCHAR2(4000),  
	"LICENSE_FEE" VARCHAR2(4000),  
	"TERM_YEAR_STATUS" VARCHAR2(4000),  
	"BROADCAST_TYPE" VARCHAR2(4000),  
	"CREATED_BY" VARCHAR2(4000),  
	"OVERRIDE_STATION_NAME" VARCHAR2(4000),  
	"STATION_ID" VARCHAR2(4000),  
	"LICENSE_FEE_CURRENCY" VARCHAR2(4000),  
	"SALES_PERSON" VARCHAR2(4000),  
	"KEY_CATEGORY" VARCHAR2(4000),  
	"PRICE_CATEGORY" VARCHAR2(4000),  
	"IS_HISTORICAL_DATA" NUMBER DEFAULT 0 NOT NULL ENABLE 
   ) SEGMENT CREATION IMMEDIATE 
  PCTFREE 10 PCTUSED 40 INITRANS 1 MAXTRANS 255 
 NOCOMPRESS LOGGING
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SPT_DATA1" ;


  CREATE TABLE "DART_B2B2"."RPM_JSON_LOG" 
   (	"RPM_JSON_ID" NUMBER(19,0) NOT NULL ENABLE,  
	"RPM_REQUEST_ID" NUMBER(19,0) NOT NULL ENABLE,  
	"JSON" CLOB,  
	"CREATED_DT" TIMESTAMP (6),  
	"IS_PROCESSED" NUMBER(10,0) DEFAULT (1) NOT NULL ENABLE,  
	"PROCESSING_ERROR" CLOB,  
	"DB_PROCESS_DATE" TIMESTAMP (6),  
	"IS_SYNDICATION" NUMBER(1,0) DEFAULT 0,  
	 CONSTRAINT "RPM_JSON_ID" PRIMARY KEY ("RPM_JSON_ID") 
  USING INDEX PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SPT_DATA1"  ENABLE
   ) SEGMENT CREATION IMMEDIATE 
  PCTFREE 10 PCTUSED 40 INITRANS 1 MAXTRANS 255 
 NOCOMPRESS LOGGING
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SPT_DATA1" 
 LOB ("JSON") STORE AS BASICFILE (
  TABLESPACE "SPT_DATA1" ENABLE STORAGE IN ROW CHUNK 8192 RETENTION 
  NOCACHE LOGGING 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
 LOB ("PROCESSING_ERROR") STORE AS BASICFILE (
  TABLESPACE "SPT_DATA1" ENABLE STORAGE IN ROW CHUNK 8192 RETENTION 
  NOCACHE LOGGING 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) ;


  CREATE TABLE "DART_B2B2"."RPM_JSON_LOG_SYND" 
   (	"RPM_JSON_ID" NUMBER(19,0) NOT NULL ENABLE,  
	"RPM_REQUEST_ID" NUMBER(19,0) NOT NULL ENABLE,  
	"JSON" CLOB,  
	"CREATED_DT" TIMESTAMP (6),  
	"IS_PROCESSED" NUMBER(10,0) DEFAULT (1) NOT NULL ENABLE,  
	"PROCESSING_ERROR" CLOB,  
	"DB_PROCESS_DATE" TIMESTAMP (6),  
	"IS_SYNDICATION" NUMBER(1,0) DEFAULT 0,  
	 CONSTRAINT "RPM_JSON_ID_SYND" PRIMARY KEY ("RPM_JSON_ID") 
  USING INDEX PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SPT_DATA1"  ENABLE
   ) SEGMENT CREATION IMMEDIATE 
  PCTFREE 10 PCTUSED 40 INITRANS 1 MAXTRANS 255 
 NOCOMPRESS LOGGING
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SPT_DATA1" 
 LOB ("JSON") STORE AS SECUREFILE (
  TABLESPACE "SPT_DATA1" ENABLE STORAGE IN ROW CHUNK 8192
  NOCACHE LOGGING  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
 LOB ("PROCESSING_ERROR") STORE AS SECUREFILE (
  TABLESPACE "SPT_DATA1" ENABLE STORAGE IN ROW CHUNK 8192
  NOCACHE LOGGING  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) ;


  CREATE TABLE "DART_B2B2"."RPM_LANGUAGE" 
   (	"LANGUAGE_ID" NUMBER(19,0) NOT NULL ENABLE,  
	"LANGUAGE_NAME" VARCHAR2(255 CHAR),  
	 PRIMARY KEY ("LANGUAGE_ID") 
  USING INDEX PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SPT_DATA1"  ENABLE
   ) SEGMENT CREATION IMMEDIATE 
  PCTFREE 10 PCTUSED 40 INITRANS 1 MAXTRANS 255 
 NOCOMPRESS LOGGING
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SPT_DATA1" ;


  CREATE TABLE "DART_B2B2"."RPM_LANGUAGE_SYND" 
   (	"LANGUAGE_ID" NUMBER(19,0) NOT NULL ENABLE,  
	"LANGUAGE_NAME" VARCHAR2(255 CHAR) 
   ) SEGMENT CREATION IMMEDIATE 
  PCTFREE 10 PCTUSED 40 INITRANS 1 MAXTRANS 255 
 NOCOMPRESS LOGGING
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SPT_DATA1" ;


  CREATE TABLE "DART_B2B2"."RPM_MEDIA" 
   (	"MEDIA_ID" NUMBER(19,0) NOT NULL ENABLE,  
	"MEDIA_DESC" VARCHAR2(255 CHAR),  
	"LKP_ID" NUMBER(10,0),  
	 PRIMARY KEY ("MEDIA_ID") 
  USING INDEX PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SPT_DATA1"  ENABLE
   ) SEGMENT CREATION IMMEDIATE 
  PCTFREE 10 PCTUSED 40 INITRANS 1 MAXTRANS 255 
 NOCOMPRESS LOGGING
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SPT_DATA1" ;


  CREATE TABLE "DART_B2B2"."RPM_MEDIA_SYND" 
   (	"MEDIA_ID" NUMBER(19,0) NOT NULL ENABLE,  
	"MEDIA_DESC" VARCHAR2(255 CHAR),  
	"LKP_ID" NUMBER(10,0) 
   ) SEGMENT CREATION IMMEDIATE 
  PCTFREE 10 PCTUSED 40 INITRANS 1 MAXTRANS 255 
 NOCOMPRESS LOGGING
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SPT_DATA1" ;


  CREATE TABLE "DART_B2B2"."RPM_TERRITORY" 
   (	"TERRITORY_ID" NUMBER(19,0) NOT NULL ENABLE,  
	"TERRITORY_NAME" VARCHAR2(255 CHAR),  
	 PRIMARY KEY ("TERRITORY_ID") 
  USING INDEX PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SPT_DATA1"  ENABLE
   ) SEGMENT CREATION IMMEDIATE 
  PCTFREE 10 PCTUSED 40 INITRANS 1 MAXTRANS 255 
 NOCOMPRESS LOGGING
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SPT_DATA1" ;


  CREATE TABLE "DART_B2B2"."RPM_TERRITORY_HIST" 
   (	"TERRITORY_ID" NUMBER(19,0) NOT NULL ENABLE,  
	"TERRITORY_NAME" VARCHAR2(255 CHAR) 
   ) SEGMENT CREATION IMMEDIATE 
  PCTFREE 10 PCTUSED 40 INITRANS 1 MAXTRANS 255 
 NOCOMPRESS LOGGING
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SPT_DATA1" ;


  CREATE TABLE "DART_B2B2"."RPM_TERRITORY_SYND" 
   (	"TERRITORY_ID" NUMBER(19,0) NOT NULL ENABLE,  
	"TERRITORY_NAME" VARCHAR2(255 CHAR) 
   ) SEGMENT CREATION IMMEDIATE 
  PCTFREE 10 PCTUSED 40 INITRANS 1 MAXTRANS 255 
 NOCOMPRESS LOGGING
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SPT_DATA1" ;


  CREATE TABLE "DART_B2B2"."RT_JUNE28_2019" 
   (	"TERRITORY_ID" NUMBER(19,0) NOT NULL ENABLE,  
	"TERRITORY_NAME" VARCHAR2(255 CHAR) 
   ) SEGMENT CREATION IMMEDIATE 
  PCTFREE 10 PCTUSED 40 INITRANS 1 MAXTRANS 255 
 NOCOMPRESS LOGGING
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SPT_DATA1" ;


  CREATE TABLE "DART_B2B2"."SYNDICATION_CUSTOMER" 
   (	"CUST_ID" NUMBER(10,0) NOT NULL ENABLE,  
	"CUSTOMER_NAME" VARCHAR2(255) NOT NULL ENABLE,  
	"CUSTOMER_NUMBER" NUMBER(10,0),  
	"CREATED_DT" TIMESTAMP (6),  
	"LAST_UPDATED_DT" TIMESTAMP (6),  
	"COUNTRY" VARCHAR2(255),  
	 CONSTRAINT "SYS_C0087299" PRIMARY KEY ("CUST_ID") 
  USING INDEX PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SPT_DATA1"  ENABLE
   ) SEGMENT CREATION IMMEDIATE 
  PCTFREE 10 PCTUSED 40 INITRANS 1 MAXTRANS 255 
 NOCOMPRESS LOGGING
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SPT_DATA1" ;


  CREATE TABLE "DART_B2B2"."SYNDICATION_CUSTOMER_BK" 
   (	"CUST_ID" NUMBER(10,0) NOT NULL ENABLE,  
	"CUSTOMER_NAME" VARCHAR2(255) NOT NULL ENABLE,  
	"CUSTOMER_NUMBER" NUMBER(10,0),  
	"CREATED_DT" TIMESTAMP (6),  
	"LAST_UPDATED_DT" TIMESTAMP (6),  
	"COUNTRY" VARCHAR2(255) 
   ) SEGMENT CREATION IMMEDIATE 
  PCTFREE 10 PCTUSED 40 INITRANS 1 MAXTRANS 255 
 NOCOMPRESS LOGGING
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SPT_DATA1" ;


  CREATE TABLE "DART_B2B2"."SYNDICATION_CUSTOMER_BK1" 
   (	"CUST_ID" NUMBER(10,0) NOT NULL ENABLE,  
	"CUSTOMER_NAME" VARCHAR2(255) NOT NULL ENABLE,  
	"CUSTOMER_NUMBER" NUMBER(10,0),  
	"CREATED_DT" TIMESTAMP (6),  
	"LAST_UPDATED_DT" TIMESTAMP (6),  
	"COUNTRY" VARCHAR2(255) 
   ) SEGMENT CREATION IMMEDIATE 
  PCTFREE 10 PCTUSED 40 INITRANS 1 MAXTRANS 255 
 NOCOMPRESS LOGGING
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SPT_DATA1" ;


  CREATE TABLE "DART_B2B2"."SYNDICATION_CUSTOMER_TWO" 
   (	"CUST_ID" NUMBER(10,0) NOT NULL ENABLE,  
	"CUSTOMER_NAME" VARCHAR2(255) NOT NULL ENABLE,  
	"CUSTOMER_NUMBER" NUMBER(10,0),  
	"CREATED_DT" TIMESTAMP (6),  
	"LAST_UPDATED_DT" TIMESTAMP (6),  
	"COUNTRY" VARCHAR2(255) 
   ) SEGMENT CREATION IMMEDIATE 
  PCTFREE 10 PCTUSED 40 INITRANS 1 MAXTRANS 255 
 NOCOMPRESS LOGGING
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SPT_DATA1" ;


  CREATE TABLE "DART_B2B2"."SYNDICATION_DEAL_MAP" 
   (	"CONNECT_VALUE" VARCHAR2(255),  
	"RPM_VALUE" VARCHAR2(255),  
	"LKP_TYPE_ID" NUMBER(10,0) 
   ) SEGMENT CREATION IMMEDIATE 
  PCTFREE 10 PCTUSED 40 INITRANS 1 MAXTRANS 255 
 NOCOMPRESS LOGGING
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SPT_DATA1" ;


  CREATE TABLE "DART_B2B2"."SYNDICATION_DEAL_PRODUCT" 
   (	"ACTION_LKP_ID" NUMBER(19,0),  
	"COMMENTS" VARCHAR2(4000 CHAR),  
	"CONTRACT_NO" VARCHAR2(255 CHAR),  
	"CONTRACT_STATUS_LKP_ID" NUMBER(19,0),  
	"CUSTOMER_NAME" VARCHAR2(255 CHAR),  
	"DEAL_PRODUCT_ID" VARCHAR2(255 CHAR),  
	"DELIVER_BY_DT" TIMESTAMP (6),  
	"DELIVERY_LEAD_DAYS" VARCHAR2(255 CHAR),  
	"EIDR_ID" VARCHAR2(255 CHAR),  
	"EXHIBITION_END_DT" TIMESTAMP (6),  
	"EXHIBITION_ST_DT" TIMESTAMP (6),  
	"GPMS_PRODUCT_ID" NUMBER(19,0) NOT NULL ENABLE,  
	"MPM_NO" VARCHAR2(255 CHAR),  
	"ORDER_DESC" VARCHAR2(255 CHAR),  
	"ORDER_NO" VARCHAR2(255 CHAR),  
	"PRIMARY_LANGUAGE_LKP_ID" VARCHAR2(255 CHAR),  
	"PRIMARY_MEDIA_LKP_ID" VARCHAR2(255 CHAR),  
	"PRIMARY_TERRITORY_LKP_ID" VARCHAR2(255 CHAR),  
	"RPM_REQUEST_ID" NUMBER(19,0) NOT NULL ENABLE,  
	"SALES_PERSON" VARCHAR2(255 CHAR),  
	"SOURCE_SYSTEM" VARCHAR2(255 CHAR),  
	"STATION_NAME" VARCHAR2(4000),  
	"SUB_DUB_LKP_ID" NUMBER(19,0),  
	"TERM_YEAR_DESC" VARCHAR2(255 CHAR),  
	"TERM_YEAR_NO" VARCHAR2(255 CHAR),  
	"TERM_YEAR_STATUS" VARCHAR2(255 CHAR),  
	"TITLE_STATUS" VARCHAR2(255 CHAR),  
	"CREATED_DT" TIMESTAMP (6),  
	"LAST_UPDATED_DT" TIMESTAMP (6),  
	"CREATED_BY" VARCHAR2(255 CHAR),  
	"LAST_UPDATED_BY" VARCHAR2(255 CHAR),  
	"SEASON_NUM" VARCHAR2(255 CHAR),  
	"RPM_STATION_ID" VARCHAR2(255),  
	"CUSTOMER_NO" NUMBER(19,0),  
	"GPMS_PROG_ID" NUMBER(19,0) NOT NULL ENABLE,  
	"GPMS_SEAS_ID" NUMBER(19,0) NOT NULL ENABLE,  
	"AGREEMENT_ID" VARCHAR2(20),  
	"PROG_NAME" VARCHAR2(400),  
	"PROG_TYPE" VARCHAR2(400),  
	"GPMS_EPS_ID" NUMBER(19,0),  
	"LICENSE_FEE" VARCHAR2(255),  
	"LICENSE_FEE_CURRENCY" VARCHAR2(255),  
	"SUB_DUB_REQUESTED" VARCHAR2(255),  
	"KEY_CATEGORY" VARCHAR2(255),  
	"PRICE_CATEGORY" VARCHAR2(255),  
	"PACKAGE_NAME" VARCHAR2(255),  
	"PACKAGE_ID" VARCHAR2(255),  
	"MARKET" VARCHAR2(255),  
	"AGREEMENT_TYPE" VARCHAR2(255),  
	"DEAL_TYPE" VARCHAR2(255),  
	"SYNDICATION_RUNS" VARCHAR2(255) 
   ) SEGMENT CREATION IMMEDIATE 
  PCTFREE 10 PCTUSED 40 INITRANS 1 MAXTRANS 255 
 NOCOMPRESS LOGGING
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SPT_DATA1" ;


  CREATE TABLE "DART_B2B2"."SYNDICATION_DEAL_PRODUCT_STATION" 
   (	"RPM_REQUEST_ID" NUMBER(19,0),  
	"B2B_STATION_ID" NUMBER(10,0) 
   ) SEGMENT CREATION IMMEDIATE 
  PCTFREE 10 PCTUSED 40 INITRANS 1 MAXTRANS 255 
 NOCOMPRESS LOGGING
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SPT_DATA1" ;


  CREATE TABLE "DART_B2B2"."SYNDICATION_DEAL_TERRITORY_MEDIA" 
   (	"RPM_TER_MEDIA_ID" NUMBER(19,0) NOT NULL ENABLE,  
	"RPM_REQUEST_ID" NUMBER(19,0),  
	"MEDIA_ID" NUMBER(19,0),  
	"TERRITORY_ID" NUMBER(19,0),  
	"LICENSE_LKP_ID" NUMBER(10,0) 
   ) SEGMENT CREATION IMMEDIATE 
  PCTFREE 10 PCTUSED 40 INITRANS 1 MAXTRANS 255 
 NOCOMPRESS LOGGING
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SPT_DATA1" ;


  CREATE TABLE "DART_B2B2"."SYNDICATION_DEAL_TERRITORY_MEDIA_LANG" 
   (	"RPM_TER_MEDIA_LANG_ID" NUMBER(19,0) NOT NULL ENABLE,  
	"RPM_TER_MEDIA_ID" NUMBER(19,0),  
	"LANGUAGE_ID" NUMBER(19,0) 
   ) SEGMENT CREATION IMMEDIATE 
  PCTFREE 10 PCTUSED 40 INITRANS 1 MAXTRANS 255 
 NOCOMPRESS LOGGING
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SPT_DATA1" ;


  CREATE TABLE "DART_B2B2"."SYNDICATION_LANGUAGE" 
   (	"LANGUAGE_ID" NUMBER(19,0) NOT NULL ENABLE,  
	"LANGUAGE_NAME" VARCHAR2(255 CHAR) 
   ) SEGMENT CREATION IMMEDIATE 
  PCTFREE 10 PCTUSED 40 INITRANS 1 MAXTRANS 255 
 NOCOMPRESS LOGGING
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SPT_DATA1" ;


  CREATE TABLE "DART_B2B2"."SYNDICATION_MEDIA" 
   (	"MEDIA_ID" NUMBER(19,0) NOT NULL ENABLE,  
	"MEDIA_DESC" VARCHAR2(255 CHAR),  
	"LKP_ID" NUMBER(10,0) 
   ) SEGMENT CREATION IMMEDIATE 
  PCTFREE 10 PCTUSED 40 INITRANS 1 MAXTRANS 255 
 NOCOMPRESS LOGGING
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SPT_DATA1" ;


  CREATE TABLE "DART_B2B2"."SYNDICATION_STATION_MASTER" 
   (	"STATION_ID" NUMBER(10,0),  
	"STATION_NAME" VARCHAR2(100),  
	"STATION_NAME_SOURCE" VARCHAR2(765),  
	"SOURCE" CHAR(6),  
	"CREATED_DT" DATE,  
	"CREATED_BY" VARCHAR2(10),  
	"IS_DELETED" NUMBER(1,0),  
	"IS_ACTIVE" NUMBER,  
	"LICENSE_INDICATOR" NUMBER,  
	"CUSTOMER_ID" NUMBER(10,0),  
	"LAST_UPDATED_BY" VARCHAR2(255),  
	"SYND_STATION_ID" NUMBER(10,0),  
	"LAST_UPDATED_DT" DATE,  
	 CONSTRAINT "SYS_C0087296" PRIMARY KEY ("STATION_ID") 
  USING INDEX PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SPT_DATA1"  ENABLE
   ) SEGMENT CREATION IMMEDIATE 
  PCTFREE 10 PCTUSED 40 INITRANS 1 MAXTRANS 255 
 NOCOMPRESS LOGGING
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SPT_DATA1" ;


  CREATE TABLE "DART_B2B2"."SYNDICATION_STATION_MASTER1" 
   (	"STATION_ID" NUMBER(10,0),  
	"STATION_NAME" VARCHAR2(100),  
	"STATION_NAME_SOURCE" VARCHAR2(765),  
	"SOURCE" CHAR(6),  
	"CREATED_DT" DATE,  
	"CREATED_BY" VARCHAR2(10),  
	"IS_DELETED" NUMBER(1,0),  
	"IS_ACTIVE" NUMBER,  
	"LICENSE_INDICATOR" NUMBER,  
	"CUSTOMER_ID" NUMBER(10,0),  
	"LAST_UPDATED_BY" VARCHAR2(255),  
	"SYND_STATION_ID" NUMBER(10,0),  
	"LAST_UPDATED_DT" DATE 
   ) SEGMENT CREATION IMMEDIATE 
  PCTFREE 10 PCTUSED 40 INITRANS 1 MAXTRANS 255 
 NOCOMPRESS LOGGING
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SPT_DATA1" ;


  CREATE TABLE "DART_B2B2"."SYNDICATION_STATION_MASTER_BK" 
   (	"STATION_ID" NUMBER(10,0),  
	"STATION_NAME" VARCHAR2(100),  
	"STATION_NAME_SOURCE" VARCHAR2(765),  
	"SOURCE" CHAR(6),  
	"CREATED_DT" DATE,  
	"CREATED_BY" VARCHAR2(10),  
	"IS_DELETED" NUMBER(1,0),  
	"IS_ACTIVE" NUMBER,  
	"LICENSE_INDICATOR" NUMBER,  
	"CUSTOMER_ID" NUMBER(10,0),  
	"LAST_UPDATED_BY" VARCHAR2(255),  
	"SYND_STATION_ID" NUMBER(10,0),  
	"LAST_UPDATED_DT" DATE 
   ) SEGMENT CREATION IMMEDIATE 
  PCTFREE 10 PCTUSED 40 INITRANS 1 MAXTRANS 255 
 NOCOMPRESS LOGGING
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SPT_DATA1" ;


  CREATE TABLE "DART_B2B2"."SYNDICATION_STATION_MASTER_TWO" 
   (	"STATION_ID" NUMBER(10,0),  
	"STATION_NAME" VARCHAR2(100),  
	"STATION_NAME_SOURCE" VARCHAR2(765),  
	"SOURCE" CHAR(6),  
	"CREATED_DT" DATE,  
	"CREATED_BY" VARCHAR2(10),  
	"IS_DELETED" NUMBER(1,0),  
	"IS_ACTIVE" NUMBER,  
	"LICENSE_INDICATOR" NUMBER,  
	"CUSTOMER_ID" NUMBER(10,0),  
	"LAST_UPDATED_BY" VARCHAR2(255),  
	"SYND_STATION_ID" NUMBER(10,0),  
	"LAST_UPDATED_DT" DATE 
   ) SEGMENT CREATION IMMEDIATE 
  PCTFREE 10 PCTUSED 40 INITRANS 1 MAXTRANS 255 
 NOCOMPRESS LOGGING
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SPT_DATA1" ;


  CREATE TABLE "DART_B2B2"."SYNDICATION_TERRITORY" 
   (	"TERRITORY_ID" NUMBER(19,0) NOT NULL ENABLE,  
	"TERRITORY_NAME" VARCHAR2(255 CHAR) 
   ) SEGMENT CREATION IMMEDIATE 
  PCTFREE 10 PCTUSED 40 INITRANS 1 MAXTRANS 255 
 NOCOMPRESS LOGGING
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SPT_DATA1" ;


  CREATE TABLE "DART_B2B2"."TERRITORY_TEMP" 
   (	"TERRITORY_ID" NUMBER(10,0),  
	"LICENSE_LKP_ID" NUMBER(10,0) 
   ) SEGMENT CREATION IMMEDIATE 
  PCTFREE 10 PCTUSED 40 INITRANS 1 MAXTRANS 255 
 NOCOMPRESS LOGGING
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SPT_DATA1" ;

